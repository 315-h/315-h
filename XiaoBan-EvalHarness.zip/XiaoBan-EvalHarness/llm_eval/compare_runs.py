"""
跨轮对比：把多次 run_eval 的 summary 拉平对比，并列出逐条翻转清单。
用法：
  python compare_runs.py full fix_d1d2 fix_d5 ...
  python compare_runs.py full fix_d1d2 --out ../out/compare_step1.md
"""
from __future__ import annotations

import argparse
import json
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, "out")

ROWS = [
    ("用例数 total", lambda s: s["total"]),
    ("失败条数 failures", lambda s: s.get("failures", 0)),
    ("全命中 strict", lambda s: s["rates"]["strict_full_hit"]),
    ("50% 口径 half", lambda s: s["rates"]["half_50pct_hit"]),
    ("宽松 anyhit", lambda s: s["rates"]["anyhit_lenient"]),
    ("禁词命中(过报)", lambda s: s["rates"]["forbidden_hit"]),
    ("输出兜底话术", lambda s: s["produced_fallback_answer"]["rate"]),
    ("  兜底条数", lambda s: s["produced_fallback_answer"]["n"]),
    ("欠报条数", lambda s: s["under_answer"]["n"]),
    ("标准QA直答率", lambda s: s["std_qa_direct"]["rate"]),
    ("  标准QA直答条数", lambda s: s["std_qa_direct"]["n"]),
    ("耗时(s)", lambda s: s["elapsed_sec"]),
    ("LLM 调用", lambda s: s["llm_usage"]["llm_calls"]),
    ("LLM tokens", lambda s: s["llm_usage"]["total_tokens"]),
]


def load(tag: str):
    p = os.path.join(OUT, f"summary_llm_{tag}.json")
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def load_traces(tag: str):
    p = os.path.join(OUT, f"traces_llm_{tag}.jsonl")
    if not os.path.exists(p):
        return {}
    rows = [json.loads(l) for l in open(p, encoding="utf-8").read().strip().split("\n")]
    return {r["test_id"]: r for r in rows}


def fmt(v):
    if isinstance(v, float):
        return f"{v:+.1f}" if False else f"{v:.1f}"
    return str(v)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("tags", nargs="+")
    ap.add_argument("--out", default=None)
    ap.add_argument("--base", default=None, help="基线 tag（默认第一个）")
    ap.add_argument("--flips", action="store_true", help="列出逐条翻转")
    a = ap.parse_args()

    base_tag = a.base or a.tags[0]
    sums = {t: load(t) for t in a.tags}
    L = []
    # 可比性守卫：任一 tag 有失败用例（n 不足）时，通过率不能横向比较——
    # 分母不同会把"少跑了 10 条"读成"涨了 2 个点"。必须显式警告。
    base_n = sums[base_tag]["total"]
    bad = [t for t in a.tags if sums[t]["total"] != base_n or sums[t].get("failures")]
    if bad:
        L.append("> ⚠️ **可比性警告**：以下 tag 的有效用例数不足或有失败用例，"
                 "其通过率与全量（n=%d）**不可直接比较**：%s" % (base_n, ", ".join(bad)))
        L.append("")
    L.append("## 跨轮对比")
    L.append("")
    L.append("| 指标 | " + " | ".join(a.tags) + " |")
    L.append("|---|" + "---|" * len(a.tags))
    for label, fn in ROWS:
        vals = []
        for i, t in enumerate(a.tags):
            try:
                v = fn(sums[t])
            except Exception:  # noqa: BLE001
                v = "-"
            if i > 0 and isinstance(v, (int, float)) and isinstance(fn(sums[base_tag]), (int, float)):
                d = v - fn(sums[base_tag])
                vals.append(f"{v} ({d:+.1f})" if isinstance(d, float) else f"{v} ({d:+d})")
            else:
                vals.append(str(v))
        L.append(f"| {label} | " + " | ".join(vals) + " |")

    # 终端分支分布
    L.append("")
    L.append("### 终端分支分布")
    L.append("")
    L.append("| 终端节点 | " + " | ".join(a.tags) + " |")
    L.append("|---|" + "---|" * len(a.tags))
    keys = []
    for t in a.tags:
        for k in sums[t]["terminal_branch_dist"]:
            if k not in keys:
                keys.append(k)
    for k in keys:
        L.append(f"| {k} | " + " | ".join(str(sums[t]["terminal_branch_dist"].get(k, 0)) for t in a.tags) + " |")
    L.append(f"| **三层兜底合计** | " + " | ".join(
        str(sum(v for k, v in sums[t]["terminal_branch_dist"].items() if "fallback" in k)) for t in a.tags) + " |")

    # 生产缺陷
    L.append("")
    L.append("### 生产缺陷命中数")
    L.append("")
    L.append("| 缺陷标记 | " + " | ".join(a.tags) + " |")
    L.append("|---|" + "---|" * len(a.tags))
    dkeys = []
    for t in a.tags:
        for k in sums[t].get("defects", {}):
            if k not in dkeys:
                dkeys.append(k)
    if not dkeys:
        L.append("| （无） | " + " | ".join("0" for _ in a.tags) + " |")
    for k in dkeys:
        L.append(f"| {k} | " + " | ".join(str(sums[t].get("defects", {}).get(k, 0)) for t in a.tags) + " |")

    # 分层
    for field, title in (("by_layer", "分层"), ("by_priority", "优先级")):
        L.append("")
        L.append(f"### {title}（half 口径）")
        L.append("")
        L.append("| 分组 | n | " + " | ".join(a.tags) + " |")
        L.append("|---|---|" + "---|" * len(a.tags))
        keys = []
        for t in a.tags:
            for k in sums[t][field]:
                if k not in keys:
                    keys.append(k)
        for k in keys:
            n = sums[a.tags[0]][field].get(k, {}).get("n", "-")
            cells = []
            for t in a.tags:
                d = sums[t][field].get(k)
                cells.append(f"{d['half']}" if d else "-")
            L.append(f"| {k} | {n} | " + " | ".join(cells) + " |")

    text = "\n".join(L)
    print(text)

    if a.flips and len(a.tags) > 1:
        bt = load_traces(base_tag)
        for t in a.tags[1:]:
            ct = load_traces(t)
            if not bt or not ct:
                continue
            gain = [i for i in ct if ct[i]["judge"]["half"] and i in bt and not bt[i]["judge"]["half"]]
            lose = [i for i in ct if not ct[i]["judge"]["half"] and i in bt and bt[i]["judge"]["half"]]
            print(f"\n--- {base_tag} -> {t} （half 口径）---")
            print(f"  转通过 {len(gain)}: {sorted(gain)}")
            print(f"  转失败 {len(lose)}: {sorted(lose)}")
            for i in sorted(set(gain + lose)):
                b, c = bt[i], ct[i]
                print(f"    {i:<9} {str(b['terminal_node'])[:30]:<30} -> {str(c['terminal_node'])[:30]:<30} "
                      f"kw {b['judge']['kw_ratio']:.2f}->{c['judge']['kw_ratio']:.2f} "
                      f"禁词 {b['judge']['forbidden_hit']}->{c['judge']['forbidden_hit']}")

    if a.out:
        with open(a.out, "w", encoding="utf-8") as f:
            f.write(text + "\n")
        print(f"\n-> {a.out}")


if __name__ == "__main__":
    main()
