"""逐例路由对比：两个 tag 之间，哪些用例的终端节点变了、变成了什么。

用途：跨轮对比表的汇总数字只告诉你"变没变"，这个工具告诉你"哪些条变了"——
判断一次跑动是「改动生效」还是「LLM 采样噪声」，后者往往表现为几条 borderline 用例
在 `标准QA直答 ↔ 检索后正常作答` 之间来回跳。

用法：
  python diff_runs_cases.py fix_d3 v12_fx
  python diff_runs_cases.py fix_d3 v12_fx --field terminal_node
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding="utf-8")

from trace_util import load_traces  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, "out")


def _get(row, field):
    """支持点号路径，如 `judge.strict` / `fixture.tables`。"""
    cur = row
    for part in field.split("."):
        if not isinstance(cur, dict):
            return None
        cur = cur.get(part)
    return cur


def _key(v):
    """把任意值转成可哈希、可打印的短字符串（list/dict 也能参与迁移矩阵统计）。"""
    if isinstance(v, (list, tuple, dict)):
        s = json.dumps(v, ensure_ascii=False)
    else:
        s = "" if v is None else str(v)
    return s if len(s) <= 46 else s[:46] + "…"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("tag_a")
    ap.add_argument("tag_b")
    ap.add_argument("--field", default="terminal_node")
    ap.add_argument("--show-answer", action="store_true", help="同时打印两侧答案前 120 字")
    args = ap.parse_args()

    A, B = load_traces(OUT, args.tag_a), load_traces(OUT, args.tag_b)
    ids = sorted(set(A) & set(B))
    raw_moved = [(i, _get(A[i], args.field), _get(B[i], args.field))
                 for i in ids if _get(A[i], args.field) != _get(B[i], args.field)]

    print(f"{args.tag_a}  →  {args.tag_b}     共同用例 {len(ids)} 条    字段={args.field}")
    print(f"发生变化的用例：{len(raw_moved)} 条\n")

    trans = Counter((_key(a), _key(b)) for _, a, b in raw_moved)
    print("迁移矩阵（A → B，条数）：")
    for (a, b), n in trans.most_common(15):
        print(f"  {n:3d}  {a or '-'}  →  {b or '-'}")
    if len(trans) > 15:
        print(f"  …（其余 {len(trans) - 15} 种组合）")

    if raw_moved:
        print("\n逐例明细：")
        for tid, a, b in raw_moved:
            ha, hb = A[tid]["judge"]["half"], B[tid]["judge"]["half"]
            print(f"  {tid:<10} A={_key(a)}")
            print(f"  {'':<10} B={_key(b)}      half {ha} → {hb}")
            if args.show_answer:
                print(f"       A答案: {(A[tid].get('answer') or '')[:110]}")
                print(f"       B答案: {(B[tid].get('answer') or '')[:110]}")

    print("\n参照（本评测台实测的运行间波动，用来区分「改动生效」与「采样噪声」）：")
    print("  - 离散字段（terminal_node / 字段是否写入）：不受采样影响，变化即可归因于改动。")
    print("  - 指标（strict/half/anyhit）：同配置两次跑极差 0.8 / 0.9 / 1.7pt。")
    print("  - 上游 LLM 字段（split_questions / query_rewrite）：同配置两次跑约 20% 的用例会不同，")
    print("    进而让「标准QA直答 ↔ 检索后正常作答」这类 borderline 路由来回跳——**不能算改动效果**。")


if __name__ == "__main__":
    main()
