"""给指定用例追加 requires_handoff 标记（P0'：必须转人工 硬门）。

用法：
  python add_requires_handoff.py --ids TC-C02,TC-C01
仅对确实缺少该字段的用例追加，已存在则不动；幂等。
"""
from __future__ import annotations
import argparse
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT = os.path.join(HERE, "..", "data", "testset_118.v1.2.jsonl")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ids", default="TC-C02", help="逗号分隔的 test_id")
    ap.add_argument("--path", default=DEFAULT)
    args = ap.parse_args()
    want = {s.strip() for s in args.ids.split(",") if s.strip()}

    lines = [l for l in open(args.path, encoding="utf-8").read().split("\n") if l.strip()]
    out, changed = [], []
    for ln in lines:
        o = json.loads(ln)
        if o.get("test_id") in want and not o.get("requires_handoff"):
            o["requires_handoff"] = True
            changed.append(o["test_id"])
        out.append(json.dumps(o, ensure_ascii=False))
    open(args.path, "w", encoding="utf-8").write("\n".join(out) + "\n")

    print("CHANGED:", changed or "none")
    for o in (json.loads(l) for l in open(args.path, encoding="utf-8") if l.strip()):
        if o.get("test_id") in want:
            print(f"  {o['test_id']} requires_handoff={o.get('requires_handoff')}")


if __name__ == "__main__":
    main()
