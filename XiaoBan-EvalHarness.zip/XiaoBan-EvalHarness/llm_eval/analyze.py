"""
小办 · 真实 LLM 评测 · 归因分析
========================================================
把 118 条的三口径结果拆开归因：
  1. 标准QA直答 vs 走检索 两条路径的得分差异
  2. 期望词里「路径/步骤类」词 vs 「结论类」词的命中率差异 → 验证三要素缺失缺陷
  3. 漏得最多的期望词 TOP
  4. 路由层兜底 0 触发的量化证据
  5. 生产缺陷影响面
"""
from __future__ import annotations

import collections
import json
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, "out")

TAG = sys.argv[1] if len(sys.argv) > 1 else "full"

traces = [json.loads(l) for l in
          open(os.path.join(OUT, f"traces_llm_{TAG}.jsonl"), encoding="utf-8").read().strip().split("\n")]
cases = {c["test_id"]: c for c in
         [json.loads(l) for l in open(os.path.join(ROOT, "data", "testset_118.v1.1.jsonl"),
                                      encoding="utf-8").read().strip().split("\n")]}
n = len(traces)
print(f"用例 {n} 条（tag={TAG}）\n")

# 期望词的语义分类
PATH_WORDS = ["飞书", "路径", "入口", "步骤", "提交", "申请", "审批", "填", "选择", "上传",
              "菜单", "模块", "表单"]


def is_path_word(k: str) -> bool:
    return any(w in k for w in PATH_WORDS)


# ---------------- 1. 两条路径拆解 ----------------
def bucket(r):
    return "标准QA直答" if (r["terminal_node"] or "").startswith("normal_answer(标准QA直答)") else "走检索+LLM"


groups = collections.defaultdict(list)
for r in traces:
    groups[bucket(r)].append(r)

print("=" * 78)
print("1) 两条路径的三口径对比")
print("=" * 78)
print(f"  {'路径':<14} {'n':>4} {'strict':>8} {'half':>8} {'anyhit':>8} {'禁词命中':>8} {'均字数':>7}")
for k in ("标准QA直答", "走检索+LLM"):
    rs = groups.get(k, [])
    if not rs:
        continue
    m = len(rs)
    print(f"  {k:<14} {m:>4} "
          f"{sum(1 for r in rs if r['judge']['strict']) / m * 100:>7.1f}% "
          f"{sum(1 for r in rs if r['judge']['half']) / m * 100:>7.1f}% "
          f"{sum(1 for r in rs if r['judge']['anyhit']) / m * 100:>7.1f}% "
          f"{sum(1 for r in rs if r['judge']['forbidden_hit']) / m * 100:>7.1f}% "
          f"{sum(len(r['answer']) for r in rs) / m:>7.0f}")

# ---------------- 2. 期望词按语义拆分命中率 ----------------
print()
print("=" * 78)
print("2) 期望词命中率：结论类 vs 路径/步骤类")
print("=" * 78)


def kw_hit_rate(rows, predicate):
    tot = hit = 0
    for r in rows:
        c = cases[r["test_id"]]
        exp = [k for k in (c.get("expected_keywords") or []) if k]
        for k in exp:
            if not predicate(k):
                continue
            tot += 1
            if k in r["answer"]:
                hit += 1
    return hit, tot, (hit / tot * 100 if tot else 0.0)


for label, rows in (("全部", traces),
                    ("标准QA直答", groups.get("标准QA直答", [])),
                    ("走检索+LLM", groups.get("走检索+LLM", []))):
    h1, t1, r1 = kw_hit_rate(rows, lambda k: not is_path_word(k))
    h2, t2, r2 = kw_hit_rate(rows, is_path_word)
    print(f"  {label:<12} 结论类 {h1:>4}/{t1:<4} = {r1:>5.1f}%   "
          f"路径/步骤类 {h2:>4}/{t2:<4} = {r2:>5.1f}%   "
          f"差 {r1 - r2:>5.1f}pt")

# ---------------- 3. 漏得最多的期望词 ----------------
print()
print("=" * 78)
print("3) 漏得最多的期望词（TOP 20，按漏的次数）")
print("=" * 78)
miss_counter = collections.Counter()
miss_by_group = collections.defaultdict(collections.Counter)
for r in traces:
    g = bucket(r)
    for k in r["judge"]["missed"]:
        miss_counter[k] += 1
        miss_by_group[g][k] += 1
for k, v in miss_counter.most_common(20):
    tag = "路径类" if is_path_word(k) else "结论类"
    print(f"  {k:<22} 漏 {v:>3} 次  [{tag}]  标准QA直答漏 {miss_by_group['标准QA直答'][k]:>3} / "
          f"走检索漏 {miss_by_group['走检索+LLM'][k]:>3}")

# ---------------- 4. 路由层兜底证据 ----------------
print()
print("=" * 78)
print("4) 路由层兜底触发情况（量化证据）")
print("=" * 78)
term = collections.Counter((r["terminal_node"] or "?") for r in traces)
for k, v in term.most_common():
    print(f"  {k:<34} {v:>3} ({v / n * 100:5.1f}%)")
node_names = collections.Counter(
    nd["node"] for r in traces for nd in r["trace"]["nodes"])
print("\n  各节点被执行的次数（118 条中）:")
for k, v in node_names.most_common():
    print(f"    {k:<28} {v:>3}")
hvc = sum(1 for r in traces if r.get("has_valid_content"))
print(f"\n  has_valid_content=True : {hvc}/{n}  ({hvc / n * 100:.1f}%)")
route = collections.Counter(str(r.get("route_branch")) for r in traces)
print(f"  condition_check 输出    : {dict(route)}")
top = [float(r["top_score"]) for r in traces if r.get("top_score") is not None]
if top:
    top_sorted = sorted(top)
    m = len(top_sorted)
    print(f"  top_score（走检索的 {m} 条）: min {top_sorted[0]:.3f}  中位 {top_sorted[m//2]:.3f}  "
          f"max {top_sorted[-1]:.3f}   >=0.6 占比 {sum(1 for t in top if t >= 0.6)/m*100:.1f}%")

# ---------------- 5. 缺陷影响面 ----------------
print()
print("=" * 78)
print("5) 生产缺陷影响面")
print("=" * 78)
defect = collections.Counter(f for r in traces for f in (r.get("defect_flags") or []))
for k, v in defect.most_common():
    print(f"  {k:<34} {v:>3}/{n}  ({v / n * 100:5.1f}%)")
std_raw = [r for r in traces if "stdqa_answer_text_is_dict" in (r.get("defect_flags") or [])]
if std_raw:
    print(f"\n  受影响用例实际产出的答案体（前 2 条原样）:")
    for r in std_raw[:2]:
        nd = next((x for x in r["trace"]["nodes"] if x["node"] == "normal_answer"), None)
        if nd:
            print(f"    {r['test_id']}: {json.dumps(nd['out'].get('normal_answer'), ensure_ascii=False)[:220]}")

# ---------------- 6. 过报与欠报 ----------------
print()
print("=" * 78)
print("6) 过报 / 欠报")
print("=" * 78)
over = [(r["test_id"], cases[r["test_id"]].get("test_dimension"), r["judge"]["forbidden_hit"])
        for r in traces if r["judge"]["forbidden_hit"]]
print(f"  过报（命中禁词）{len(over)} 条：")
for tid, dim, bad in over:
    print(f"    {tid:<9} [{dim}]  禁词命中 {bad}")
fb = [r for r in traces if r["judge"]["is_fallback_answer"]]
print(f"\n  输出兜底话术 {len(fb)} 条，其中终端节点分布：")
for k, v in collections.Counter(r["terminal_node"] for r in fb).most_common():
    print(f"    {k:<34} {v}")

# ---------------- 7. 归档不一致用例 ----------------
print()
print("=" * 78)
print("7) 与归档判定不一致的用例（按维度统计）")
print("=" * 78)
mism = collections.Counter()
for r in traces:
    c = cases[r["test_id"]]
    v = (c.get("verdict_coze") or "").strip().lower()
    if v in ("pass", "半pass") and not r["judge"]["half"]:
        mism[c.get("test_dimension")] += 1
print(f"  归档 pass 但本地 half 不通过：{sum(mism.values())} 条")
for k, v in mism.most_common():
    print(f"    {k:<26} {v}")
