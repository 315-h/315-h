"""判官自评偏差矩阵：同一条用例分别由两个模型作答，再让两个判官交叉评。

为什么要这么做（这是「换跨厂商判官」的**目的**）：
  只比"两个判官在标注集上一致"是不够的——那只能说明它们看同一件事。
  真正要量化的是：**判官会不会偏袒自己厂商生成的答案**（self-preference bias）。

  做法（经典 2×2 设计）：
     行 = 答案作者（deepseek / qwen）
     列 = 判官（deepseek / qwen）
     格 = 通过率
    自评偏差 = mean(通过 | 同行同列) − mean(通过 | 跨行跨列)

用法（`--pair` 可重复，用同一份语料/同一份 fixture 跑出的两轮 trace）：
  python bias_matrix.py --pair v12_fx2 v12_fx_qwengen --pair fixture_conflict fc_qwengen
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from typing import Any, Dict, List, Tuple

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding="utf-8")

import semantic_judge as SJ  # noqa: E402
from trace_util import load_traces  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, "out")


def _summary(tag: str) -> Dict[str, Any]:
    p = os.path.join(OUT, f"summary_llm_{tag}.json")
    return json.load(open(p, encoding="utf-8")) if os.path.exists(p) else {}


def author_of(tag: str) -> str:
    """从该轮 summary 里读生成后端（作者是谁）。

    ⚠️ 兼容历史轮次：`generation_backend` 字段是本次才加的；此前的轮次全部是 DeepSeek 生成，
       缺字段时按 deepseek 处理，不能返回 unknown（否则整个矩阵对不上）。
    """
    s = _summary(tag)
    gb = s.get("generation_backend") or {}
    return gb.get("backend") or "deepseek"


def model_of_author(tag: str) -> str:
    s = _summary(tag)
    gb = s.get("generation_backend") or {}
    b = gb.get("backend") or "deepseek"
    return gb.get("model") or (SJ.JUDGES.get(b, {}).get("model_default") or "?")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pair", nargs=2, action="append", required=True,
                    metavar=("TAG_A", "TAG_B"),
                    help="两轮 trace，差异应只在生成后端；可重复")
    ap.add_argument("--judges", default="deepseek,qwen")
    ap.add_argument("--show-answers", action="store_true")
    args = ap.parse_args()

    judges = [s.strip() for s in args.judges.split(",") if s.strip()]
    cfg = SJ.load_checks()

    def auth_label(backend: str, tag: str) -> str:
        return f"{backend}/{model_of_author(tag)}"

    author_label: Dict[str, str] = {}
    for _ta, _tb in args.pair:
        author_label[author_of(_ta)] = auth_label(author_of(_ta), _ta)
        author_label[author_of(_tb)] = auth_label(author_of(_tb), _tb)

    rows: List[Dict[str, Any]] = []
    for tag_a, tag_b in args.pair:
        aa, ab = author_of(tag_a), author_of(tag_b)
        ta, tb = load_traces(OUT, tag_a), load_traces(OUT, tag_b)
        ids = sorted(set(ta) & set(tb))
        print(f"组合 {tag_a}(作者={aa}) × {tag_b}(作者={ab}) → 共同用例 {ids}")
        for tid in ids:
            checks = SJ.checks_for(cfg, tid)
            for author, rec in ((aa, ta[tid]), (ab, tb[tid])):
                answer = rec.get("answer") or ""
                row = {"test_id": tid, "author": author, "terminal_node": rec.get("terminal_node"),
                       "answer": answer, "judge": {}}
                for jb in judges:
                    r = SJ.judge_semantic(rec.get("query") or "", answer, checks, backend=jb)
                    row["judge"][jb] = {"pass": r["passed"], "failed": r["failed"],
                                        "evidence": r["evidence"], "cached": r["cached"]}
                rows.append(row)
        print()

    if not rows:
        print("没有可比用例")
        return 1

    print("=" * 78)
    print("判官 × 答案作者 —— 通过情况")
    print("=" * 78)
    head = f"  {'用例':<10} {'作者':<20} " + " ".join(f"{j:<10}" for j in judges) + " 终端节点"
    print(head)
    for r in rows:
        cells = " ".join(f"{('PASS' if r['judge'][j]['pass'] else 'FAIL'):<10}" for j in judges)
        print(f"  {r['test_id']:<10} {author_label.get(r['author'], r['author']):<20} {cells} "
              f"{r['terminal_node']}")

    print()
    print("=" * 78)
    print("2×2 偏差矩阵（通过率）")
    print("=" * 78)
    print(f"  {'答案作者 ↓ ／ 判官 →':<28} " + " ".join(f"{j:<12}" for j in judges))
    same, cross, n_same, n_cross = 0, 0, 0, 0
    for a in sorted({r["author"] for r in rows}):
        cells = []
        for j in judges:
            sub = [r for r in rows if r["author"] == a]
            p = sum(1 for r in sub if r["judge"][j]["pass"])
            cells.append(f"{p}/{len(sub)}")
            if a == j:
                same += p
                n_same += len(sub)
            else:
                cross += p
                n_cross += len(sub)
        print(f"  {author_label.get(a, a):<28} " + " ".join(f"{c:<12}" for c in cells))

    print()
    print("=" * 78)
    print("自评偏差")
    print("=" * 78)
    if n_same and n_cross:
        r_same, r_cross = same / n_same, cross / n_cross
        print(f"  「自己人评自己人」通过率：{same}/{n_same} = {r_same * 100:.1f}%")
        print(f"  「跨厂商评」通过率      ：{cross}/{n_cross} = {r_cross * 100:.1f}%")
        d = (r_same - r_cross) * 100
        print(f"  偏差（同厂商 − 跨厂商）= {d:+.1f}pt")
        print()
        if abs(d) < 1e-9:
            print("  结论：本批样本上**未观察到自评偏差**（两条对角线完全一致）。")
        else:
            print("  结论：**存在自评偏差** —— 同厂商判官对自家答案更宽容。")
    else:
        print("  样本不足，无法计算。")

    dis = [(r["test_id"], r["author"],
            {j: r["judge"][j]["pass"] for j in judges})
           for r in rows if len({r["judge"][j]["pass"] for j in judges}) > 1]
    if dis:
        print(f"\n  判官之间分歧的 (用例, 作者) 组合 {len(dis)} 个：")
        for tid, a, v in dis:
            print(f"    {tid} · 作者={a} · {json.dumps(v, ensure_ascii=False)}")

    if args.show_answers:
        print("\n" + "=" * 78)
        print("各 (用例, 作者) 的实际答案")
        print("=" * 78)
        for tid in sorted({r["test_id"] for r in rows}):
            for r in [x for x in rows if x["test_id"] == tid]:
                verdicts = {j: ("PASS" if r["judge"][j]["pass"] else "FAIL") for j in judges}
                print(f"\n▶ {tid} · 作者={author_label.get(r['author'], r['author'])} · "
                      f"终端={r['terminal_node']} · 判官={json.dumps(verdicts, ensure_ascii=False)}")
                print(r["answer"][:700])

    out = os.path.join(OUT, "bias_matrix.json")
    json.dump({"rows": [{k: v for k, v in r.items() if k != "answer"} | {"answer": r["answer"][:800]}
                        for r in rows],
               "self_preference_delta_pt": round((same / n_same - cross / n_cross) * 100, 1)
               if n_same and n_cross else None,
               "judges": judges},
              open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"\n-> {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
