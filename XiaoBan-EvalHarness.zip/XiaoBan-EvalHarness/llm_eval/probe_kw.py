"""
关键词路得分探针（零 LLM 成本，复用 llm_cache 回放改写/分类）。
目的：为 D5 选一个「有数据支撑」的门限，并分别验证两个候选杠杆：
  A. retrieval.keyword_min_score —— 关键词路的嵌入相似度门限（MIN_SCORE）
  B. kw_score 门限 —— 关键词词典命中率门限（原 D5 ticket 设想的修法）
用法：
  python probe_kw.py [tag]

注意：判有效性的辅助函数一律取参数，不要在 for 循环里定义后再在循环外调用
（闭包晚期绑定会全部落到最后一条用例上，扫描结果会假性"零变化"）。
"""
from __future__ import annotations

import collections
import importlib
import json
import os
import sys
from typing import Any, Dict, List, Tuple

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import harness as H  # noqa: E402

H.STORE.load()
S = H.load_states()
MRG = importlib.import_module("graphs.nodes.merge_retrieval_node")
is_title_only = MRG._is_title_only

TAG = sys.argv[1] if len(sys.argv) > 1 else "full"
cache_path = os.path.join(H.CACHE_DIR, f"llm_cache_{TAG}.json")
cache = json.load(open(cache_path, encoding="utf-8"))
cases = [json.loads(l) for l in
         open(os.path.join(os.path.dirname(H.EVAL_DIR), "data", "testset_118.v1.1.jsonl"),
              encoding="utf-8").read().strip().split("\n")]

Node = lambda mod, fn: H.load_node(mod, fn)  # noqa: E731


def valid_row(row: Dict[str, Any], t: float) -> bool:
    """把关键词路的嵌入相似度门限提到 t 之后，该用例的 has_valid_content 是否仍成立。"""
    for _s, content in row["vec"]:
        if content and not is_title_only(content):
            return True
    for s, _k, content in row["kw"]:
        if s >= t and content and not is_title_only(content):
            return True
    return False


def valid_row_kwscore(row: Dict[str, Any], t: float) -> bool:
    """把关键词词典命中率门限提到 t 之后，该用例的 has_valid_content 是否仍成立。"""
    for _s, content in row["vec"]:
        if content and not is_title_only(content):
            return True
    for _s, k, content in row["kw"]:
        if k >= t and content and not is_title_only(content):
            return True
    return False


rows: List[Dict[str, Any]] = []
for c in cases:
    cached = cache.get(c["test_id"])
    if not cached:
        continue
    g = {
        "user_input": c.get("query") or "",
        "query_rewrite": cached.get("query_rewrite", ""),
        "split_questions": cached.get("split_questions", []),
        "biz_type": cached.get("biz_type", "其他"),
        "biz_types": cached.get("biz_types", []),
    }
    qa = H.call_node(Node("standard_qa_match_node", "standard_qa_match_node"), S.StandardQaMatchInput, g)
    g.update(qa.model_dump())
    if qa.all_sub_questions_hit:
        rows.append({"id": c["test_id"], "std": True})
        continue

    vr = H.call_node(Node("vector_retrieval_node", "vector_retrieval_node"), S.VectorRetrievalInput, g)
    g.update(vr.model_dump())
    kr = H.call_node(Node("keyword_retrieval_node", "keyword_retrieval_node"), S.KeywordRetrievalInput, g)
    g.update(kr.model_dump())
    mg = H.call_node(Node("merge_retrieval_node", "merge_retrieval_node"), S.MergeRetrievalInput, g)

    vec: List[Tuple[float, str]] = [(float(x.get("score") or 0), x.get("content", ""))
                                    for x in (vr.vector_chunks or [])]
    kw: List[Tuple[float, float, str]] = [(float(x.get("score") or 0),
                                           float(x.get("kw_score") or 0),
                                           x.get("content", ""))
                                          for x in (kr.keyword_chunks or [])]

    rows.append({
        "id": c["test_id"], "std": False, "vec": vec, "kw": kw,
        "top": float(mg.top_score or 0),
        "vscore": float(vr.vector_score or 0),
        "has_valid": bool(mg.has_valid_content),
        "vec_valid": any(content and not is_title_only(content) for _s, content in vec),
    })

std_rows = [r for r in rows if r["std"]]
ret_rows = [r for r in rows if not r["std"]]
print(f"tag={TAG}  用例 {len(rows)} 条：标准QA直答 {len(std_rows)} 条（不参与本探针），走检索 {len(ret_rows)} 条\n")

all_kw = sorted(k for r in ret_rows for _s, k, _c in r["kw"])
all_sc = sorted(s for r in ret_rows for s, _k, _c in r["kw"])

print("=== 关键词片段 kw_score 分布（词典命中率）===")
if all_kw:
    n = len(all_kw)
    print(f"  片段总数 {n}（平均每例 {n / len(ret_rows):.1f} 片）")
    print(f"  min={all_kw[0]:.4f} 中位={all_kw[n // 2]:.4f} max={all_kw[-1]:.4f}")
    print("  分位：" + "  ".join(f"p{int(q * 100)}={all_kw[min(n - 1, int(n * q))]:.4f}"
                                for q in (0.05, 0.1, 0.25, 0.5, 0.75, 0.9)))
    bk = collections.Counter()
    for s in all_kw:
        bk["<0.1" if s < 0.1 else "[0.1,0.15)" if s < 0.15 else "[0.15,0.2)" if s < 0.2
           else "[0.2,0.25)" if s < 0.25 else "[0.25,0.3)" if s < 0.3 else ">=0.3"] += 1
    for k in ("<0.1", "[0.1,0.15)", "[0.15,0.2)", "[0.2,0.25)", "[0.25,0.3)", ">=0.3"):
        print(f"    {k:<14} {bk.get(k, 0)}")

print("\n=== 关键词片段的嵌入相似度 score 分布（keyword_min_score 的作用对象）===")
if all_sc:
    n = len(all_sc)
    print(f"  min={all_sc[0]:.4f} 中位={all_sc[n // 2]:.4f} max={all_sc[-1]:.4f}")
    print("  分位：" + "  ".join(f"p{int(q * 100)}={all_sc[min(n - 1, int(n * q))]:.4f}"
                                for q in (0.05, 0.1, 0.25, 0.5, 0.75, 0.9)))
    for th in (0.3, 0.4, 0.5, 0.55, 0.6, 0.65, 0.7):
        c = sum(1 for s in all_sc if s >= th)
        print(f"    >= {th:.2f} : {c:3d}/{n}  ({c / n * 100:5.1f}%)")

print("\n=== 向量路能否独立支撑 has_valid ===")
vonly = sum(1 for r in ret_rows if r["vec_valid"])
print(f"  向量路独立有效：{vonly}/{len(ret_rows)} 条")
print(f"  向量路无有效内容（完全依赖关键词路）：{len(ret_rows) - vonly} 条")
print("  D5 的真正作用域：", [r["id"] for r in ret_rows if not r["vec_valid"]])
print(f"  向量路一条片段都没召回：{sum(1 for r in ret_rows if not r['vec'])} 条")

print("\n=== 扫描 A：retrieval.keyword_min_score（嵌入相似度门限）===")
print(f"  {'门限':<8} {'仍有效':<8} {'翻成无效':<10} 翻成无效的用例")
for t in (0.0, 0.3, 0.4, 0.5, 0.55, 0.6, 0.65, 0.7, 0.75):
    flip = [r["id"] for r in ret_rows if r["has_valid"] and not valid_row(r, t)]
    print(f"  {t:<8} {len(ret_rows) - len(flip):<8} {len(flip):<10} {flip if flip else ''}")

print("\n=== 扫描 B：kw_score 门限（原 D5 ticket 设想的修法）===")
print(f"  {'门限':<8} {'仍有效':<8} {'翻成无效':<10} 翻成无效的用例")
for t in (0.0, 0.1, 0.15, 0.2, 0.25, 0.3, 0.33):
    flip = [r["id"] for r in ret_rows if r["has_valid"] and not valid_row_kwscore(r, t)]
    print(f"  {t:<8} {len(ret_rows) - len(flip):<8} {len(flip):<10} {flip if flip else ''}")

print("\n=== D5 作用域用例明细（向量路为空，全靠关键词路）===")
print(f"  {'用例':<10} {'向量最高分':<10} {'关键词片段数':<10} {'关键词最高相似度':<12} {'关键词最高kw':<10}")
for r in ret_rows:
    if not r["vec_valid"]:
        print(f"  {r['id']:<10} {r['vscore']:<10.4f} {len(r['kw']):<10} "
              f"{(max((s for s, _k, _c in r['kw']), default=0)):<12.4f} "
              f"{(max((k for _s, k, _c in r['kw']), default=0)):<10.4f}")
