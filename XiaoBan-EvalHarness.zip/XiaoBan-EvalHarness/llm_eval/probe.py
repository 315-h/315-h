"""探针：验证替身能加载生产节点，并查看真实相似度分布（决定 0.6 阈值是否有意义）。"""
import json
import os
import sys
import traceback

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harness as H  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8")

print("=" * 70)
print("1) 替身注入 + 生产节点加载")
print("=" * 70)
nodes = [
    ("query_rewrite_node", "query_rewrite_node"),
    ("split_and_classify_node", "split_and_classify_node"),
    ("standard_qa_match_node", "standard_qa_match_node"),
    ("vector_retrieval_node", "vector_retrieval_node"),
    ("keyword_retrieval_node", "keyword_retrieval_node"),
    ("merge_retrieval_node", "merge_retrieval_node"),
    ("rule_conflict_check_node", "rule_conflict_check_node"),
    ("secondary_retrieval_node", "secondary_retrieval_node"),
    ("condition_check_node", "condition_check_node"),
    ("normal_answer_node", "normal_answer_node"),
    ("mid_fallback_answer_node", "mid_fallback_answer_node"),
    ("fallback_answer_node", "fallback_answer_node"),
    ("conflict_fallback_answer_node", "conflict_fallback_answer_node"),
]
loaded = {}
for mod, fn in nodes:
    try:
        loaded[fn] = H.load_node(mod, fn)
        print(f"  OK   {fn}")
    except Exception as e:
        print(f"  FAIL {fn}: {type(e).__name__}: {e}")

S = H.load_states()
print(f"\n  state 模型: {len([k for k in dir(S) if not k.startswith('_')])} 个符号")

print()
print("=" * 70)
print("2) 语料加载 + 真实相似度分布")
print("=" * 70)
H.STORE.load()
docs = H.STORE.tables["standard_qa_kb"]
print(f"  语料: {len(docs)} 篇  |  嵌入缓存: {len(H.STORE.embedder._cache)} 条")

cases_path = os.path.join(os.path.dirname(H.EVAL_DIR), "data", "testset_118.v1.1.jsonl")
if not os.path.exists(cases_path):
    cases_path = os.path.join(os.path.dirname(H.EVAL_DIR), "data", "testset_118.jsonl")
cases = [json.loads(l) for l in open(cases_path, encoding="utf-8").read().strip().split("\n")]
print(f"  测试集: {len(cases)} 条  <- {os.path.basename(cases_path)}")

# 每条用例：原始 query 对全库的 top1 相似度
qs = [c["query"] for c in cases if isinstance(c.get("query"), str) and c.get("query")]
sims = []
for q in qs:
    hits = H.STORE.search("coze_doc_knowledge", q, top_k=1)
    if hits:
        sims.append(hits[0].score)
sims_sorted = sorted(sims)
n = len(sims_sorted)
print(f"\n  样本 n={n}  min={sims_sorted[0]:.4f}  p25={sims_sorted[n//4]:.4f}  "
      f"中位={sims_sorted[n//2]:.4f}  p75={sims_sorted[3*n//4]:.4f}  max={sims_sorted[-1]:.4f}")

for th in (0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.75, 0.8):
    over = sum(1 for s in sims if s >= th)
    print(f"    >= {th:.2f} : {over:3d}/{n}  ({over/n*100:5.1f}%)")

print("\n  相似度分箱:")
bins = [(0.0, 0.3), (0.3, 0.4), (0.4, 0.5), (0.5, 0.6), (0.6, 0.7), (0.7, 0.8), (0.8, 1.01)]
for lo, hi in bins:
    c = sum(1 for s in sims if lo <= s < hi)
    print(f"    [{lo:.1f},{hi:.1f}) {c:3d}  {'#' * c}")

print()
print("=" * 70)
print("3) 端到端冒烟：3 条用例真跑（真 LLM + 真向量）")
print("=" * 70)
import run_pipeline as RP  # noqa: E402

for c in cases[:3]:
    try:
        t = RP.run_case(c, keep_trace=True)
        print(f"\n  --- {c['test_id']} | {c['query'][:40]}")
        print(f"      分支={t['terminal_node']}  标准QA命中={t['standard_hit']}  "
              f"top_score={t['top_score']}  耗时={t['elapsed_ms']}ms")
        ans = (t["answer"] or "").replace("\n", " ")
        print(f"      判定: strict={t['judge']['strict']} half={t['judge']['half']} "
              f"anyhit={t['judge']['anyhit']} | 命中词={t['judge']['hit']} 漏={t['judge']['missed']}")
        print(f"      答案前 150 字: {ans[:150]}")
    except Exception as e:
        print(f"\n  --- {c['test_id']} 失败: {type(e).__name__}: {e}")
        traceback.print_exc()

print()
print("  LLM 用量:", json.dumps(H.USAGE.snapshot(), ensure_ascii=False))
