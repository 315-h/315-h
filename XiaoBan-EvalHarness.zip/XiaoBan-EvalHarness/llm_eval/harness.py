"""
小办 · 真实 LLM 评测台（本地复现版工作流）
========================================================
设计原则：**节点代码不重写，直接复用生产源码**。

做法：
  1. 用 sys.modules 注入替身，冒充 Coze 运行时：
       - coze_coding_utils.runtime_ctx.context  -> Context / new_context
       - coze_coding_dev_sdk                    -> LLMClient / KnowledgeClient / Config
       - langgraph.runtime                      -> Runtime（可下标）
       - graphs / graphs.nodes                  -> 指向 Desktop 源码树（真源码）
  2. 只替换两类外部依赖：
       - LLM      -> DeepSeek（真实 HTTP）
       - 知识库   -> Qwen text-embedding-v3 真实向量 + 余弦检索（本地语料）
  3. 其余 11 个节点的路由/合并/冲突/兜底逻辑 = 生产源码原样执行。

诚实口径：
  - `coze_doc_knowledge` 的原始制度文档本地不可得，用 63 篇标准问答文档本体作替代语料
    （CORPUS_NOTE 会在报告里显式披露）。
  - 本评测台是**可复现 + 带 trace 的真实模型评测**，但**不等于**扣子线上工作流。
"""
from __future__ import annotations

import concurrent.futures as _cf  # noqa: F401  (预留给调用方)
import hashlib
import json
import math
import os
import sys
import threading
import time
import types
import urllib.request
from typing import Any, Dict, List, Optional

# ============================================================
# 路径与常量
# ============================================================
SRC_DIR = r"C:\Users\Lenovo\Desktop\小办源文件\xiaoban-workflow-src"
NODES_DIR = os.path.join(SRC_DIR, "nodes")
KB_DIR = os.path.join(SRC_DIR, "standard_qa_kb")
CONFIG_DIR = os.path.join(SRC_DIR, "config")

EVAL_DIR = os.path.dirname(os.path.abspath(__file__))
CACHE_DIR = os.path.join(EVAL_DIR, "cache")

CORPUS_NOTE = (
    "coze_doc_knowledge 的原始制度文档在本地不可得；"
    "本评测台以 63 篇标准问答文档（standard_qa_kb）本体作为替代语料。"
    "因此 retrieval.vector_min_score 的扫描反映的是「真实相似度分布下的阈值行为」，"
    "而非线上知识库的绝对分值。"
)

# 语料变体（消融实验用）：
#   full  —— 文档 = 原问题 + 同义问法 + 答案 + 路径 + 步骤 + 来源（含答案侧）
#   qonly —— 文档 = 原问题 + 同义问法（仅问题侧，模拟「检索到标题/条目、正文未知」）
CORPUS_VARIANT = os.getenv("XIAOBAN_CORPUS_VARIANT", "full").strip() or "full"

# 按用例语料注入（fixture）：
#   某些用例的场景在基础语料里**不存在**（例如「制度冲突校验」维度需要两份互相矛盾
#   的制度文档）。它们靠关键词判定永远测不出来，因为模型无从"看到"冲突。
#   这里提供按用例的语料覆盖能力：注入补充文档 / 排除既有文档，仅对该用例的检索生效。
#
#   用法：run_eval.py --fixtures data/corpus_fixtures.json
#   传递：thread-local（每条用例在单个 worker 线程内跑完，用完即清，不会串味）
_FIXTURES: Dict[str, Dict[str, Any]] = {}
_FX_LOCAL = threading.local()
_FX_DOC_CACHE: Dict[str, List[Dict[str, Any]]] = {}


def load_fixtures(path: Optional[str]) -> Dict[str, Dict[str, Any]]:
    """加载 fixture 文件；路径为空/不存在 → 清空（等价于不启用）。"""
    global _FIXTURES
    if not path or not os.path.exists(path):
        _FIXTURES = {}
        return _FIXTURES
    raw = json.load(open(path, encoding="utf-8"))
    _FIXTURES = {k: v for k, v in raw.items()
                 if not k.startswith("_") and isinstance(v, dict)}
    return _FIXTURES


def fixture_of(test_id: str) -> Optional[Dict[str, Any]]:
    return _FIXTURES.get(test_id)


def set_active_fixture(fx: Optional[Dict[str, Any]]) -> None:
    _FX_LOCAL.fixture = fx


def clear_active_fixture() -> None:
    _FX_LOCAL.fixture = None


def active_fixture() -> Optional[Dict[str, Any]]:
    return getattr(_FX_LOCAL, "fixture", None)


def describe_fixture(fx: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """给 trace 用的 fixture 摘要（证明"这条用例跑了哪套语料"）。"""
    if not fx:
        return {"applied": False}
    tables = {}
    for table, spec in (fx.get("tables") or {}).items():
        tables[table] = {"append": len(spec.get("append") or []),
                         "exclude": list(spec.get("exclude") or [])}
    return {"applied": True, "why": fx.get("why", ""), "tables": tables}


def _ensure_dirs():
    os.makedirs(CACHE_DIR, exist_ok=True)


# ============================================================
# 1. Coze 运行时替身
# ============================================================
class Context:
    """替身：生产代码只把它透传给 SDK，从不读属性。"""
    run_id = ""

    def __init__(self, **kwargs):
        self.run_id = kwargs.get("run_id") or uuid_like()


def uuid_like() -> str:
    import uuid
    return uuid.uuid4().hex


def new_context(method: str = "", headers: Any = None) -> Context:
    return Context(method=method)


class _Runtime:
    """替身 langgraph.runtime.Runtime，支持 Runtime[Context] 下标。"""
    def __init__(self, context: Optional[Context] = None):
        self.context = context or Context()

    def __class_getitem__(cls, item):  # noqa: N805
        return cls


RUNTIME = _Runtime()


class Config:
    """替身 coze_coding_dev_sdk.Config —— 生产代码无参构造。"""
    pass


# ----------------------------------------------
# 1.1 LLM 客户端替身 -> DeepSeek
# ----------------------------------------------
class _UsageLedger:
    def __init__(self):
        self.lock = threading.Lock()
        self.calls = 0
        self.prompt_tokens = 0
        self.completion_tokens = 0
        self.errors = 0
        self.per_model: Dict[str, int] = {}

    def add(self, model: str, pt: int, ct: int, err: bool = False):
        with self.lock:
            self.calls += 1
            self.prompt_tokens += pt
            self.completion_tokens += ct
            self.per_model[model] = self.per_model.get(model, 0) + 1
            if err:
                self.errors += 1

    def snapshot(self) -> Dict[str, Any]:
        with self.lock:
            return {
                "llm_calls": self.calls,
                "prompt_tokens": self.prompt_tokens,
                "completion_tokens": self.completion_tokens,
                "total_tokens": self.prompt_tokens + self.completion_tokens,
                "errors": self.errors,
                "calls_per_model": dict(self.per_model),
            }


USAGE = _UsageLedger()


class _LLMResponse:
    def __init__(self, content: str, raw: Dict[str, Any]):
        self.content = content
        self.raw = raw


# 生成侧后端（可切厂商）。用途有两块：
#   ① 跨模型鲁棒性探针：被测系统换模型后，行为是否一致；
#   ② 量化判官的**自评偏差**：需要"同一条用例分别由两个模型作答"，再让两个判官去评。
# 用法：XIAOBAN_LLM_BACKEND=qwen ...
LLM_BACKENDS: Dict[str, Dict[str, str]] = {
    "deepseek": {
        "base_url_env": "DEEPSEEK_BASE_URL",
        "base_url_default": "https://api.deepseek.com",
        "model_env": "DEEPSEEK_MODEL",
        "model_default": "deepseek-chat",
        "key_env": "DEEPSEEK_API_KEY",
    },
    "qwen": {
        "base_url_env": "QWEN_BASE_URL",
        "base_url_default": "https://dashscope.aliyuncs.com/compatible-mode/v1",
        "model_env": "QWEN_GEN_MODEL",
        "model_default": "qwen-plus",
        "key_env": "QWEN_API_KEY",
    },
}
LLM_BACKEND = (os.getenv("XIAOBAN_LLM_BACKEND", "deepseek").strip() or "deepseek")


class LLMClient:
    """替身 coze_coding_dev_sdk.LLMClient -> 真实模型（OpenAI 兼容协议）。"""

    _clients: Dict[str, Any] = {}
    _client_lock = threading.Lock()

    def __init__(self, ctx: Any = None):
        self.ctx = ctx

    @classmethod
    def backend_conf(cls) -> Dict[str, str]:
        if LLM_BACKEND not in LLM_BACKENDS:
            raise RuntimeError(f"未知生成后端 XIAOBAN_LLM_BACKEND={LLM_BACKEND}，"
                               f"可选 {sorted(LLM_BACKENDS)}")
        return LLM_BACKENDS[LLM_BACKEND]

    @classmethod
    def backend_model(cls) -> str:
        c = cls.backend_conf()
        return (os.getenv(c["model_env"]) or c["model_default"]).strip()

    @classmethod
    def _get_client(cls):
        b = LLM_BACKEND
        if b not in cls._clients:
            with cls._client_lock:
                if b not in cls._clients:
                    c = cls.backend_conf()
                    from openai import OpenAI
                    cls._clients[b] = OpenAI(
                        api_key=(os.getenv(c["key_env"]) or "").strip(),
                        base_url=(os.getenv(c["base_url_env"]) or c["base_url_default"]).rstrip("/"),
                        timeout=120.0,
                        max_retries=2,
                    )
        return cls._clients[b]

    def invoke(self, messages, model=None, temperature=None, top_p=None,
               max_completion_tokens=None, thinking=None, **kwargs):
        """
        生产节点只读 response.content。
        model 传进来的是扣子侧模型名（doubao-* / deepseek-*），这里统一路由到当前后端，
        并在 trace 里同时记录「请求的模型名」与「实际调用的模型名」。
        """
        requested = model or ""
        actual = self.backend_model()

        oai_messages = []
        for m in messages or []:
            role = "user"
            cls_name = type(m).__name__
            if cls_name == "SystemMessage":
                role = "system"
            elif cls_name == "AIMessage":
                role = "assistant"
            content = getattr(m, "content", "")
            oai_messages.append({"role": role, "content": content})

        payload = {
            "model": actual,
            "messages": oai_messages,
            "stream": False,
        }
        if temperature is not None:
            payload["temperature"] = float(temperature)
        if top_p is not None:
            payload["top_p"] = float(top_p)
        if max_completion_tokens:
            payload["max_tokens"] = int(max_completion_tokens)

        last_err = None
        for attempt in range(3):
            try:
                resp = self._get_client().chat.completions.create(**payload)
                u = getattr(resp, "usage", None)
                pt = getattr(u, "prompt_tokens", 0) or 0
                ct = getattr(u, "completion_tokens", 0) or 0
                USAGE.add(actual, pt, ct)
                content = resp.choices[0].message.content or ""
                return _LLMResponse(content, {
                    "model_requested": requested,
                    "model_actual": actual,
                    "temperature": payload.get("temperature"),
                    "top_p": payload.get("top_p"),
                    "max_tokens": payload.get("max_tokens"),
                    "thinking_flag": thinking,
                    "prompt_tokens": pt,
                    "completion_tokens": ct,
                })
            except Exception as e:  # noqa: BLE001
                last_err = e
                time.sleep(1.5 * (attempt + 1))
        USAGE.add(actual, 0, 0, err=True)
        raise RuntimeError(f"LLM 调用失败(重试3次, backend={LLM_BACKEND}): "
                           f"{type(last_err).__name__}: {last_err}")


# ----------------------------------------------
# 1.2 知识库替身 -> Qwen 向量嵌入 + 余弦检索
# ----------------------------------------------
class _Chunk:
    def __init__(self, content: str, score: float, metadata: Dict[str, Any]):
        self.content = content
        self.score = score
        self.metadata = metadata

    def __repr__(self):
        return f"<Chunk score={self.score:.4f} len={len(self.content)}>"


class _SearchResponse:
    def __init__(self, code: int, chunks: List[_Chunk]):
        self.code = code
        self.chunks = chunks


class _Embedder:
    """DashScope 兼容模式 text-embedding-v3，真实向量。"""

    def __init__(self):
        # 注意：此处不能缓存 env（load_env() 在模块末尾才执行），一律惰性读取
        self.lock = threading.Lock()
        self._cache: Dict[str, List[float]] = {}
        self.calls = 0
        self._load_cache()

    # ---- 磁盘缓存 ----
    @property
    def _cache_path(self) -> str:
        return os.path.join(CACHE_DIR, "embed_cache.json")

    def _load_cache(self):
        if os.path.exists(self._cache_path):
            try:
                self._cache = json.load(open(self._cache_path, encoding="utf-8"))
            except Exception:  # noqa: BLE001
                self._cache = {}

    def persist(self):
        with self.lock:
            json.dump(self._cache, open(self._cache_path, "w", encoding="utf-8"),
                      ensure_ascii=False)

    @staticmethod
    def _key(text: str) -> str:
        return hashlib.sha1(text.encode("utf-8")).hexdigest()

    def embed(self, texts: List[str], batch: int = 10) -> List[List[float]]:
        todo = [t for t in texts if self._key(t) not in self._cache]
        if todo:
            for i in range(0, len(todo), batch):
                part = todo[i:i + batch]
                vecs = self._post(part)
                with self.lock:
                    for t, v in zip(part, vecs):
                        self._cache[self._key(t)] = v
                    self.calls += 1
                self.persist()
        with self.lock:
            return [self._cache[self._key(t)] for t in texts]

    def _post(self, texts: List[str]) -> List[List[float]]:
        url = os.getenv(
            "QWEN_EMBED_URL",
            "https://dashscope.aliyuncs.com/compatible-mode/v1/embeddings",
        )
        model = os.getenv("QWEN_EMBED_MODEL", "text-embedding-v3")
        key = os.getenv("QWEN_API_KEY", "").strip()
        body = json.dumps({"model": model, "input": texts}).encode("utf-8")
        last_err = None
        for attempt in range(4):
            req = urllib.request.Request(
                url, data=body,
                headers={"Content-Type": "application/json",
                         "Authorization": "Bearer " + key},
            )
            try:
                with urllib.request.urlopen(req, timeout=60) as r:
                    data = json.loads(r.read().decode("utf-8"))
                return [d["embedding"] for d in data["data"]]
            except Exception as e:  # noqa: BLE001
                detail = ""
                try:
                    detail = e.read().decode("utf-8")[:300]  # type: ignore[attr-defined]
                except Exception:  # noqa: BLE001
                    pass
                last_err = f"{type(e).__name__}: {e} {detail}"
                time.sleep(1.0 + 1.5 * attempt)
        raise RuntimeError(f"嵌入调用失败: {last_err}")


def cosine(a: List[float], b: List[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    if na == 0 or nb == 0:
        return 0.0
    return dot / (na * nb)


class _VectorStore:
    """本地语料 + 真实向量检索。"""

    def __init__(self):
        self.embedder = _Embedder()
        self.tables: Dict[str, List[Dict[str, Any]]] = {}
        self._loaded = False
        self.lock = threading.Lock()

    @staticmethod
    def _parse_kb_text(raw: str) -> Dict[str, str]:
        lines = [l.strip() for l in (raw or "").strip().split("\n")]
        lines = [l for l in lines if l]
        d = {"question": "", "synonyms": "", "answer": "", "path": "", "steps": "", "source": ""}
        if len(lines) >= 1:
            d["question"] = lines[0]
        for l in lines[1:]:
            for pfx, key in (("同义问法：", "synonyms"), ("答案：", "answer"),
                             ("路径：", "path"), ("步骤：", "steps"), ("来源：", "source")):
                if l.startswith(pfx):
                    d[key] = l[len(pfx):].strip()
        return d

    @staticmethod
    def _parse_kb_file(path: str) -> Dict[str, str]:
        return _VectorStore._parse_kb_text(open(path, encoding="utf-8").read())

    def load(self):
        if self._loaded:
            return
        with self.lock:
            if self._loaded:
                return
            docs = []
            for fn in sorted(os.listdir(KB_DIR)):
                if not fn.lower().endswith(".txt"):
                    continue
                raw = open(os.path.join(KB_DIR, fn), encoding="utf-8").read().strip()
                meta = self._parse_kb_file(os.path.join(KB_DIR, fn))
                if CORPUS_VARIANT == "qonly":
                    searchable = meta["question"] + "\n同义问法：" + meta["synonyms"]
                else:
                    searchable = raw
                docs.append({
                    "doc_id": fn[:-4],
                    "file": fn,
                    "content": raw,                 # 节点期望解析 6 行格式，恒用原文
                    "searchable": searchable,       # 真正参与嵌入的文本
                    "question": meta["question"],
                    "synonyms": meta["synonyms"],
                    "answer": meta["answer"],
                    "path": meta["path"],
                    "steps": meta["steps"],
                    "source": meta["source"],
                })
            vecs = self.embedder.embed([d["searchable"] for d in docs])
            for d, v in zip(docs, vecs):
                d["vec"] = v
            # 两张表指向同一批语料（替代语料，见 CORPUS_NOTE）
            self.tables["standard_qa_kb"] = docs
            self.tables["coze_doc_knowledge"] = docs
            self._loaded = True

    def _materialize_fixture_docs(self, items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """把 fixture 里声明的补充文档变成可检索的 doc（含真实向量，走同一嵌入缓存）。"""
        if not items:
            return []
        key = hashlib.sha1(json.dumps(items, ensure_ascii=False, sort_keys=True)
                           .encode("utf-8")).hexdigest()
        with self.lock:
            if key in _FX_DOC_CACHE:
                return _FX_DOC_CACHE[key]
        docs = []
        for i, it in enumerate(items):
            raw = it.get("content") or ""
            meta = self._parse_kb_text(raw)
            docs.append({
                "doc_id": it.get("doc_id") or f"FIXTURE_{key[:6]}_{i}",
                "file": it.get("doc_id") or "(fixture)",
                "content": raw,                                    # 节点按 6 行格式解析
                "searchable": it.get("searchable") or raw,         # 参与嵌入的文本
                "question": meta["question"],
                "synonyms": meta["synonyms"],
                "answer": meta["answer"],
                "path": meta["path"],
                "steps": meta["steps"],
                "source": meta["source"],
                "is_fixture": True,
            })
        vecs = self.embedder.embed([d["searchable"] for d in docs])
        for d, v in zip(docs, vecs):
            d["vec"] = v
        with self.lock:
            _FX_DOC_CACHE.setdefault(key, docs)
        return _FX_DOC_CACHE[key]

    def docs_for(self, table: str) -> List[Dict[str, Any]]:
        """某张表的最终语料 = 基础语料 − exclude + fixture append（仅当前线程的用例）。"""
        base = self.tables.get(table) or []
        fx = active_fixture()
        if not fx:
            return base
        spec = (fx.get("tables") or {}).get(table)
        if not spec:
            return base
        excl = set(spec.get("exclude") or [])
        head = [d for d in base if d["doc_id"] not in excl] if excl else list(base)
        return head + self._materialize_fixture_docs(spec.get("append") or [])

    def search(self, table: str, query: str, top_k: int = 5,
               min_score: Optional[float] = None) -> List[_Chunk]:
        self.load()
        docs = self.docs_for(table)
        qv = self.embedder.embed([query])[0]
        scored = [(cosine(qv, d["vec"]), d) for d in docs]
        scored.sort(key=lambda x: x[0], reverse=True)
        out = []
        for sc, d in scored[:max(1, top_k)]:
            if min_score is not None and sc < float(min_score):
                continue
            out.append(_Chunk(
                content=d["content"],
                score=round(float(sc), 6),
                metadata={"source": d["source"] or d["file"],
                          "path": d["path"], "doc_id": d["doc_id"], "table": table,
                          "is_fixture": bool(d.get("is_fixture"))},
            ))
        return out


STORE = _VectorStore()


class KnowledgeClient:
    """替身 coze_coding_dev_sdk.KnowledgeClient。

    生产代码里有两套返回契约，必须都支持：
      - standard_qa_match / vector_retrieval / keyword_retrieval
            search(query, table_names=[...], top_k=, min_score=)
            -> 读 response.code / response.chunks / chunk.content / chunk.score
      - secondary_retrieval
            search(query, top_k=)  -> 直接迭代返回的 chunk 列表，chunk 有 .metadata
    """

    def __init__(self, config: Any = None, ctx: Any = None):
        self.config = config
        self.ctx = ctx
        self.calls = 0

    def search(self, query, table_names=None, top_k=5, min_score=None, **kwargs):
        self.calls += 1
        if table_names:
            table = table_names[0] if isinstance(table_names, (list, tuple)) else str(table_names)
            chunks = STORE.search(table, query, top_k=top_k, min_score=min_score)
            return _SearchResponse(0, chunks)
        # secondary_retrieval 契约：直接返回可迭代的 chunk 列表
        chunks = STORE.search("coze_doc_knowledge", query, top_k=top_k, min_score=min_score)
        return chunks


# ============================================================
# 2. 注入替身并加载生产节点
# ============================================================
def install_shims():
    """把替身塞进 sys.modules，并把 `graphs` 指向 Desktop 真源码树。"""
    # --- coze_coding_utils ---
    pkg = types.ModuleType("coze_coding_utils")
    pkg.__path__ = []
    sys.modules["coze_coding_utils"] = pkg

    rc = types.ModuleType("coze_coding_utils.runtime_ctx")
    rc.__path__ = []
    sys.modules["coze_coding_utils.runtime_ctx"] = rc

    ctx_mod = types.ModuleType("coze_coding_utils.runtime_ctx.context")
    ctx_mod.Context = Context
    ctx_mod.new_context = new_context
    sys.modules["coze_coding_utils.runtime_ctx.context"] = ctx_mod

    # --- coze_coding_dev_sdk ---
    sdk = types.ModuleType("coze_coding_dev_sdk")
    sdk.LLMClient = LLMClient
    sdk.KnowledgeClient = KnowledgeClient
    sdk.Config = Config
    sys.modules["coze_coding_dev_sdk"] = sdk

    # --- langgraph ---
    lg = types.ModuleType("langgraph")
    lg.__path__ = []
    sys.modules["langgraph"] = lg
    lg_rt = types.ModuleType("langgraph.runtime")
    lg_rt.Runtime = _Runtime
    sys.modules["langgraph.runtime"] = lg_rt
    lg_graph = types.ModuleType("langgraph.graph")
    lg_graph.StateGraph = object
    lg_graph.END = "__end__"
    sys.modules["langgraph.graph"] = lg_graph

    # --- graphs 包别名 -> Desktop 源码树（生产源码就在这） ---
    if SRC_DIR not in sys.path:
        sys.path.insert(0, SRC_DIR)
    if NODES_DIR not in sys.path:
        sys.path.insert(0, NODES_DIR)

    g = types.ModuleType("graphs")
    g.__path__ = [SRC_DIR]
    sys.modules["graphs"] = g

    gn = types.ModuleType("graphs.nodes")
    gn.__path__ = [NODES_DIR]
    sys.modules["graphs.nodes"] = gn


_NODE_CACHE: Dict[str, Any] = {}


def load_node(module_name: str, fn_name: str):
    """从生产源码加载节点函数。"""
    key = f"{module_name}.{fn_name}"
    if key in _NODE_CACHE:
        return _NODE_CACHE[key]
    mod = __import__(f"graphs.nodes.{module_name}", fromlist=[fn_name])
    fn = getattr(mod, fn_name)
    _NODE_CACHE[key] = fn
    return fn


def load_states():
    return __import__("graphs.state", fromlist=["*"])


# ============================================================
# 3. 节点调用适配（复刻框架行为：按 Input 模型过滤全局状态）
# ============================================================
def call_node(fn, InputCls, gstate: Dict[str, Any],
              llm_cfg: Optional[str] = None) -> Any:
    payload = {k: v for k, v in gstate.items() if k in InputCls.model_fields}
    inp = InputCls(**payload)
    cfg = {"metadata": {"llm_cfg": llm_cfg}} if llm_cfg else {"metadata": {}}
    return fn(inp, cfg, RUNTIME)


# ============================================================
# 4. ENV
# ============================================================
def load_env():
    env_path = os.path.join(os.path.dirname(EVAL_DIR), "..", "backend", ".env")
    env_path = os.path.abspath(env_path)
    if os.path.exists(env_path):
        for line in open(env_path, encoding="utf-8"):
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip())
    os.environ.setdefault("COZE_WORKSPACE_PATH", SRC_DIR)
    _ensure_dirs()


load_env()
install_shims()

# 静音：生产节点大量使用 logger.warning/info，未配置 handler 时会走 logging 的
# lastResort 处理器把日志喷到 stderr，污染评测输出。挂一个 NullHandler 即可。
import logging as _logging  # noqa: E402

_logging.getLogger().addHandler(_logging.NullHandler())
_logging.getLogger().setLevel(_logging.CRITICAL)
for _n in ("graphs", "graphs.nodes"):
    _logging.getLogger(_n).setLevel(_logging.CRITICAL)
