"""
单条用例执行器：按 graph.py 的真实路由顺序驱动生产节点。
不重写任何节点逻辑，只做「输入构造 + 路由 + trace 记录」。
"""
from __future__ import annotations

import os
import sys
import time
import traceback
from typing import Any, Dict, List, Optional

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harness as H  # noqa: E402

CFG_QUERY_REWRITE = "config/query_rewrite_llm_cfg.json"
CFG_SPLIT_CLASSIFY = "config/split_and_classify_llm_cfg.json"
CFG_NORMAL_ANSWER = "config/normal_answer_llm_cfg.json"
CFG_FALLBACK_ANSWER = "config/fallback_answer_llm_cfg.json"

LLM_CFG_OF_NODE = {
    "query_rewrite": CFG_QUERY_REWRITE,
    "split_and_classify": CFG_SPLIT_CLASSIFY,
    "normal_answer": CFG_NORMAL_ANSWER,
    "fallback_answer": CFG_FALLBACK_ANSWER,
}

FALLBACK_MARKERS = ["未明确规定", "hr@company.com", "暂未找到", "暂未查询到", "不予受理"]

# P0'：转人工指引词表（R33 发现——关键词口径把「必须转人工」按半权重静默抹掉）。
# 仅对显式声明 requires_handoff 的用例做硬门；其余用例完全不读这张表（向后兼容）。
# 取词原则：明确指向「人工渠道 / 上级 / 财务 / HR」的升级措辞；避免过宽导致非冲突答案误过。
HANDOFF_MARKERS = [
    "hr@", "hr", "人力", "直属上级", "上级", "财务",
    "转人工", "人工渠道", "人工核实", "人工确认", "人工客服",
    "请示", "请咨询", "咨询hr", "咨询 hr", "咨询人力", "联系人工",
    "对接专人", "专人对接", "向hr", "联系hr",
]


def _clip(s: Any, n: int = 300) -> str:
    s = "" if s is None else str(s)
    return s if len(s) <= n else s[:n] + "…"


def judge(answer: str, case: Dict[str, Any]) -> Dict[str, Any]:
    """与 P0 完全一致的三口径判定，保证可跨版本对比。

    v1.2 起新增可选的 `expected_any`（AND-of-OR 组）：
      - `expected_keywords`：每词都必须出现（AND）
      - `expected_any`：每个组内**任一**词出现即算该组满足；所有组都必须满足（AND of OR）
    为什么需要它：当"合规做法"有多种合理措辞时（例如冲突场景下「存在差异」/「存在规则冲突」
    都对，或「咨询 HR」/「请示直属上级」都对），纯 AND 的逐字断言会把合规回答判失败——
    这正是 R7/R21 反复踩到的「用逐字断言去测行为」。
    不写 `expected_any` 的用例行为**与改动前完全一致**（向后兼容）。
    """
    answer = answer or ""
    exp = [k for k in (case.get("expected_keywords") or []) if k]
    groups = [[k for k in g if k] for g in (case.get("expected_any") or []) if g]
    forb = [k for k in (case.get("forbidden_keywords") or []) if k]

    hit = [k for k in exp if k in answer]
    missed = [k for k in exp if k not in answer]

    group_hit: List[str] = []
    group_missed: List[str] = []
    for alts in groups:
        matched = next((a for a in alts if a in answer), None)
        if matched:
            group_hit.append(matched)
        else:
            group_missed.append("any[" + "|".join(alts) + "]")

    bad = [k for k in forb if k in answer]
    n_total = len(exp) + len(groups)
    n_hit = len(hit) + len(group_hit)
    ratio = (n_hit / n_total) if n_total else 0.0

    strict = (len(missed) == 0 and len(group_missed) == 0 and len(bad) == 0)
    half = (ratio >= 0.5 and len(bad) == 0)
    anyhit = (n_hit > 0 and len(bad) == 0)

    # ---- P0'：必须转人工 硬门（R33 发现：关键词口径把「必须转人工」按半权重静默抹掉）----
    # 仅对显式声明 requires_handoff 的用例生效；其余用例行为完全不变（向后兼容）。
    # 缺失转人工指引 => 合规失败，三口径全判 False（不可协商的合规项，不是加权项）。
    ans_low = answer.lower()
    handoff_present = any(m.lower() in ans_low for m in HANDOFF_MARKERS)
    requires_handoff = bool(case.get("requires_handoff"))
    must_handoff_fail = bool(requires_handoff and not handoff_present)
    if must_handoff_fail:
        strict = half = anyhit = False

    return {
        "hit": hit,
        "missed": missed + group_missed,
        "group_hit": group_hit,
        "group_missed": group_missed,
        "forbidden_hit": bad,
        "kw_ratio": round(ratio, 4),
        "strict": strict,
        "half": half,
        "anyhit": anyhit,
        "is_fallback_answer": any(m in answer for m in FALLBACK_MARKERS),
        "answer_chars": len(answer),
        "requires_handoff": requires_handoff,
        "handoff_present": handoff_present,
        "must_handoff_fail": must_handoff_fail,
    }


def run_case(case: Dict[str, Any], keep_trace: bool = False,
             stage: str = "full",
             llm_cache: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """对外入口：套一层「按用例语料注入」的作用域。

    为什么必须 try/finally：fixture 存放在 thread-local 里，同一个 worker 线程会连跑多条
    用例；一旦某条用例抛异常而没清干净，注入语料会**泄漏到后续用例**，污染整轮评测。
    """
    fx = H.fixture_of(case.get("test_id"))
    H.set_active_fixture(fx)
    try:
        res = _run_case_inner(case, keep_trace=keep_trace, stage=stage, llm_cache=llm_cache)
    finally:
        H.clear_active_fixture()
    res["fixture"] = H.describe_fixture(fx)
    return res


def _run_case_inner(case: Dict[str, Any], keep_trace: bool = False,
                    stage: str = "full",
                    llm_cache: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    stage:
      - full       : 全链路，含 3 次 LLM 调用
      - route_only : 跳过 query_rewrite / split_and_classify（用 llm_cache 回放），
                     只跑检索与路由，用于阈值扫描（零 LLM 成本）
    """
    S = H.load_states()
    t0 = time.time()
    nodes: List[Dict[str, Any]] = []
    g: Dict[str, Any] = {"user_input": case.get("query") or ""}
    cached = (llm_cache or {}).get(case["test_id"], {})
    SKIP_ANSWERS = (stage == "route_only")

    def step(name: str, InputClsName: str, fn, llm_cfg: Optional[str] = None):
        t = time.time()
        try:
            out = H.call_node(fn, getattr(S, InputClsName), g, llm_cfg)
            d = out.model_dump()
            g.update(d)
            nodes.append({"node": name, "ok": True, "ms": round((time.time() - t) * 1000, 1),
                          "out": {k: _clip(v, 200) for k, v in d.items()}})
            return out
        except Exception as e:  # noqa: BLE001
            nodes.append({"node": name, "ok": False, "ms": round((time.time() - t) * 1000, 1),
                          "error": f"{type(e).__name__}: {e}"})
            raise

    def answer_step(name: str, InputClsName: str, fn, llm_cfg: Optional[str] = None):
        """阈值扫描（route_only）时跳过回答节点，避免无谓的 LLM 调用。"""
        if SKIP_ANSWERS:
            nodes.append({"node": name, "ok": True, "ms": 0.0, "skipped": True})
            return None
        return step(name, InputClsName, fn, llm_cfg)

    # ---------- 1) query_rewrite ----------
    if stage == "route_only" and cached.get("query_rewrite") is not None:
        g["query_rewrite"] = cached["query_rewrite"]
        nodes.append({"node": "query_rewrite", "ok": True, "ms": 0.0, "replayed": True,
                      "out": {"query_rewrite": _clip(cached["query_rewrite"], 200)}})
    else:
        step("query_rewrite", "QueryRewriteInput",
             H.load_node("query_rewrite_node", "query_rewrite_node"),
             LLM_CFG_OF_NODE["query_rewrite"])

    # ---------- 2) split_and_classify ----------
    if stage == "route_only" and cached.get("split_questions") is not None:
        g["split_questions"] = cached["split_questions"]
        g["biz_type"] = cached.get("biz_type", "其他")
        g["biz_types"] = cached.get("biz_types", [])
        nodes.append({"node": "split_and_classify", "ok": True, "ms": 0.0, "replayed": True,
                      "out": {"split_questions": cached["split_questions"],
                              "biz_type": g["biz_type"], "biz_types": g["biz_types"]}})
    else:
        step("split_and_classify", "SplitAndClassifyInput",
             H.load_node("split_and_classify_node", "split_and_classify_node"),
             LLM_CFG_OF_NODE["split_and_classify"])

    # ---------- 3) standard_qa_match ----------
    qa = step("standard_qa_match", "StandardQaMatchInput",
              H.load_node("standard_qa_match_node", "standard_qa_match_node"))

    terminal = None
    if qa.all_sub_questions_hit:
        terminal = "normal_answer(标准QA直答)"
        answer_step("normal_answer", "NormalAnswerInput",
                    H.load_node("normal_answer_node", "normal_answer_node"),
                    LLM_CFG_OF_NODE["normal_answer"])
    else:
        # ---------- 4) 混合检索链路 ----------
        step("vector_retrieval", "VectorRetrievalInput",
             H.load_node("vector_retrieval_node", "vector_retrieval_node"))
        step("keyword_retrieval", "KeywordRetrievalInput",
             H.load_node("keyword_retrieval_node", "keyword_retrieval_node"))
        mg = step("merge_retrieval", "MergeRetrievalInput",
                  H.load_node("merge_retrieval_node", "merge_retrieval_node"))

        if not mg.has_valid_content:
            # ---------- 5) 二次检索 ----------
            sr = step("secondary_retrieval", "SecondaryRetrievalInput",
                      H.load_node("secondary_retrieval_node", "secondary_retrieval_node"))
            if sr.has_valid_content:
                terminal = "normal_answer(二次检索后)"
                answer_step("normal_answer", "NormalAnswerInput",
                     H.load_node("normal_answer_node", "normal_answer_node"),
                     LLM_CFG_OF_NODE["normal_answer"])
            else:
                terminal = "fallback_answer(二次检索无效)"
                answer_step("fallback_answer", "FallbackAnswerInput",
                            H.load_node("fallback_answer_node", "fallback_answer_node"),
                            LLM_CFG_OF_NODE["fallback_answer"])
        else:
            # ---------- 6) 冲突校验 ----------
            rc = step("rule_conflict_check", "RuleConflictCheckInput",
                      H.load_node("rule_conflict_check_node", "rule_conflict_check_node"))
            if rc.rule_conflict_detected and rc.is_real_conflict:
                terminal = "conflict_fallback_answer"
                answer_step("conflict_fallback_answer", "ConflictFallbackAnswerInput",
                     H.load_node("conflict_fallback_answer_node", "conflict_fallback_answer_node"))
            else:
                # ---------- 7) 三级路由 ----------
                cc = step("condition_check", "ConditionCheckInput",
                          H.load_node("condition_check_node", "condition_check_node"))
                if cc.route_branch == "normal":
                    terminal = "normal_answer(检索后正常作答)"
                    answer_step("normal_answer", "NormalAnswerInput",
                         H.load_node("normal_answer_node", "normal_answer_node"),
                         LLM_CFG_OF_NODE["normal_answer"])
                elif cc.route_branch == "mid_fallback":
                    terminal = "mid_fallback_answer"
                    answer_step("mid_fallback_answer", "MidFallbackAnswerInput",
                         H.load_node("mid_fallback_answer_node", "mid_fallback_answer_node"))
                else:
                    terminal = "fallback_answer(全局兜底)"
                    answer_step("fallback_answer", "FallbackAnswerInput",
                         H.load_node("fallback_answer_node", "fallback_answer_node"),
                         LLM_CFG_OF_NODE["fallback_answer"])

    # ---------- 取答案 ----------
    # 生产缺陷（已定位）：normal_answer_node.py:132 `answer_text = state.standard_answer`
    # 把 dict 直接赋给 answer_text，标准QA直答分支的答案体会变成 dict 字符串。
    # 判定时把内层 answer_text 解出来（用内容口径），同时单独打缺陷标记。
    defect_flags: List[str] = []

    def _unwrap(v: Any, depth: int = 0) -> str:
        if depth > 4:
            return str(v)
        if isinstance(v, dict):
            inner = v.get("answer_text") or v.get("answer") or v.get("text")
            if isinstance(inner, dict):
                defect_flags.append("stdqa_answer_text_is_dict")
                return _unwrap(inner, depth + 1)
            if isinstance(inner, str):
                if "${" in inner or inner.startswith("{'"):
                    defect_flags.append("stdqa_answer_text_is_dict_repr")
                    import ast
                    try:
                        return _unwrap(ast.literal_eval(inner), depth + 1)
                    except Exception:  # noqa: BLE001
                        return inner
                return inner
            return str(v)
        s = str(v)
        if s.startswith("{'") and "answer_text" in s:
            defect_flags.append("stdqa_answer_text_is_dict_repr")
            import ast
            try:
                return _unwrap(ast.literal_eval(s), depth + 1)
            except Exception:  # noqa: BLE001
                return s
        return s

    def pick(*keys) -> str:
        for k in keys:
            v = g.get(k)
            if v:
                return _unwrap(v)
        return ""

    answer = pick("normal_answer", "mid_fallback_answer",
                  "fallback_answer", "conflict_fallback_answer")
    # 标准QA直答分支的 source 恒为空（doc_source 未在 GlobalState 中流转）
    if terminal and terminal.startswith("normal_answer(标准QA直答)"):
        if not (g.get("normal_answer") or {}).get("source"):
            defect_flags.append("stdqa_source_empty")

    res = {
        "test_id": case["test_id"],
        "dim": case.get("test_dimension"),
        "priority": case.get("priority"),
        "layer": case.get("layer"),
        "query": case.get("query"),
        "query_rewrite": g.get("query_rewrite"),
        "split_questions": g.get("split_questions"),
        "biz_type": g.get("biz_type"),
        "biz_types": g.get("biz_types"),
        "standard_hit": g.get("standard_hit"),
        "all_sub_questions_hit": g.get("all_sub_questions_hit"),
        "standard_match_type": g.get("standard_match_type"),
        "top_score": g.get("top_score"),
        "has_valid_content": g.get("has_valid_content"),
        "route_branch": g.get("route_branch"),
        "terminal_node": terminal,
        "answer": answer,
        "raw_answer_type": type(g.get("normal_answer")).__name__,
        "defect_flags": sorted(set(defect_flags)),
        "judge": judge(answer, case),
        "elapsed_ms": round((time.time() - t0) * 1000, 1),
    }
    if keep_trace:
        res["trace"] = {"nodes": nodes,
                        "knowledge_retrieval": _clip(g.get("knowledge_retrieval"), 4000)}
    return res
