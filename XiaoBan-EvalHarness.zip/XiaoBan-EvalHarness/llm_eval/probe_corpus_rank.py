"""语料排名探针：给一个 query，列出语料里 top-N 篇文档及其余弦相似度。

用途（写 fixture 时的高频动作）：
  1. 查清某条用例「被哪篇文档短路 / 命中了哪篇」→ 决定 fixture 要 exclude 哪几篇；
  2. 验证注入的补充文档能否被检索到（分数是否过 min_score 门槛）。

零 LLM 成本：走嵌入磁盘缓存（cache/embed_cache.json），新文本才调一次嵌入。

用法：
  python probe_corpus_rank.py "事假最多能请几天？"
  python probe_corpus_rank.py "事假最多能请几天？" --table coze_doc_knowledge --top 5
"""
from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding="utf-8")

import harness as H  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("query")
    ap.add_argument("--table", default="standard_qa_kb")
    ap.add_argument("--top", type=int, default=5)
    ap.add_argument("--fixtures", default="")
    ap.add_argument("--fixture-case", default="", help="用哪条用例的 fixture（配合 --fixtures）")
    args = ap.parse_args()

    if args.fixtures:
        fx = H.load_fixtures(args.fixtures)
        if args.fixture_case:
            H.set_active_fixture(fx.get(args.fixture_case))
            print(f"已启用 fixture: {args.fixture_case}  {H.describe_fixture(fx.get(args.fixture_case))}")

    H.STORE.load()
    docs = H.STORE.docs_for(args.table)
    qv = H.STORE.embedder.embed([args.query])[0]
    scored = sorted(((H.cosine(qv, d["vec"]), d) for d in docs), key=lambda x: -x[0])

    print(f"query = {args.query!r}")
    print(f"table = {args.table}   语料 {len(docs)} 篇（含 fixture 注入）\n")
    for sc, d in scored[:args.top]:
        flag = " [FIXTURE]" if d.get("is_fixture") else ""
        print(f"  {sc:.4f}  {d['doc_id']}{flag}")
        print(f"          {d['searchable'][:110].replace(chr(10), ' / ')}")

    print("\n  判定门槛参照：standard_qa_sim_threshold=0.70 / vector_min_score=0.60 / "
          "keyword_min_score=0.60 / secondary_min_score=0.60")


if __name__ == "__main__":
    main()
