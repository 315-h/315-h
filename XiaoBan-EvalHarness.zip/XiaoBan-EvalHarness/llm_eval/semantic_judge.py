"""轻量语义判定器：给「行为型用例」加第二判官。

为什么需要它（第五轮的结论）：
  关键词断言已经到顶——同一条合规语义实测被模型用 5 种说法表达
  （存在规则冲突 / 存在条款差异 / 两版规定 / 两种制度规定 / 规定不一致），
  靠堆同义词永远追不上。更致命的是它**表达不了否定式要求**
  （「不得在未提示不确定性的情况下给出唯一确定结论」）。

设计原则（三条，都很重要）：
  1. **不替换主判定**：语义判定产出的是**第二套口径**（semantic），与关键词三口径并列。
     两者结论不一致的样本自动落盘 → 那就是**人工复核队列 / 语义判定的调参集**。
  2. **判定任务极简 + 强制引用原文证据**：每条判断必须给出回答中的原样片段（quote）。
     生成与判定用的是同一个模型（DeepSeek）→ 存在自评偏差，靠"任务足够窄 + 证据可复核"压制。
     这个局限必须写进报告，不能藏。
  3. **可缓存、零重复成本**：按 (模型, 指令版本, 问题, 回答) 哈希缓存，重跑不花钱。

用法：
  python semantic_judge.py --validate                                    # 跑标注集（默认判官 deepseek）
  python semantic_judge.py --validate --judge-model qwen                 # 换跨厂商判官
  python semantic_judge.py --compare-models                              # 跨厂商对比：量化自评偏差
  python semantic_judge.py --validate --no-cache                         # 强制重判（测稳定性）
  python semantic_judge.py --validate --flip --no-cache                  # 阴性对照（标注反转）
  python semantic_judge.py --from-trace v12_fx2 [--judge-model qwen]     # 对某轮 trace 跑
  python semantic_judge.py --from-trace v12_fx2 --only TC-C01,TC-C02
  python semantic_judge.py --dump-answers v12_fx2 --ids TC-C01,TC-C02   # 导出真实答案（做标注集用）

判官后端（`--judge-model`）：`deepseek`（与被测系统同厂商，默认）／`qwen`（跨厂商，通义千问）。
两个后端使用**完全相同的 prompt**，缓存键含后端与模型名 → 两份结论并存、互不覆盖，可逐项对比。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time
from typing import Any, Dict, List, Optional

sys.stdout.reconfigure(encoding="utf-8")

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, "out")
CACHE_PATH = os.path.join(HERE, "cache", "semantic_cache.json")
CHECKS_PATH = os.path.join(ROOT, "data", "semantic_checks.json")
SAMPLES_PATH = os.path.join(ROOT, "data", "semantic_judge_samples.jsonl")

PROMPT_VERSION = "v1"  # 改指令必须同步改这里，否则缓存会拿旧结论


# ============================================================
# 判官后端（可切换厂商）
# ============================================================
# 为什么要有第二个厂商：被测系统由 DeepSeek 生成，若判官也是 DeepSeek，就存在
# **自评偏差**（self-preference）——模型可能对自己的措辞更宽容。换一个厂商的模型当判官，
# 才能把这个偏差显式量化出来。两个后端**使用完全相同的 prompt**，保证可比。
JUDGES: Dict[str, Dict[str, str]] = {
    "deepseek": {
        "label": "DeepSeek（被测系统同厂商）",
        "base_url_env": "DEEPSEEK_BASE_URL",
        "base_url_default": "https://api.deepseek.com",
        "model_env": "DEEPSEEK_MODEL",
        "model_default": "deepseek-chat",
        "key_env": "DEEPSEEK_API_KEY",
    },
    "qwen": {
        "label": "通义千问（跨厂商）",
        "base_url_env": "QWEN_BASE_URL",
        "base_url_default": "https://dashscope.aliyuncs.com/compatible-mode/v1",
        "model_env": "QWEN_JUDGE_MODEL",
        "model_default": "qwen-plus",
        "key_env": "QWEN_API_KEY",
    },
}


def judge_conf(backend: str) -> Dict[str, str]:
    if backend not in JUDGES:
        raise SystemExit(f"未知判官后端 {backend}，可选：{sorted(JUDGES)}")
    return JUDGES[backend]


def judge_model_of(backend: str) -> str:
    c = judge_conf(backend)
    return (os.getenv(c["model_env"]) or c["model_default"]).strip()


# ============================================================
# 判定项定义（与具体用例解耦：用例只声明"用哪套判定项"）
# ============================================================
DEFAULT_CHECKS = [
    {
        "id": "ack_discrepancy",
        "expect": True,
        "question": "回答明确指出公司制度对该问题存在不一致、冲突，或存在多个版本的规定。",
    },
    {
        "id": "handoff_to_human",
        "expect": True,
        "question": "回答建议用户向人工渠道（HR / 人力 / 直属上级 / 上级 / 财务）确认或请示。",
    },
    {
        "id": "single_definitive_claim",
        "expect": False,
        "question": ("回答在没有提示任何不确定性、分歧或版本差异的情况下，直接给出了一个唯一的确定结论"
                     "（例如断言只能办/不能办，或只给出唯一一个天数、金额、上限）。"),
    },
]


def load_checks() -> Dict[str, Any]:
    """读取判定项配置（config + 代码默认值，和阈值外置同一套约定）。

    结构：
      _default : 判定项列表（数组，元素含 id / expect / question）
      _cases   : 哪些用例纳入语义判定范围（数组；为空则需 --only 显式指定）
      <test_id>: 可选，为该用例覆盖 _default（数组）
    """
    default = DEFAULT_CHECKS
    cases: List[str] = []
    overrides: Dict[str, List[Dict[str, Any]]] = {}
    if os.path.exists(CHECKS_PATH):
        raw = json.load(open(CHECKS_PATH, encoding="utf-8"))
        default = raw.get("_default") or DEFAULT_CHECKS
        cases = list(raw.get("_cases") or [])
        overrides = {k: v for k, v in raw.items()
                     if not k.startswith("_") and isinstance(v, list) and v}
    return {"default": default, "cases": cases, "overrides": overrides}


def checks_for(cfg: Dict[str, Any], test_id: str) -> List[Dict[str, Any]]:
    return cfg["overrides"].get(test_id) or cfg["default"]


# ============================================================
# LLM 调用（DeepSeek，temperature=0，JSON 输出）
# ============================================================
def _load_env():
    env_path = os.path.abspath(os.path.join(ROOT, "..", "backend", ".env"))
    if os.path.exists(env_path):
        for line in open(env_path, encoding="utf-8"):
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip())


_load_env()  # 模块级调用：被 import 时也能拿到密钥（全用 setdefault，幂等）


class _Cache:
    def __init__(self):
        self.data: Dict[str, Any] = {}
        if os.path.exists(CACHE_PATH):
            try:
                self.data = json.load(open(CACHE_PATH, encoding="utf-8"))
            except Exception:  # noqa: BLE001
                self.data = {}

    def get(self, key: str):
        return self.data.get(key)

    def put(self, key: str, val: Any):
        self.data[key] = val
        os.makedirs(os.path.dirname(CACHE_PATH), exist_ok=True)
        json.dump(self.data, open(CACHE_PATH, "w", encoding="utf-8"), ensure_ascii=False, indent=1)


def _key(query: str, answer: str, check_ids: List[str], backend: str) -> str:
    raw = json.dumps([PROMPT_VERSION, backend, judge_model_of(backend),
                      query, answer, check_ids], ensure_ascii=False)
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()


def build_prompt(query: str, answer: str, checks: List[Dict[str, Any]]) -> str:
    lines = [
        "你是制度问答系统的评测裁判。下面给出【用户问题】与【系统回答】。",
        "请**只根据回答原文**判断下列事实是否成立。要求：",
        "1. 只判断事实，不评价回答好坏，不补充原文没有的信息；",
        "2. 每条判断必须给出回答中的**原样片段**作为证据（quote）；若不成立，quote 留空字符串；",
        "3. 原文明显只是**并列陈述两个版本**、或**提示存在差异/建议确认**，都算「提示了不确定性」；",
        "4. 只输出 JSON，不要任何解释文字。",
        "",
        f"【用户问题】{query}",
        "【系统回答】",
        answer,
        "",
        "【待判断的事实】",
    ]
    for i, c in enumerate(checks, 1):
        lines.append(f"{i}. (id={c['id']}) {c['question']}")
    lines += [
        "",
        "【输出格式】",
        '{"judgments":[{"id":"判定项id","holds":true或false,"quote":"回答中的原样片段或空字符串"}],'
        '"confidence":0到1之间的小数}',
    ]
    return "\n".join(lines)


def call_llm(prompt: str, backend: str = "deepseek") -> Dict[str, Any]:
    from openai import OpenAI

    c = judge_conf(backend)
    base = (os.getenv(c["base_url_env"]) or c["base_url_default"]).rstrip("/")
    client = OpenAI(api_key=(os.getenv(c["key_env"]) or "").strip(),
                    base_url=base, timeout=120.0, max_retries=2)
    payload = {
        "model": judge_model_of(backend),
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0,
        "stream": False,
        "response_format": {"type": "json_object"},
    }
    last = None
    for attempt in range(3):
        try:
            resp = client.chat.completions.create(**payload)
            return json.loads(resp.choices[0].message.content or "{}")
        except Exception as e:  # noqa: BLE001
            last = e
            time.sleep(1.2 * (attempt + 1))
    raise RuntimeError(f"语义判定调用失败(backend={backend}): {type(last).__name__}: {last}")


_CACHE = _Cache()


def judge_semantic(query: str, answer: str, checks: List[Dict[str, Any]],
                   backend: str = "deepseek",
                   use_cache: bool = True) -> Dict[str, Any]:
    """返回 {holds: {id: bool}, evidence: {id: str}, confidence, failed: [id], passed: bool, cached}

    注意：同一答案换判官后端 → 缓存键不同，两份结论并存、互不覆盖。
    """
    cids = [c["id"] for c in checks]
    key = _key(query, answer, cids, backend)
    raw = _CACHE.get(key) if use_cache else None
    cached = raw is not None
    if raw is None:
        raw = call_llm(build_prompt(query, answer, checks), backend)
        _CACHE.put(key, raw)

    got = {j.get("id"): j for j in (raw.get("judgments") or []) if isinstance(j, dict)}
    holds, evidence, failed, unknown = {}, {}, [], []
    for c in checks:
        j = got.get(c["id"])
        if j is None or not isinstance(j.get("holds"), bool):
            unknown.append(c["id"])
            continue
        holds[c["id"]] = j["holds"]
        evidence[c["id"]] = str(j.get("quote") or "")[:120]
        if j["holds"] != c["expect"]:
            failed.append(c["id"])
    return {
        "holds": holds,
        "evidence": evidence,
        "confidence": raw.get("confidence"),
        "failed": failed,
        "unknown": unknown,
        "passed": (not failed) and (not unknown),
        "cached": cached,
    }


# ============================================================
# 模式一：标注集验证
# ============================================================
def _agreement_detail(samples: List[Dict[str, Any]], checks: List[Dict[str, Any]],
                      backend: str, no_cache: bool):
    """对标注集跑一个判官，返回逐项/整条一致率与不一致明细。"""
    agree_items = total_items = agree_samples = billed = 0
    mismatches = []
    for s in samples:
        r = judge_semantic(s["query"], s["answer"], checks, backend=backend, use_cache=not no_cache)
        if not r["cached"]:
            billed += 1
        exp = s["expected"]
        got = dict(r["holds"])
        items_ok = all(got.get(k) == exp[k] for k in exp if k in got)
        cover_ok = all(k in got for k in exp)          # 判定项必须都判出来（漏判 = 不合格）
        pass_ok = (r["passed"] == s["expected_pass"]) if "expected_pass" in s else True
        for k in exp:
            total_items += 1
            if got.get(k) == exp[k]:
                agree_items += 1
        if items_ok and cover_ok and pass_ok:
            agree_samples += 1
        else:
            mismatches.append((s["id"], exp, got, r))
    return {"backend": backend, "model": judge_model_of(backend),
            "agree_items": agree_items, "total_items": total_items,
            "agree_samples": agree_samples, "total_samples": len(samples),
            "billed": billed, "mismatches": mismatches}


def mode_validate(samples_path: str, no_cache: bool, flip: bool, backend: str) -> int:
    if not os.path.exists(samples_path):
        print(f"缺少标注集 {samples_path}")
        return 1
    samples = [json.loads(l) for l in open(samples_path, encoding="utf-8").read().strip().split("\n") if l.strip()]
    checks = load_checks()["default"]
    if flip:
        # 阴性对照：把标注全部反转。判定器如果只是在"猜标注方向"，一致率会照样很高；
        # 只有当它真的在读回答时，一致率才会崩到很低。
        for s in samples:
            s["expected"] = {k: (not v) for k, v in s["expected"].items()}
            if "expected_pass" in s:
                s["expected_pass"] = not s["expected_pass"]
    print(f"标注集 {samples_path}  {len(samples)} 条；判定项 {[c['id'] for c in checks]}")
    print(f"判官：{backend} / {judge_model_of(backend)}"
          f"  |  模式：{'阴性对照（标注已全部反转）' if flip else '正向'}"
          f"  |  缓存：{'禁用' if no_cache else '启用'}\n")

    d = _agreement_detail(samples, checks, backend, no_cache)
    print(f"逐项一致率：{d['agree_items']}/{d['total_items']} = "
          f"{d['agree_items'] / d['total_items'] * 100:.1f}%")
    print(f"整条一致率：{d['agree_samples']}/{d['total_samples']} = "
          f"{d['agree_samples'] / d['total_samples'] * 100:.1f}%")
    print(f"本次新增 LLM 调用：{d['billed']} 次\n")

    if d["mismatches"]:
        print("=" * 74)
        print("不一致明细（这些就是调参样本 / 人工复核队列）")
        print("=" * 74)
        for sid, exp, got, r in d["mismatches"]:
            print(f"\n▶ {sid}")
            print(f"   期望: {json.dumps(exp, ensure_ascii=False)}")
            print(f"   实测: {json.dumps(got, ensure_ascii=False)}")
            print(f"   证据: {json.dumps(r['evidence'], ensure_ascii=False)}")
    else:
        print("✅ 本模式下无不一致。")

    if flip:
        print("\n【阴性对照读法】逐项一致率应当**接近 0%**；若仍然很高，说明判定器没在读回答，"
              "标注集的 100% 不可信。")

    out = os.path.join(OUT, f"semantic_judge_validate_{backend}.json")
    json.dump({"samples_file": os.path.relpath(samples_path, ROOT), "flip": flip,
               "no_cache": no_cache, "backend": backend, "model": judge_model_of(backend),
               "total_items": d["total_items"], "agree_items": d["agree_items"],
               "total_samples": d["total_samples"], "agree_samples": d["agree_samples"],
               "mismatch_ids": [m[0] for m in d["mismatches"]], "billed_calls": d["billed"]},
              open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    print(f"\n-> {out}")
    return 0 if not d["mismatches"] else 2


# ============================================================
# 模式二：对某轮 trace 跑语义判定
# ============================================================
def mode_from_trace(tag: str, only: Optional[List[str]], backend: str) -> int:
    sys.path.insert(0, HERE)
    from trace_util import load_traces  # noqa: E402

    rows = load_traces(OUT, tag)
    cfg = load_checks()
    scope = set(only) if only else set(cfg["cases"])

    results = []
    billed = 0
    skipped = []
    for tid, r in sorted(rows.items()):
        if scope and tid not in scope:
            continue
        checks = checks_for(cfg, tid)
        answer = r.get("answer") or ""
        if not answer.strip():
            skipped.append(tid)
            continue
        res = judge_semantic(r.get("query") or "", answer, checks, backend=backend)
        if not res["cached"]:
            billed += 1
        kw_half = bool(r.get("judge", {}).get("half"))
        results.append({
            "test_id": tid,
            "judge_backend": backend,
            "judge_model": judge_model_of(backend),
            "terminal_node": r.get("terminal_node"),
            "keyword_half": kw_half,
            "keyword_strict": bool(r.get("judge", {}).get("strict")),
            "semantic_pass": res["passed"],
            "semantic_holds": res["holds"],
            "semantic_failed": res["failed"],
            "semantic_unknown": res["unknown"],
            "evidence": res["evidence"],
            "confidence": res["confidence"],
            "agreement": (kw_half == res["passed"]),
            "answer": answer[:400],
        })

    n = len(results)
    print(f"tag={tag}   判官={backend}/{judge_model_of(backend)}   "
          f"判定范围={sorted(scope) if scope else '（未限定，全部）'}   "
          f"语义判定用例 {n} 条   新增 LLM 调用 {billed} 次")
    if skipped:
        print(f"跳过（无答案）: {skipped}")
    print()
    print(f"  {'用例':<10} {'终端节点':<28} {'关键词half':<10} {'语义pass':<9} 一致")
    for x in results:
        print(f"  {x['test_id']:<10} {(x['terminal_node'] or '-'):<28} "
              f"{str(x['keyword_half']):<10} {str(x['semantic_pass']):<9} "
              f"{'✅' if x['agreement'] else '❌ 分歧'}")

    agree = sum(1 for x in results if x["agreement"])
    print(f"\n两种判官一致率：{agree}/{n} = {agree / n * 100:.1f}%")
    dis = [x for x in results if not x["agreement"]]
    if dis:
        print(f"\n分歧样本 {len(dis)} 条（→ 人工复核队列）：")
        for x in dis:
            print(f"\n▶ {x['test_id']}  终端={x['terminal_node']}")
            print(f"   关键词判={x['keyword_half']}  语义判={x['semantic_pass']}  "
                  f"失败项={x['semantic_failed']} 未判出={x['semantic_unknown']}")
            print(f"   证据: {json.dumps(x['evidence'], ensure_ascii=False)}")
            print(f"   答案: {x['answer'][:200]}")

    outst = os.path.join(OUT, f"semantic_{tag}_{backend}.json")
    json.dump(results, open(outst, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"\n-> {outst}")
    return 0


# ============================================================
# 模式三：导出真实答案（做标注集用）
# ============================================================
def mode_dump_answers(tag: str, ids: List[str]) -> int:
    sys.path.insert(0, HERE)
    from trace_util import load_traces  # noqa: E402

    rows = load_traces(OUT, tag)
    for tid in ids:
        r = rows.get(tid)
        if not r:
            print(f"✗ {tid} 不在 tag={tag} 里")
            continue
        print("=" * 78)
        print(f"[{tid}]  终端={r.get('terminal_node')}  kw_half={r.get('judge', {}).get('half')}")
        print(f"query: {r.get('query')}")
        print("-" * 78)
        print(r.get("answer"))
    return 0


# ============================================================
# 模式四：跨厂商判官对比（量化自评偏差）
# ============================================================
def mode_compare(samples_path: str, no_cache: bool, backends: List[str]) -> int:
    if not os.path.exists(samples_path):
        print(f"缺少标注集 {samples_path}")
        return 1
    samples = [json.loads(l) for l in open(samples_path, encoding="utf-8").read().strip().split("\n") if l.strip()]
    checks = load_checks()["default"]

    print("=" * 78)
    print("跨厂商判官对比（同一标注集 · 同一 prompt · 同一判定项）")
    print("=" * 78)
    print(f"标注集 {len(samples)} 条 / {len(samples) * len(checks)} 项；"
          f"判官 {[(b, judge_model_of(b)) for b in backends]}\n")

    per_model: Dict[str, Dict[str, Any]] = {}
    verdicts: Dict[str, Dict[str, Dict[str, bool]]] = {}
    evidence: Dict[str, Dict[str, Dict[str, str]]] = {}
    for b in backends:
        d = _agreement_detail(samples, checks, b, no_cache)
        per_model[b] = d
        verdicts[b] = {}
        evidence[b] = {}
        for s in samples:
            r = judge_semantic(s["query"], s["answer"], checks, backend=b, use_cache=not no_cache)
            verdicts[b][s["id"]] = dict(r["holds"])
            evidence[b][s["id"]] = dict(r["evidence"])

    print("① 各判官 vs 人工标注（标注为真值）")
    print(f"  {'判官':<10} {'模型':<16} {'逐项一致':<12} {'整条一致':<12} 与标注不符的项")
    for b in backends:
        d = per_model[b]
        bad = []
        for s in samples:
            for k in s["expected"]:
                if verdicts[b][s["id"]].get(k) != s["expected"][k]:
                    bad.append(f"{s['id']}.{k}")
        print(f"  {b:<10} {judge_model_of(b):<16} "
              f"{d['agree_items']}/{d['total_items']:<10} {d['agree_samples']}/{d['total_samples']:<10} "
              f"{bad if bad else '（无）'}")

    print("\n② 判官之间的一致性（不算真值，只看两个厂商是否看同一件事）")
    both = [b for b in backends]
    item_total = item_agree = 0
    sample_same = 0
    disputes = []
    for s in samples:
        same_all = True
        for c in checks:
            k = c["id"]
            item_total += 1
            vals = [verdicts[b][s["id"]].get(k) for b in both]
            if len(set(vals)) == 1:
                item_agree += 1
            else:
                same_all = False
                disputes.append((s["id"], k, {b: verdicts[b][s["id"]].get(k) for b in both},
                                 {b: evidence[b][s["id"]].get(k, "") for b in both},
                                 s["expected"][k], s["note"]))
        if same_all:
            sample_same += 1
    print(f"  逐项一致：{item_agree}/{item_total} = {item_agree / item_total * 100:.1f}%")
    print(f"  整条一致：{sample_same}/{len(samples)} = {sample_same / len(samples) * 100:.1f}%")

    if disputes:
        print(f"\n  分歧明细（{len(disputes)} 项）—— 这些样本 = 判官调参集：")
        for sid, k, vals, evs, truth, note in disputes:
            winner = [b for b in backends if vals[b] == truth]
            print(f"\n  ▶ {sid} · {k}")
            print(f"     标注真值={truth}   各判官={json.dumps(vals, ensure_ascii=False)}   "
                  f"与真值一致={winner or '（都不一致）'}")
            print(f"     备注: {note}")
            for b in both:
                print(f"     {b:<9} 证据: {evs[b][:100]!r}")

    out = os.path.join(OUT, "semantic_judge_crossmodel.json")
    json.dump({"samples_file": os.path.relpath(samples_path, ROOT),
               "backends": {b: {"model": judge_model_of(b),
                                "agree_items": per_model[b]["agree_items"],
                                "total_items": per_model[b]["total_items"],
                                "agree_samples": per_model[b]["agree_samples"],
                                "total_samples": per_model[b]["total_samples"]}
                            for b in backends},
               "cross_model": {"item_agree": item_agree, "item_total": item_total,
                               "sample_same": sample_same, "samples": len(samples)},
               "disputes": [{"sample": d[0], "check": d[1], "verdicts": d[2],
                             "expected": d[4]} for d in disputes]},
              open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    print(f"\n-> {out}")
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--validate", action="store_true")
    ap.add_argument("--compare-models", action="store_true", help="跨厂商判官对比（量化自评偏差）")
    ap.add_argument("--judge-model", default="deepseek", choices=sorted(JUDGES),
                    help="判官后端：deepseek=被测系统同厂商；qwen=跨厂商")
    ap.add_argument("--judges", default="deepseek,qwen", help="--compare-models 用的后端列表")
    ap.add_argument("--samples", default=SAMPLES_PATH, help="标注集路径")
    ap.add_argument("--no-cache", action="store_true", help="强制重新调用（测判定稳定性）")
    ap.add_argument("--flip", action="store_true",
                    help="阴性对照：把标注全部反转。判定器若真在读回答，一致率应崩到接近 0%")
    ap.add_argument("--from-trace", default="")
    ap.add_argument("--dump-answers", default="")
    ap.add_argument("--only", default="")
    ap.add_argument("--ids", default="")
    args = ap.parse_args()

    _load_env()
    if args.compare_models:
        bs = [s.strip() for s in args.judges.split(",") if s.strip()]
        return mode_compare(args.samples, args.no_cache, bs)
    if args.validate:
        return mode_validate(args.samples, args.no_cache, args.flip, args.judge_model)
    if args.from_trace:
        only = [s.strip() for s in args.only.split(",") if s.strip()] or None
        return mode_from_trace(args.from_trace, only, args.judge_model)
    if args.dump_answers:
        ids = [s.strip() for s in args.ids.split(",") if s.strip()]
        return mode_dump_answers(args.dump_answers, ids)
    ap.print_help()
    return 1


if __name__ == "__main__":
    sys.exit(main())
