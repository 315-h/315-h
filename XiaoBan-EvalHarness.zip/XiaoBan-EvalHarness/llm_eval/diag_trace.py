"""
trace 诊断：查看 trace 结构 + 抽取修复 D3/D4/D5 需要的关键分布。
用法：
  python diag_trace.py --tag full --schema          # 只看结构
  python diag_trace.py --tag full --route           # 路由/得分/业务分类分布
  python diag_trace.py --tag full --kw              # 关键词路 kw_score 分布
"""
from __future__ import annotations

import argparse
import collections
import json
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, "out")


def load(tag: str):
    path = os.path.join(OUT, f"traces_llm_{tag}.jsonl")
    return [json.loads(l) for l in open(path, encoding="utf-8").read().strip().split("\n")]


def brief(v, n=160):
    s = json.dumps(v, ensure_ascii=False) if not isinstance(v, str) else v
    s = s.replace("\n", "\\n")
    return s[:n] + ("…" if len(s) > n else "")


def schema(rows):
    r = rows[0]
    print("=== 顶层字段 ===")
    for k, v in r.items():
        print(f"  {k:<24} {type(v).__name__:<8} {brief(v, 90)}")
    for key in ("steps", "trace", "node_trace", "node_outputs"):
        if key in r:
            print(f"\n=== {key} 结构（第一条，共 {len(r[key])} 项）===")
            for i, st in enumerate(r[key]):
                if isinstance(st, dict):
                    print(f"  [{i}] keys={list(st.keys())}")
                    print(f"      {brief(st, 300)}")
                else:
                    print(f"  [{i}] {brief(st, 300)}")


def nodes_of(r):
    return ((r.get("trace") or {}).get("nodes") or [])


def route(rows):
    print("=== 业务分类分布（全部 118 条）===")
    c = collections.Counter(r.get("biz_type") or "?" for r in rows)
    for k, v in c.most_common():
        print(f"  {k:<12} {v}")
    print("\n=== 终端节点分布 ===")
    c = collections.Counter((r.get("terminal_node") or "?").split("(")[0] for r in rows)
    for k, v in c.most_common():
        print(f"  {k:<28} {v}")
    print("\n=== 终端节点（细分）===")
    c = collections.Counter(r.get("terminal_node") or "?" for r in rows)
    for k, v in c.most_common():
        print(f"  {k:<40} {v}")

    print("\n=== condition_check 输出（只看走到该节点的用例）===")
    c = collections.Counter()
    biz = collections.Counter()
    ts = []
    rc = collections.Counter()
    reach = 0
    for r in rows:
        hit_cc = False
        for st in nodes_of(r):
            name = st.get("node") or ""
            out = st.get("out") or {}
            if name == "condition_check":
                hit_cc = True
                c[out.get("route_branch") or "?"] += 1
                biz[(r.get("biz_type"), out.get("route_branch"))] += 1
            if name == "rule_conflict_check" and isinstance(out, dict):
                rc[(out.get("rule_conflict_detected"), out.get("is_real_conflict"))] += 1
            if name == "merge_retrieval" and isinstance(out, dict):
                ts.append(out.get("top_score"))
        if hit_cc:
            reach += 1
    print(f"  走到 condition_check 的用例：{reach} 条")
    for k, v in c.most_common():
        print(f"  route_branch={k}  x{v}")
    print("  (biz_type, route_branch) 明细：")
    for k, v in biz.most_common():
        print(f"    {k}  x{v}")

    print("\n=== rule_conflict_check (detected, is_real) ===")
    for k, v in rc.most_common():
        print(f"  {k}  x{v}")

    ts2 = [t for t in ts if isinstance(t, (int, float))]
    if ts2:
        ts2.sort()
        n = len(ts2)
        print(f"\n=== merge_retrieval.top_score n={n} ===")
        print(f"  min={ts2[0]:.4f} p25={ts2[n//4]:.4f} 中位={ts2[n//2]:.4f} "
              f"p75={ts2[n*3//4]:.4f} max={ts2[-1]:.4f}")
        for thr in (0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8):
            print(f"  >= {thr}: {sum(1 for t in ts2 if t >= thr)} 条")


def kw(rows):
    print("=== 关键词路 kw_score 分布（keyword_retrieval 输出里的 keyword_chunks）===")
    vals = []
    per_case = []
    for r in rows:
        n = 0
        for st in nodes_of(r):
            if (st.get("node") or "") == "keyword_retrieval":
                out = st.get("out") or {}
                for ch in (out.get("keyword_chunks") or []):
                    if isinstance(ch, dict):
                        vals.append(float(ch.get("kw_score") or 0.0))
                        n += 1
        per_case.append(n)
    vals.sort()
    if not vals:
        print("  未取到 kw_score")
        return
    n = len(vals)
    print(f"  片段总数 n={n}（平均每例 {n / len(rows):.1f} 片）")
    print(f"  min={vals[0]:.4f} 中位={vals[n//2]:.4f} max={vals[-1]:.4f}")
    print("  分位：", {q: round(vals[min(n - 1, int(n * q))], 4) for q in (0.05, 0.1, 0.25, 0.5, 0.75, 0.9)})
    buckets = collections.Counter()
    for v in vals:
        if v < 0.005:
            buckets["<0.005"] += 1
        elif v < 0.01:
            buckets["[0.005,0.01)"] += 1
        elif v < 0.015:
            buckets["[0.01,0.015)"] += 1
        elif v < 0.02:
            buckets["[0.015,0.02)"] += 1
        elif v < 0.03:
            buckets["[0.02,0.03)"] += 1
        elif v < 0.05:
            buckets["[0.03,0.05)"] += 1
        else:
            buckets[">=0.05"] += 1
    for k in ("<0.005", "[0.005,0.01)", "[0.01,0.015)", "[0.015,0.02)",
              "[0.02,0.03)", "[0.03,0.05)", ">=0.05"):
        print(f"  {k:<16} {buckets.get(k, 0)}")
    print("\n  每例关键词片段数分布：")
    c = collections.Counter(per_case)
    for k in sorted(c):
        print(f"    {k} 片: {c[k]} 例")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", default="full")
    ap.add_argument("--schema", action="store_true")
    ap.add_argument("--route", action="store_true")
    ap.add_argument("--kw", action="store_true")
    a = ap.parse_args()
    rows = load(a.tag)
    print(f"tag={a.tag}  用例 {len(rows)} 条\n")
    if a.schema or not (a.route or a.kw):
        schema(rows)
    if a.route:
        print()
        route(rows)
    if a.kw:
        print()
        kw(rows)


if __name__ == "__main__":
    main()
