"""trace 读取小工具（供各 probe / verify 脚本共用）。

⚠️ 踩坑记录：`traces_llm_*.jsonl` 里节点的 `out` 是**值被字符串化**的 dict，
   即 {"rule_conflict_detected": "False"} —— 直接 `if out.get(k)` 判真会**恒为真**。
   早期 probe_conflict.py 就因此把「detected=0」误报成「detected=28」。
   故本模块统一提供 `as_bool` 做显式转换，禁止再直接对字段做真值判断。
"""
from __future__ import annotations

import json
import os


def load_traces(out_dir: str, tag: str) -> dict:
    """读某个 tag 的 trace，返回 {test_id: record}。"""
    path = os.path.join(out_dir, f"traces_llm_{tag}.jsonl")
    rows = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            r = json.loads(line)
            rows[r["test_id"]] = r
    return rows


def node_out(row: dict, node_name: str):
    """取某条 trace 里指定节点的 out（dict）；没跑过该节点返回 None。"""
    for n in (row.get("trace") or {}).get("nodes") or []:
        if n.get("node") == node_name:
            out = n.get("out")
            return out if isinstance(out, dict) else {}
    return None


def as_bool(v) -> bool:
    """把 'False' / 'True' / False / True / b'...' 统一转成 bool。"""
    if isinstance(v, bool):
        return v
    if v is None:
        return False
    if isinstance(v, (int, float)):
        return bool(v)
    return str(v).strip().lower() in {"true", "1", "yes"}


def as_list(v) -> list:
    """把 '[]' / "['a']" / ['a'] 统一转成 list。"""
    if isinstance(v, list):
        return v
    if v in (None, ""):
        return []
    s = str(v).strip()
    try:
        got = json.loads(s)
        return got if isinstance(got, list) else [got]
    except Exception:
        pass
    try:
        import ast

        got = ast.literal_eval(s)
        return got if isinstance(got, list) else [got]
    except Exception:
        return [s]
