"""导出单条用例的完整节点轨迹（含检索到的片段原文）。

用途：当某个终端分支"意外触发/意外不触发"时，用它看清每一个节点的真实输入输出，
而不是靠推理猜——本项目的 trace 里节点 out 的值是字符串，务必原样阅读、不要做真值判断。

用法：
  python show_case_trace.py fix_d3 TC-C01
  python show_case_trace.py fixture_c01c02 TC-C01 --retrieval
"""
from __future__ import annotations

import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding="utf-8")

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, "out")

TAG = sys.argv[1]
WANT = sys.argv[2]
SHOW_RETRIEVAL = "--retrieval" in sys.argv

row = None
with open(os.path.join(OUT, f"traces_llm_{TAG}.jsonl"), encoding="utf-8") as f:
    for line in f:
        line = line.strip()
        if not line:
            continue
        r = json.loads(line)
        if r["test_id"] == WANT:
            row = r
            break
if row is None:
    print(f"未找到 {WANT}（tag={TAG}）")
    raise SystemExit(1)

print("=" * 78)
print(f"{WANT}   tag={TAG}")
print("=" * 78)
print(f"query            : {row.get('query')}")
print(f"query_rewrite    : {row.get('query_rewrite')}")
print(f"split_questions  : {row.get('split_questions')}")
print(f"biz_type         : {row.get('biz_type')} / {row.get('biz_types')}")
print(f"top_score        : {row.get('top_score')}")
print(f"has_valid_content: {row.get('has_valid_content')}")
print(f"route_branch     : {row.get('route_branch')}")
print(f"terminal_node    : {row.get('terminal_node')}")
print(f"fixture          : {json.dumps(row.get('fixture'), ensure_ascii=False)}")
print(f"judge            : {json.dumps(row.get('judge'), ensure_ascii=False)}")
print(f"\n--- answer ---\n{row.get('answer')}")

print("\n--- 节点轨迹（out 的值是字符串，原样展示）---")
for n in (row.get("trace") or {}).get("nodes") or []:
    print(f"\n▶ {n.get('node')}  ok={n.get('ok')}  ms={n.get('ms')}")
    out = n.get("out")
    if out is None:
        print(f"   {n.get('error') or '(跳过：阈值扫描不回放回答节点)'}")
        continue
    for k, v in (out or {}).items():
        s = str(v)
        if len(s) > 700:
            s = s[:700] + "…"
        print(f"   {k}: {s}")

if SHOW_RETRIEVAL:
    print("\n--- 合并检索原文（截断 4000）---")
    print(((row.get("trace") or {}).get("knowledge_retrieval") or "")[:4000])
