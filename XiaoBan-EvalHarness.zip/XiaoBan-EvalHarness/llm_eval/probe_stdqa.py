"""标准QA短路诊断：某条用例是被哪篇 standard_qa_kb 文档「全部命中」短路掉的？

为什么需要它：给「制度冲突校验」类用例写 fixture 时，必须先把造成短路的基线文档
`exclude` 掉，否则工作流在 standard_qa_match 就返回了预制答案，
**根本不会走到检索 / 冲突校验节点**，注入再多冲突语料也没用。

用法：
  python probe_stdqa.py fix_d3 TC-C01 TC-C02
  python probe_stdqa.py fix_d3 --all      # 列出所有被短路的用例
"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding="utf-8")

from trace_util import as_bool, load_traces, node_out  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, "out")

TAG = sys.argv[1] if len(sys.argv) > 1 else "fix_d3"
WANT = [a for a in sys.argv[2:] if a and a != "--all"]
ALL = "--all" in sys.argv

traces = load_traces(OUT, TAG)
rows = []
for tid, r in sorted(traces.items()):
    o = node_out(r, "standard_qa_match")
    if o is None:
        continue
    short = as_bool(o.get("all_sub_questions_hit"))
    rows.append((tid, short, o, r))

print(f"tag={TAG}   执行过 standard_qa_match 的用例：{len(rows)} 条")
print(f"  其中 all_sub_questions_hit=True（被短路，不会进入检索/冲突校验）："
      f"{sum(1 for _, s, _, _ in rows if s)} 条\n")

sel = rows if (ALL or not WANT) else [x for x in rows if x[0] in set(WANT)]

for tid, short, o, r in sel:
    print(f"{tid}  短路={short}  终端={r.get('terminal_node')}")
    print(f"   standard_hit={o.get('standard_hit')}  match_type={o.get('standard_match_type')}")
    for k in ("standard_answer", "sub_question_hits", "matched_question", "top_score"):
        if k in o:
            print(f"   {k}: {str(o.get(k))[:400]}")
    print()

print("--- 建议 ---")
print("若要让某条用例走到 rule_conflict_check，需在其 fixture 里 exclude 掉让它短路的")
print("standard_qa_kb 文档（doc_id 见 out/console_kb_docids.txt），并注入互相矛盾的文档。")
