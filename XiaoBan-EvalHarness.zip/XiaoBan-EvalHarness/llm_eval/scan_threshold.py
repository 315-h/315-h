"""
小办 · 阈值扫描（零 LLM 成本）
========================================================
思路：把主运行已经产生的 query_rewrite / split_and_classify 结果回放（llm_cache_*.json），
只重跑「检索 + 冲突 + 三级路由」这一段纯 Python 逻辑，扫描阈值对**路由行为**的影响。

这就补上了 P0 阶段做不到的事：真实向量相似度下，0.6 到底意味什么。
"""
from __future__ import annotations

import argparse
import collections
import copy
import importlib
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding="utf-8")

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, "out")
os.makedirs(OUT, exist_ok=True)

import harness as H  # noqa: E402
import run_pipeline as RP  # noqa: E402

RELOAD_MODS = [
    "thresholds",
    "standard_qa_match_node",
    "vector_retrieval_node",
    "keyword_retrieval_node",
    "merge_retrieval_node",
    "secondary_retrieval_node",
    "condition_check_node",
]


def apply_thresholds(base_cfg, overrides, tmp_path):
    cfg = copy.deepcopy(base_cfg)
    for dotted, val in overrides.items():
        sec, key = dotted.split(".")
        cfg.setdefault(sec, {})[key] = val
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    os.environ["XIAOBAN_THRESHOLDS"] = tmp_path
    # 清掉 thresholds 模块的缓存 + 重载依赖它的节点，让模块级常量重新取值
    th = importlib.import_module("graphs.nodes.thresholds")
    th._CONFIG_CACHE = None
    th._CONFIG_PATH_CACHE = None
    importlib.reload(th)
    for name in RELOAD_MODS:
        mod = sys.modules.get(f"graphs.nodes.{name}")
        if mod is not None:
            importlib.reload(mod)
    H._NODE_CACHE.clear()
    return cfg


def expect_fallback(branch_text: str) -> bool:
    b = branch_text or ""
    if "兜底" in b and "正常回答" not in b:
        return True
    return False


def expected_answer(branch_text: str) -> bool:
    b = branch_text or ""
    return any(t in b for t in ("正常回答", "标准QA", "直接输出", "组装输出", "逐条"))


def run_once(cases, llm_cache, base_cfg, overrides, tmp_path):
    apply_thresholds(base_cfg, overrides, tmp_path)
    branch_counter = collections.Counter()
    tops = []
    std_qa = mid = glob = conflict = 0
    under = []
    over = []
    errors = 0
    for c in cases:
        try:
            r = RP.run_case(c, keep_trace=False, stage="route_only",
                            llm_cache=llm_cache)
        except Exception:  # noqa: BLE001
            errors += 1
            continue
        t = r["terminal_node"] or "?"
        if t.startswith("normal_answer(标准QA直答)"):
            std_qa += 1
        elif t.startswith("normal_answer"):
            branch_counter["normal_answer"] += 1
        elif t.startswith("mid_fallback"):
            branch_counter["mid_fallback"] += 1
            mid += 1
        elif t.startswith("fallback"):
            branch_counter["global_fallback"] += 1
            glob += 1
        elif t.startswith("conflict"):
            branch_counter["conflict_fallback"] += 1
            conflict += 1
        else:
            branch_counter[t] += 1
        if r.get("top_score") is not None:
            tops.append(float(r["top_score"]))
        eb = next((x.get("expected_branch") for x in cases if x["test_id"] == r["test_id"]), "")
        got_fallback = t.startswith(("mid_fallback", "fallback", "conflict"))
        if expected_answer(eb) and got_fallback:
            under.append(r["test_id"])
        if expect_fallback(eb) and t.startswith("normal_answer"):
            over.append(r["test_id"])
    n = len(cases) - errors
    answered = std_qa + branch_counter["normal_answer"]
    return {
        "n": n,
        "errors": errors,
        "standard_qa_direct": std_qa,
        "normal_answer": branch_counter["normal_answer"],
        "total_answered": answered,
        "answer_rate": round(answered / n * 100, 1) if n else 0.0,
        "mid_fallback": mid,
        "global_fallback": glob,
        "conflict_fallback": conflict,
        "fallback_total": mid + glob + conflict,
        "fallback_rate": round((mid + glob + conflict) / n * 100, 1) if n else 0.0,
        "under_answer": len(under),
        "under_cases": under,
        "over_answer": len(over),
        "over_cases": over,
        "top_score_mean": round(sum(tops) / len(tops), 4) if tops else None,
        "top_score_min": round(min(tops), 4) if tops else None,
        "top_score_max": round(max(tops), 4) if tops else None,
        "branch_dist": dict(branch_counter),
        "overrides": overrides,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", default="full")
    ap.add_argument("--cache", default=None)
    ap.add_argument("--cases", default=os.path.join(ROOT, "data", "testset_118.v1.1.jsonl"))
    args = ap.parse_args()

    cache_path = args.cache or os.path.join(H.CACHE_DIR, f"llm_cache_{args.tag}.json")
    llm_cache = json.load(open(cache_path, encoding="utf-8"))
    cases = [json.loads(l) for l in open(args.cases, encoding="utf-8").read().strip().split("\n")]
    base_cfg = json.load(open(os.path.join(H.CONFIG_DIR, "eval_thresholds.json"), encoding="utf-8"))

    print(f"回放缓存: {os.path.basename(cache_path)}  ({len(llm_cache)} 条)")
    print(f"用例 {len(cases)} 条  |  基线: vector_min={base_cfg['retrieval']['vector_min_score']} "
          f"std_qa_sim={base_cfg['retrieval']['standard_qa_sim_threshold']} "
          f"route_normal={base_cfg['route']['normal_min_score']} "
          f"route_mid={base_cfg['route']['mid_min_score']}")
    tmp_path = os.path.join(H.CACHE_DIR, "thresh_scan_tmp.json")

    baseline = run_once(cases, llm_cache, base_cfg, {}, tmp_path)
    print(f"\n基线：作答 {baseline['answer_rate']}%（标准QA直答 {baseline['standard_qa_direct']} + "
          f"正常回答 {baseline['normal_answer']}）  兜底 {baseline['fallback_rate']}% "
          f"(过渡 {baseline['mid_fallback']} / 全局 {baseline['global_fallback']} / 冲突 {baseline['conflict_fallback']})")
    print(f"      欠报 {baseline['under_answer']}  过报 {baseline['over_answer']}  "
          f"top_score 均值 {baseline['top_score_mean']}（{baseline['top_score_min']}~{baseline['top_score_max']}）")

    sweeps = {
        "retrieval.vector_min_score": [round(0.30 + 0.05 * i, 2) for i in range(11)],
        "route.normal_min_score": [round(0.20 + 0.10 * i, 2) for i in range(7)],
        "route.mid_min_score": [round(0.05 + 0.05 * i, 2) for i in range(8)],
        "retrieval.standard_qa_sim_threshold": [round(0.50 + 0.05 * i, 2) for i in range(8)],
        # D5 修复时补入：这是唯一能改变 has_valid_content 的阈值（第一轮/第二轮都没扫过它）
        "retrieval.keyword_min_score": [round(0.10 + 0.05 * i, 2) for i in range(12)],
        # D5-b：二次检索的相关性门限（同样是「无门限通道」）
        "retrieval.secondary_min_score": [round(0.10 + 0.05 * i, 2) for i in range(12)],
    }

    rows = []
    t0 = time.time()
    for key, vals in sweeps.items():
        print(f"\n{'='*84}\n扫描 {key}\n{'='*84}")
        print(f"  {'取值':>6} | {'作答%':>6} {'标准QA':>6} {'正常':>5} | {'兜底%':>6} "
              f"{'过渡':>4} {'全局':>4} | {'欠报':>4} {'过报':>4} | top均值")
        for v in vals:
            r = run_once(cases, llm_cache, base_cfg, {key: v}, tmp_path)
            r["sweep_key"] = key
            r["sweep_value"] = v
            rows.append(r)
            print(f"  {v:>6} | {r['answer_rate']:>6} {r['standard_qa_direct']:>6} {r['normal_answer']:>5} | "
                  f"{r['fallback_rate']:>6} {r['mid_fallback']:>4} {r['global_fallback']:>4} | "
                  f"{r['under_answer']:>4} {r['over_answer']:>4} | {r['top_score_mean']}")
    scan_sec = time.time() - t0

    # ---------------- 落盘 ----------------
    json.dump({"baseline": baseline, "sweeps": rows,
               "corpus_variant": H.CORPUS_VARIANT, "corpus_note": H.CORPUS_NOTE},
              open(os.path.join(OUT, "threshold_scan_llm.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)

    import csv
    with open(os.path.join(OUT, "threshold_scan_llm.csv"), "w", encoding="utf-8-sig",
              newline="") as f:
        w = csv.writer(f)
        w.writerow(["sweep_key", "sweep_value", "n", "answer_rate", "standard_qa_direct",
                    "normal_answer", "fallback_rate", "mid_fallback", "global_fallback",
                    "conflict_fallback", "under_answer", "over_answer",
                    "top_score_mean", "top_score_min", "top_score_max"])
        for r in rows:
            w.writerow([r["sweep_key"], r["sweep_value"], r["n"], r["answer_rate"],
                        r["standard_qa_direct"], r["normal_answer"], r["fallback_rate"],
                        r["mid_fallback"], r["global_fallback"], r["conflict_fallback"],
                        r["under_answer"], r["over_answer"], r["top_score_mean"],
                        r["top_score_min"], r["top_score_max"]])

    md = ["# 阈值扫描（真实向量相似度，零 LLM 成本）", ""]
    md.append(f"- 语料变体：`{H.CORPUS_VARIANT}`")
    md.append(f"- 回放缓存：`{os.path.basename(cache_path)}`（{len(llm_cache)} 条，复用主运行的改写/分类结果）")
    md.append(f"- 用例：{len(cases)} 条；扫描耗时 {scan_sec:.1f}s")
    md.append("")
    md.append("> " + H.CORPUS_NOTE)
    md.append("")
    md.append("## 基线")
    md.append("")
    md.append("| 指标 | 值 |")
    md.append("|---|---|")
    for k in ("answer_rate", "standard_qa_direct", "normal_answer", "fallback_rate",
              "mid_fallback", "global_fallback", "conflict_fallback", "under_answer",
              "over_answer", "top_score_mean", "top_score_min", "top_score_max"):
        md.append(f"| {k} | {baseline[k]} |")
    md.append("")
    md.append("## 单维扫描")
    md.append("")
    md.append("| 阈值 | 取值 | 作答% | 标准QA直答 | 正常回答 | 兜底% | 过渡 | 全局 | 欠报 | 过报 | top均值 |")
    md.append("|---|---|---|---|---|---|---|---|---|---|---|")
    for r in rows:
        md.append(f"| `{r['sweep_key']}` | {r['sweep_value']} | {r['answer_rate']} | "
                  f"{r['standard_qa_direct']} | {r['normal_answer']} | {r['fallback_rate']} | "
                  f"{r['mid_fallback']} | {r['global_fallback']} | {r['under_answer']} | "
                  f"{r['over_answer']} | {r['top_score_mean']} |")
    md.append("")
    open(os.path.join(OUT, "threshold_scan_llm.md"), "w", encoding="utf-8").write("\n".join(md))

    print(f"\n扫描完成 {scan_sec:.1f}s -> out/threshold_scan_llm.md / .csv / .json")


if __name__ == "__main__":
    main()
