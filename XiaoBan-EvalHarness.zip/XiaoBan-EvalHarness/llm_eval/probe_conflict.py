"""
冲突路由探针：列出「检出规则冲突」的用例，以及它们的期望分支/维度/当前判定。
用途：修 D3（节点补写 is_real_conflict）前后对比，看清这批用例是不是真的该走冲突兜底。

⚠️ 修正记录（2026-09-15）：原实现直接 `if out.get("rule_conflict_detected")`，
   而 trace 里该值是**字符串** "False"（truthy）→ 恒判为检出，历史上报出的
   「28/38 条检出冲突」是**假的**。现统一走 trace_util.as_bool。

用法：
  python probe_conflict.py [tag]
"""
from __future__ import annotations

import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding="utf-8")

from trace_util import as_bool, as_list, load_traces, node_out  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, "out")

TAG = sys.argv[1] if len(sys.argv) > 1 else "fix_d3"
traces = load_traces(OUT, TAG)
cases = {c["test_id"]: c for c in
         [json.loads(l) for l in
          open(os.path.join(ROOT, "data", "testset_118.v1.1.jsonl"),
               encoding="utf-8").read().strip().split("\n")]}

checked = detected = real = tiered = 0
rows = []
for tid, r in sorted(traces.items()):
    out = node_out(r, "rule_conflict_check")
    if out is None:
        continue
    checked += 1
    d = as_bool(out.get("rule_conflict_detected"))
    rc = as_bool(out.get("is_real_conflict"))
    ti = as_bool(out.get("is_tiered_rule"))
    if d:
        detected += 1
    if rc:
        real += 1
    if ti:
        tiered += 1
    rows.append((tid, d, rc, ti, out))

print(f"tag={TAG}   执行过 rule_conflict_check 的用例：{checked} 条")
print(f"  其中 rule_conflict_detected=True : {detected} 条")
print(f"  其中 is_real_conflict=True       : {real} 条")
print(f"  其中 is_tiered_rule=True（命中阶梯规则而跳过判定）: {tiered} 条")
print()

if detected:
    print(f"  {'用例':<10} {'期望分支':<26} {'终态':<30} half")
    for tid, d, rc, ti, out in rows:
        if not d:
            continue
        r = traces[tid]
        c = cases.get(tid, {})
        print(f"  {tid:<10} {(c.get('expected_branch') or '-')[:24]:<26} "
              f"{(r.get('terminal_node') or '-')[:28]:<30} {r['judge']['half']}")
        print(f"      冲突详情: {str(out.get('rule_conflict_details'))[:150]}")

print("\n--- 全量规模参照 ---")
print(f"  118 条中，期望分支里含「冲突」的用例："
      f"{[t for t, c in cases.items() if '冲突' in str(c.get('expected_branch') or '')]}")
print(f"  维度=制度冲突校验 的用例："
      f"{[t for t, c in cases.items() if '冲突' in str(c.get('test_dimension') or '')]}")
print(f"  （注：维度字段名是 test_dimension，此前脚本误用 dim 导致读出全空）")
term = {}
for tid, r in traces.items():
    term[r.get("terminal_node")] = term.get(r.get("terminal_node"), 0) + 1
print("\n  终端节点分布：")
for k, v in sorted(term.items(), key=lambda x: -x[1]):
    print(f"    {k}: {v}")
print(f"  冲突兜底(conflict_fallback)实际触发条数："
      f"{sum(1 for r in traces.values() if 'conflict_fallback' in str(r.get('terminal_node')))}")
