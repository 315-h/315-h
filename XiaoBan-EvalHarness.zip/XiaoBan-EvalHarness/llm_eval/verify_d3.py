"""复核 D3 修复的真实影响面（用 trace_util 正确解析，避免字符串真值陷阱）。

回答三个问题：
  1. D3 到底改变了什么（误报数、字段写入、路由）？
  2. 指标差异里哪些是 D3 贡献、哪些是 LLM 采样噪声？
  3. 本测试集能否验证「冲突兜底」这条分支？
"""
from __future__ import annotations

import os
import sys
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding="utf-8")

from trace_util import as_bool, load_traces, node_out  # noqa: E402

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "out")
TAGS = ["full", "fix_d1d2", "noise_a", "fix_d5", "fix_d5b", "fix_d3"]
data = {t: load_traces(OUT, t) for t in TAGS}

print("=" * 76)
print("1. 精确终端节点分布（按 case 计数，不归类）")
print("=" * 76)
for t in TAGS:
    c = Counter(r.get("terminal_node") for r in data[t].values())
    print(f"{t:10s} n={len(data[t]):3d}")
    for k, v in c.most_common():
        print(f"           {k}: {v}")

print()
print("=" * 76)
print("2. rule_conflict_check 节点行为对比（D3 真正的落点）")
print("=" * 76)
print(f"{'tag':10s} {'执行':>4s} {'detected':>9s} {'is_real':>8s} {'is_tiered':>10s} {'冲突兜底':>8s}")
for t in TAGS:
    ex = det = real = ti = cf = 0
    for r in data[t].values():
        o = node_out(r, "rule_conflict_check")
        if o is None:
            continue
        ex += 1
        det += as_bool(o.get("rule_conflict_detected"))
        real += as_bool(o.get("is_real_conflict"))
        ti += as_bool(o.get("is_tiered_rule"))
        if "conflict_fallback" in str(r.get("terminal_node")):
            cf += 1
    print(f"{t:10s} {ex:>4d} {det:>9d} {real:>8d} {ti:>10d} {cf:>8d}")

print()
print("=" * 76)
print("3. fix_d5b -> fix_d3：路由变化 vs 文本变化")
print("=" * 76)
ids = sorted(set(data["fix_d5b"]) & set(data["fix_d3"]))
route_ch = [(i, data["fix_d5b"][i].get("terminal_node"), data["fix_d3"][i].get("terminal_node"))
            for i in ids if data["fix_d5b"][i].get("terminal_node") != data["fix_d3"][i].get("terminal_node")]
text_ch = [i for i in ids if (data["fix_d5b"][i].get("answer") or "") != (data["fix_d3"][i].get("answer") or "")]
judge_ch = [i for i in ids if data["fix_d5b"][i]["judge"]["half"] != data["fix_d3"][i]["judge"]["half"]]
print(f"路由变化: {len(route_ch)} 条 {route_ch}")
print(f"判定(half)变化: {len(judge_ch)} 条 {judge_ch}")
print(f"答案文本变化: {len(text_ch)} 条")
print()
print("判断：D3 只改 rule_conflict_* 字段，而这些字段仅被 conflict_fallback_answer_node 消费；")
print("      冲突兜底触发 0 条 ⇒ D3 对路由与答案内容的影响应为 0。")
print("      故上面观察到的文本/判定差异只能归因于 LLM 采样非确定性。")

print()
print("=" * 76)
print("4. 采样噪声基线（同配置不同次运行：fix_d1d2 vs noise_a）")
print("=" * 76)
for t in ["fix_d1d2", "noise_a"]:
    r = data[t]
    n = len(r)
    h = sum(1 for x in r.values() if x["judge"]["half"])
    a = sum(1 for x in r.values() if x["judge"]["anyhit"])
    s = sum(1 for x in r.values() if x["judge"]["strict"])
    print(f"{t:10s} strict={s/n*100:.1f}%  half={h/n*100:.1f}%  anyhit={a/n*100:.1f}%")
txt = [i for i in ids if (data["fix_d1d2"][i].get("answer") or "") != (data["noise_a"][i].get("answer") or "")]
print(f"同配置两次运行之间，答案文本就变了 {len(txt)} 条 → 文本级差异不能作为改动效果的证据")

print()
print("=" * 76)
print("5. 本测试集对「冲突兜底」分支的覆盖度")
print("=" * 76)
import json  # noqa: E402

cases = {c["test_id"]: c for c in
         [json.loads(l) for l in open(os.path.join(os.path.dirname(OUT), "data", "testset_118.v1.1.jsonl"),
                                      encoding="utf-8").read().strip().split("\n")]}
exp_cf = [t for t, c in cases.items() if "冲突" in str(c.get("expected_branch") or "")]
print(f"期望分支含「冲突」的用例: {exp_cf}")
for t in exp_cf:
    r = data["fix_d3"].get(t, {})
    ran = node_out(r, "rule_conflict_check") is not None
    print(f"  {t}: 期望={(cases[t].get('expected_branch') or '')[:30]} | 实际={r.get('terminal_node')} | 走到冲突节点={ran}")
print(f"维度含「冲突」的用例（字段=test_dimension）: "
      f"{[t for t, c in cases.items() if '冲突' in str(c.get('test_dimension') or '')]}")
print("→ 结论：期望冲突的用例在上游被标准QA直答短路，从未到达冲突节点；")
print("  测试集里没有任何一条用例能验证 conflict_fallback_answer。")
