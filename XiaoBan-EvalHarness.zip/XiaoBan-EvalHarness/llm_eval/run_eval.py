"""
小办 · 真实 LLM 复现评测 · 主运行器
========================================================
用法：
  python run_eval.py                     # 全量 118 条（真实 DeepSeek + Qwen 向量）
  python run_eval.py --tag full          # 打标签，产物带后缀
  python run_eval.py --workers 4         # 并发度
  python run_eval.py --limit 5           # 冒烟
  python run_eval.py --variant qonly     # 语料消融：仅问题侧
  python run_eval.py --cases data/testset_xxx.jsonl --only TC-C01,TC-C02
  python run_eval.py --fixtures data/corpus_fixtures.json   # 按用例注入语料
"""
from __future__ import annotations

import argparse
import collections
import concurrent.futures as cf
import json
import os
import sys
import time
import traceback

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding="utf-8")

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, "out")
os.makedirs(OUT, exist_ok=True)

import harness as H  # noqa: E402
import run_pipeline as RP  # noqa: E402


def load_cases(path: str):
    return [json.loads(l) for l in open(path, encoding="utf-8").read().strip().split("\n")]


def expect_fallback(branch_text: str) -> bool:
    b = branch_text or ""
    if "兜底" in b and "正常回答" not in b:
        return True
    if "正常回答" in b or "标准QA" in b or "直接输出" in b or "组装输出" in b:
        return False
    return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", default="llm")
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--variant", default=None, choices=[None, "full", "qonly"])
    ap.add_argument("--cases", default=os.path.join(ROOT, "data", "testset_118.v1.1.jsonl"))
    ap.add_argument("--only", default="",
                    help="只跑指定用例，逗号分隔（如 TC-C01,TC-C02）；用于低成本定向验证")
    ap.add_argument("--fixtures", default="",
                    help="按用例注入语料的 fixture 文件（不传 = 不启用，保证与历史轮次可比）")
    args = ap.parse_args()

    if args.variant:
        os.environ["XIAOBAN_CORPUS_VARIANT"] = args.variant
        H.CORPUS_VARIANT = args.variant  # 模块常量在 import 时已固化，这里显式覆盖

    fixtures_path = args.fixtures or None
    fx = H.load_fixtures(fixtures_path)

    tag = args.tag
    cases = load_cases(args.cases)
    if args.only:
        want = {s.strip() for s in args.only.split(",") if s.strip()}
        cases = [c for c in cases if c["test_id"] in want]
        missing = want - {c["test_id"] for c in cases}
        if missing:
            print(f"⚠️ --only 指定的用例不在文件里: {sorted(missing)}")
    if args.limit:
        cases = cases[:args.limit]

    # P1：冲突分支常驻回归集（FC-CF01/CF02）。启用语料注入且非定向(--only)时，
    # 自动随全量一起跑，单独分母报告（不计入 118 主口径）。
    fc_cases = []
    if fx and not args.only:
        fc_path = os.path.join(ROOT, "data", "testset_fixture_conflict.jsonl")
        if os.path.exists(fc_path):
            fc_cases = load_cases(fc_path)
            print(f"冲突回归集: {os.path.relpath(fc_path, ROOT)}  |  {len(fc_cases)} 条（单独分母）")

    print(f"语料变体: {H.CORPUS_VARIANT}  |  用例 {len(cases)} 条  |  并发 {args.workers}")
    print(f"生成后端: {H.LLM_BACKEND} / {H.LLMClient.backend_model()}  |  嵌入: "
          f"{os.getenv('QWEN_EMBED_MODEL', 'text-embedding-v3')}")
    if fx:
        applied = [c["test_id"] for c in cases if c["test_id"] in fx]
        print(f"语料注入: {os.path.relpath(fixtures_path, ROOT)}  |  文件含 {len(fx)} 条 fixture  |  "
              f"本轮命中 {len(applied)} 条 {applied}")
    else:
        print("语料注入: 未启用（基础语料全量）")
    needs = [c["test_id"] for c in (cases + fc_cases) if c.get("needs_fixture")]
    if needs:
        missing = [t for t in needs if t not in fx]
        if missing:
            print(f"⚠️ 以下用例声明 needs_fixture 但本轮没有对应 fixture，**必然失败**"
                  f"（这是场景装配问题，不是引擎缺陷）：{missing}")
        else:
            print(f"✅ needs_fixture 用例已全部装配语料：{needs}")
    H.STORE.load()
    print(f"语料: {len(H.STORE.tables['standard_qa_kb'])} 篇\n")

    t0 = time.time()
    # P1：冲突回归集（FC-*）与主集（118）分开存放，保证单独分母。
    all_jobs = [(c, False) for c in cases]
    if fc_cases:
        all_jobs += [(c, True) for c in fc_cases]
    results, fc_results, failures = [], [], []
    total_jobs = len(all_jobs)
    with cf.ThreadPoolExecutor(max_workers=args.workers) as ex:
        futs = {ex.submit(RP.run_case, c, True, "full", None): (c, is_fc) for c, is_fc in all_jobs}
        done = 0
        for fut in cf.as_completed(futs):
            c, is_fc = futs[fut]
            done += 1
            try:
                r = fut.result()
                (fc_results if is_fc else results).append(r)
                mark = "OK " if r["judge"]["half"] else "MISS"
                tag = "FC " if is_fc else "   "
                print(f"  [{done:3d}/{total_jobs}] {tag}{mark} {r['test_id']:<9} "
                      f"{(r['terminal_node'] or '-'):<26} half={r['judge']['half']} "
                      f"strict={r['judge']['strict']} kw={r['judge']['kw_ratio']:.2f} "
                      f"{r['elapsed_ms']:.0f}ms")
            except Exception as e:  # noqa: BLE001
                failures.append({"test_id": c["test_id"], "error": f"{type(e).__name__}: {e}",
                                 "tb": traceback.format_exc()[-800:]})
                print(f"  [{done:3d}/{total_jobs}] FAIL {c['test_id']}: {type(e).__name__}: {e}")

    results.sort(key=lambda r: r["test_id"])
    elapsed = time.time() - t0
    n = len(results)
    if n == 0:
        print("无成功用例，退出")
        return

    # ---------------- 指标 ----------------
    def rate(pred) -> float:
        return round(sum(1 for r in results if pred(r)) / n * 100, 1)

    def by_field(field: str):
        acc = collections.defaultdict(lambda: {"n": 0, "strict": 0, "half": 0, "anyhit": 0})
        for r in results:
            k = str(r.get(field) or "?")
            a = acc[k]
            a["n"] += 1
            for cal in ("strict", "half", "anyhit"):
                if r["judge"][cal]:
                    a[cal] += 1
        out = {}
        for k, a in acc.items():
            out[k] = {"n": a["n"],
                      "strict": round(a["strict"] / a["n"] * 100, 1),
                      "half": round(a["half"] / a["n"] * 100, 1),
                      "anyhit": round(a["anyhit"] / a["n"] * 100, 1)}
        return dict(sorted(out.items(), key=lambda kv: -kv[1]["n"]))

    branch_dist = collections.Counter((r["terminal_node"] or "?").split("(")[0] for r in results)
    fallback_cases = [r["test_id"] for r in results if r["judge"]["is_fallback_answer"]]

    under = [r["test_id"] for r in results
             if not expect_fallback(next((c.get("expected_branch") for c in cases
                                          if c["test_id"] == r["test_id"]), ""))
             and r["judge"]["is_fallback_answer"]]
    over = [r["test_id"] for r in results if r["judge"]["forbidden_hit"]]
    defect_counter = collections.Counter(
        f for r in results for f in (r.get("defect_flags") or []))

    verdict_coze = {c["test_id"]: c.get("verdict_coze") for c in cases}
    verdict_demo = {c["test_id"]: c.get("verdict_demo") for c in cases}

    def align(verdict_key: str, pred):
        src = verdict_coze if verdict_key == "verdict_coze" else verdict_demo
        agree = mism = 0
        mism_ids = []
        for r in results:
            v = (src.get(r["test_id"]) or "").strip().lower()
            if v not in ("pass", "fail", "fall", "半pass"):
                continue
            their_pass = v in ("pass", "半pass")
            my_pass = bool(pred(r))
            if their_pass == my_pass:
                agree += 1
            else:
                mism += 1
                mism_ids.append(r["test_id"])
        tot = agree + mism
        return {"n": tot, "agree": agree, "rate": round(agree / tot * 100, 1) if tot else 0.0,
                "mismatch": mism_ids}

    summary = {
        "tag": tag,
        "run_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "engine": "生产节点源码（13 节点原样复用）+ 真实 LLM + Qwen text-embedding-v3 真实向量",
        "generation_backend": {"backend": H.LLM_BACKEND, "model": H.LLMClient.backend_model()},
        "corpus_variant": H.CORPUS_VARIANT,
        "corpus_note": H.CORPUS_NOTE,
        "fixtures": {
            "file": (os.path.relpath(fixtures_path, ROOT) if fixtures_path else None),
            "declared": sorted(fx.keys()),
            "applied": sorted(r["test_id"] for r in results if (r.get("fixture") or {}).get("applied")),
        },
        "cases_file": os.path.relpath(args.cases, ROOT),
        "total": n,
        "failures": len(failures),
        "elapsed_sec": round(elapsed, 1),
        "rates": {
            "strict_full_hit": rate(lambda r: r["judge"]["strict"]),
            "half_50pct_hit": rate(lambda r: r["judge"]["half"]),
            "anyhit_lenient": rate(lambda r: r["judge"]["anyhit"]),
            "forbidden_hit": rate(lambda r: bool(r["judge"]["forbidden_hit"])),
        },
        "produced_fallback_answer": {"n": len(fallback_cases), "rate": round(len(fallback_cases) / n * 100, 1)},
        "under_answer": {"n": len(under), "cases": under},
        "over_answer_forbidden_hit": {"n": len(over), "cases": over},
        "defects": dict(defect_counter),
        "terminal_branch_dist": dict(branch_dist),
        "by_priority": by_field("priority"),
        "by_layer": by_field("layer"),
        "by_dimension": by_field("dim"),
        "std_qa_direct": {"n": sum(1 for r in results if (r["terminal_node"] or "").startswith("normal_answer(标准QA直答)")),
                          "rate": rate(lambda r: (r["terminal_node"] or "").startswith("normal_answer(标准QA直答)"))},
        "align_with_archived": {
            "coze_workspace(half)": align("verdict_coze", lambda r: r["judge"]["half"]),
            "coze_workspace(anyhit)": align("verdict_coze", lambda r: r["judge"]["anyhit"]),
            "local_demo(half)": align("verdict_demo", lambda r: r["judge"]["half"]),
            "local_demo(anyhit)": align("verdict_demo", lambda r: r["judge"]["anyhit"]),
        },
        "llm_usage": H.USAGE.snapshot(),
    }

    # ---- P0'：必须转人工 硬门汇总（仅统计主集 118 内声明 requires_handoff 的用例）----
    mh_flagged = [r for r in results if r["judge"].get("requires_handoff")]
    mh_fail = [r for r in mh_flagged if r["judge"].get("must_handoff_fail")]
    summary["must_handoff_gate"] = {
        "n_flagged": len(mh_flagged),
        "fail": len(mh_fail),
        "fail_cases": [r["test_id"] for r in mh_fail],
    }

    # ---- P1：冲突分支常驻回归集（单独分母，不计入 118 主口径）----
    if fc_results:
        n_fc = len(fc_results)
        summary["conflict_regression_set"] = {
            "n": n_fc,
            "cases": [r["test_id"] for r in fc_results],
            "strict": round(sum(1 for r in fc_results if r["judge"]["strict"]) / n_fc * 100, 1),
            "half": round(sum(1 for r in fc_results if r["judge"]["half"]) / n_fc * 100, 1),
            "anyhit": round(sum(1 for r in fc_results if r["judge"]["anyhit"]) / n_fc * 100, 1),
            "by_case": {r["test_id"]: {"terminal": r["terminal_node"],
                                       "strict": r["judge"]["strict"],
                                       "half": r["judge"]["half"],
                                       "anyhit": r["judge"]["anyhit"]}
                        for r in fc_results},
        }

    # ---------------- 落盘 ----------------
    with open(os.path.join(OUT, f"traces_llm_{tag}.jsonl"), "w", encoding="utf-8") as f:
        for r in results:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    with open(os.path.join(OUT, f"summary_llm_{tag}.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    # 供阈值扫描回放，避免重复花 LLM 费用
    cache = {r["test_id"]: {"query_rewrite": r["query_rewrite"],
                            "split_questions": r["split_questions"],
                            "biz_type": r["biz_type"],
                            "biz_types": r["biz_types"]}
             for r in results}
    with open(os.path.join(H.CACHE_DIR, f"llm_cache_{tag}.json"), "w", encoding="utf-8") as f:
        json.dump(cache, f, ensure_ascii=False)

    # ---------------- 控制台 ----------------
    print("\n" + "=" * 64)
    print(f"三口径（n={n}）")
    print(f"  全命中 strict      : {summary['rates']['strict_full_hit']}%")
    print(f"  50%口径 half       : {summary['rates']['half_50pct_hit']}%")
    print(f"  宽松 anyhit        : {summary['rates']['anyhit_lenient']}%")
    print(f"  禁词命中 forbidden : {summary['rates']['forbidden_hit']}%")
    print(f"  输出兜底话术       : {summary['produced_fallback_answer']['rate']}%  ({len(fallback_cases)} 条)")
    print(f"  欠报(该答却兜底)   : {summary['under_answer']['n']} 条 {under}")
    print(f"  过报(命中禁词)     : {summary['over_answer_forbidden_hit']['n']} 条")
    print(f"  标准QA直答         : {summary['std_qa_direct']['rate']}%")
    print(f"  生产缺陷命中       : {dict(defect_counter) or '无'}")
    print("\n终端分支分布:")
    for k, v in branch_dist.most_common():
        print(f"  {k:<28} {v:3d}  ({v / n * 100:5.1f}%)")
    fx_rows = [r for r in results if (r.get("fixture") or {}).get("applied")]
    if fx_rows:
        print("\n语料注入用例明细（注：trace 里的字段值是字符串，此处原样打印不做真值判断）:")
        for r in sorted(fx_rows, key=lambda x: x["test_id"]):
            rc = None
            for nd in (r.get("trace") or {}).get("nodes") or []:
                if nd.get("node") == "rule_conflict_check":
                    rc = nd.get("out") or {}
            print(f"  {r['test_id']:<9} 终端={r.get('terminal_node') or '-':<28} "
                  f"conflict_detected={(rc or {}).get('rule_conflict_detected', '未执行')!s:<6} "
                  f"real={(rc or {}).get('is_real_conflict', '-')!s:<6} half={r['judge']['half']}")
    print("\n分层（layer）:")
    for k, v in summary["by_layer"].items():
        print(f"  {k:<14} n={v['n']:3d}  strict {v['strict']:5.1f}%  half {v['half']:5.1f}%  anyhit {v['anyhit']:5.1f}%")
    print("\n优先级:")
    for k, v in summary["by_priority"].items():
        print(f"  {k:<6} n={v['n']:3d}  strict {v['strict']:5.1f}%  half {v['half']:5.1f}%  anyhit {v['anyhit']:5.1f}%")
    print("\n与归档判定对齐:")
    for k, v in summary["align_with_archived"].items():
        print(f"  {k:<24} {v['agree']}/{v['n']} = {v['rate']}%   不一致 {len(v['mismatch'])} 条")
    print(f"\nLLM 用量: {json.dumps(summary['llm_usage'], ensure_ascii=False)}")
    # P0'：必须转人工 硬门
    mh = summary["must_handoff_gate"]
    print(f"\n必须转人工硬门(must_handoff): 标记 {mh['n_flagged']} 条  |  失败 {mh['fail']} 条 {mh['fail_cases']}")
    # P1：冲突回归集
    if "conflict_regression_set" in summary:
        cf_set = summary["conflict_regression_set"]
        print(f"冲突回归集(单独分母 n={cf_set['n']}): strict {cf_set['strict']}%  half {cf_set['half']}%  anyhit {cf_set['anyhit']}%")
        for cid, cv in cf_set["by_case"].items():
            print(f"  {cid:<9} 终端={cv['terminal'] or '-':<26} strict={cv['strict']} half={cv['half']} anyhit={cv['anyhit']}")
    print(f"耗时 {elapsed:.1f}s  ->  out/traces_llm_{tag}.jsonl  out/summary_llm_{tag}.json")

    if failures:
        with open(os.path.join(OUT, f"failures_llm_{tag}.json"), "w", encoding="utf-8") as f:
            json.dump(failures, f, ensure_ascii=False, indent=2)
        print(f"失败 {len(failures)} 条 -> out/failures_llm_{tag}.json")


def _biz_types_of(r):
    return None


if __name__ == "__main__":
    main()
