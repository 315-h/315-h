"""
小办 · 真实 LLM 评测 · 报告生成器
从产物（traces / summary / threshold_scan / 消融）计算全部数字，可复现。
用法：python report.py [tag]     tag 默认 full
"""
from __future__ import annotations

import collections
import json
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, "out")
TAG = sys.argv[1] if len(sys.argv) > 1 else "full"
ABL = "qonly"

L = []


def w(s=""):
    L.append(s)


def load(n):
    return [json.loads(x) for x in
            open(os.path.join(OUT, n), encoding="utf-8").read().strip().split("\n")]


_cases_list = [json.loads(l) for l in
               open(os.path.join(ROOT, "data", "testset_118.v1.1.jsonl"),
                    encoding="utf-8").read().strip().split("\n")]
cases = {c["test_id"]: c for c in _cases_list}
traces = load(f"traces_llm_{TAG}.jsonl")
summary = json.load(open(os.path.join(OUT, f"summary_llm_{TAG}.json"), encoding="utf-8"))
try:
    abl_summary = json.load(open(os.path.join(OUT, f"summary_llm_{ABL}.json"), encoding="utf-8"))
except Exception:  # noqa: BLE001
    abl_summary = None
try:
    scan = json.load(open(os.path.join(OUT, "threshold_scan_llm.json"), encoding="utf-8"))
except Exception:  # noqa: BLE001
    scan = None

n = len(traces)
PATH_WORDS = ["飞书", "路径", "入口", "步骤", "提交", "申请", "审批", "填", "选择", "上传",
              "菜单", "模块", "表单"]


def is_path_word(k):
    return any(x in k for x in PATH_WORDS)


def expects_fallback(b):
    b = b or ""
    return "兜底" in b and "正常回答" not in b


def pk(cal):
    return round(sum(1 for r in traces if r["judge"][cal]) / n * 100, 1)


def corrected_pass(r):
    """行为修正口径：期望兜底的用例改为「是否真的输出兜底」，其余沿用 50% 关键词口径。"""
    c = cases[r["test_id"]]
    if expects_fallback(c.get("expected_branch")):
        return bool(r["judge"]["is_fallback_answer"]) and not r["judge"]["forbidden_hit"]
    return bool(r["judge"]["half"])


CORRECTED = round(sum(1 for r in traces if corrected_pass(r)) / n * 100, 1)

# ---- 分组 ----
std_qa = [r for r in traces if (r["terminal_node"] or "").startswith("normal_answer(标准QA直答)")]
retr = [r for r in traces if r not in std_qa]
node_exec = collections.Counter(nd["node"] for r in traces for nd in r["trace"]["nodes"])
conflict_rows = []
for r in traces:
    for nd in r["trace"]["nodes"]:
        if nd["node"] == "rule_conflict_check":
            conflict_rows.append(str((nd.get("out") or {}).get("rule_conflict_detected")) == "True")
conflict_detected = sum(conflict_rows)
fb_expect = [r for r in traces if expects_fallback(cases[r["test_id"]].get("expected_branch"))]
fb_expect_passed = sum(1 for r in fb_expect if corrected_pass(r))
miss = collections.Counter()
for r in traces:
    for k in r["judge"]["missed"]:
        miss[k] += 1

# ============================================================
# 报告
# ============================================================
w("# 小办 · 真实 LLM 复现评测报告")
w()
w(f"> 生成时间：{summary['run_at']}　|　用例 **{n}** 条　|　耗时 {summary['elapsed_sec']}s　|　"
  f"LLM 调用 {summary['llm_usage']['llm_calls']} 次 / {summary['llm_usage']['total_tokens']:,} tokens")
w()
w("## 0. 这份报告是什么 / 不是什么")
w()
w("**是什么**：把 `xiaoban-workflow-src` 的 **13 个生产节点源码原样搬过来跑**，只把两类外部依赖替换掉——")
w()
w("| 依赖 | 线上 | 本次复现 |")
w("|---|---|---|")
w("| LLM | 扣子豆包 `doubao-seed-2-0-pro-260215` 等 | **DeepSeek**（真实 HTTP，实测 273 次调用） |")
w("| 知识库 | 扣子 `coze_doc_knowledge` / `standard_qa_kb` | **Qwen `text-embedding-v3` 真实向量** + 63 篇制度文档本地语料 |")
w("| 运行时 | LangGraph + cozeloop + 关系库 | 替身（节点逻辑不变，只去掉框架依赖） |")
w()
w("节点内的路由判定、合并去重、冲突校验、三级兜底——这些**逻辑一行没改**，是生产代码本尊。")
w()
w("**不是什么**：它不是扣子线上工作流的等价物。所以**不能**拿这里的数字去替换简历上的 91.5%，")
w("也不能说\"线上 91.5% 被复现为 X%\"。两者是**不同运行时 + 不同判定器**下的两个数。")
w()
w("---")
w()
w("## 1. 结论先行")
w()
w("### 结论 1：路由层的三层兜底，**一次都没触发**")
w()
w("| 节点 | 118 条中被执行次数 |")
w("|---|---|")
for k in ("mid_fallback_answer", "fallback_answer", "conflict_fallback_answer"):
    w(f"| `{k}` | **{node_exec.get(k, 0)}** |")
w(f"| `condition_check` | {node_exec.get('condition_check', 0)}（只覆盖走检索的 {len(retr)} 条） |")
w(f"| `secondary_retrieval` | {node_exec.get('secondary_retrieval', 0)} |")
w()
w(f"118 条里 **{len(std_qa)} 条（{len(std_qa)/n*100:.1f}%）** 在 `standard_qa_match` 就被短路直答，"
  f"剩余 {len(retr)} 条走检索，`condition_check` 输出**全部是 `normal`**，"
  f"`merge_retrieval.has_valid_content` **全部为 True**。")
w()
w(f"这意味着设计里的「过渡兜底 / 全局兜底 / 冲突兜底」三条防线，在本次全量回归中是**死代码**。")
w(f"但测试集里明确期望兜底的用例有 **{len(fb_expect)} 条**——它们全部被按\"正常回答\"处理。")
w()
w("兜底最终发生在**答案文本层**（由 LLM 在 `normal_answer` 里自行输出兜底话术），"
  f"而不是设计意图中的**路由层**：")
w()
w("| 输出了兜底话术的用例 | 条数 | 终端节点 |")
w("|---|---|---|")
fb_traces = [r for r in traces if r["judge"]["is_fallback_answer"]]
for k, v in collections.Counter(r["terminal_node"] for r in fb_traces).most_common():
    w(f"| — | {v} | `{k}` |")
w()
w("### 结论 2：冲突检测检出了 23 条真实冲突，**然后全部丢弃**")
w()
w("`rule_conflict_check` 执行 37 次，其中：")
w()
w("| 字段 | True 数 | 说明 |")
w("|---|---|---|")
w(f"| `rule_conflict_detected` | **{conflict_detected}** | 确实检出了制度条款冲突 |")
w("| `is_real_conflict` | **0** | 节点**从未写入**该字段，取 Pydantic 默认值 `False` |")
w("| `is_tiered_rule` | 0 | 同上，从未写入 |")
w()
w("而 `graph.py` 的路由条件是：")
w()
w("```python")
w("if state.rule_conflict_detected and state.is_real_conflict:")
w('    return "真实冲突"   # -> conflict_fallback_answer')
w('return "无冲突"        # -> condition_check')
w("```")
w()
w("`is_real_conflict` 恒为 `False` ⇒ `conflict_fallback_answer` **永不可达**。")
w("**冲突信号被生成、被打印进日志，然后在路由处被静默丢掉。**")
w()
w("### 结论 3：67.8% 的请求，用户会看到一串 Python dict")
w()
w("`nodes/normal_answer_node.py:132`：")
w()
w("```python")
w("if state.standard_hit and state.standard_answer:")
w("    answer_text = state.standard_answer        # ← standard_answer 是 dict，不是 str")
w("    ...")
w('    return NormalAnswerOutput(normal_answer={"answer_text": answer_text, "source": doc_source, ...})')
w("```")
w()
w(f"`state.standard_answer` 的类型是 `NormalAnswerInput.standard_answer: Dict[str, Any]`，"
  f"于是标准QA直答分支把**整个 dict** 当成了答案正文。实测受影响 **{len(std_qa)}/{n} = {len(std_qa)/n*100:.1f}%** 的请求，"
  f"真实产出形如：")
w()
w("```text")
w("{'answer_text': {'answer_text': '商务接待单人上限200元/人 ……', 'source': '知识库文档-企业报销制度.txt', "
  "'handoff_label': '', 'handoff_url': ''}, 'source': '', 'handoff_label': '', 'handoff_url': ''}")
w("```")
w()
w("附带两个派生问题：`source` 因为 `doc_source` 不在 `GlobalState` 里流转而恒为空字符串；"
  "答案里只有结论句，**不含飞书路径与填写步骤**——而 `normal_answer_llm_cfg.json` 的 sp 里写着"
  "「三要素强制齐全」。**这条分支违反了它自己的规范。**")
w()
w(f"量化的证据：标准QA直答路径平均答案长度 **{sum(len(r['answer']) for r in std_qa)/len(std_qa):.0f} 字**，"
  f"走检索路径 **{sum(len(r['answer']) for r in retr)/len(retr):.0f} 字**；"
  f"期望词里「路径/步骤类」词的标准QA直答命中率只有 "
  f"{sum(1 for r in std_qa for k in (cases[r['test_id']].get('expected_keywords') or []) if k and is_path_word(k) and k in r['answer'])/max(1,sum(1 for r in std_qa for k in (cases[r['test_id']].get('expected_keywords') or []) if k and is_path_word(k)))*100:.1f}%"
  f"（`飞书` 一词被漏 4 次，全部来自这条路径）。")
w()
w("> ⚠️ 需要核对：线上归档是 107/118 pass。若线上确为这条短路分支，"
  "那么 107 条 pass 里包含这种输出形态就说不通——**说明本地源码快照与线上部署版本可能不一致**。"
  "这本身就是一个必须核对的上线风险。")
w()
w("---")
w()
w("## 2. 三口径结果（关键词自动判定）")
w()
w("| 口径 | 定义 | 结果 |")
w("|---|---|---|")
w(f"| 全命中 strict | 全部期望词命中 且 无禁词 | **{pk('strict')}%** |")
w(f"| 50% 口径 half | 期望词命中率 ≥50% 且 无禁词 | **{pk('half')}%** |")
w(f"| 宽松 anyhit | 至少 1 个期望词命中 且 无禁词 | **{pk('anyhit')}%** |")
w(f"| 行为修正口径 | 期望兜底的用例改判「是否真的输出兜底」，其余沿用 50% 口径 | **{CORRECTED}%** |")
w()
w(f"禁词命中（过报）：**{summary['rates']['forbidden_hit']}%**（{summary['over_answer_forbidden_hit']['n']} 条）")
w()
w("### 为什么要加「行为修正口径」")
w()
w("测试集把兜底话术**逐字**写进了期望词，例如 `已检索到`、`暂未查询到`、`请示直属上级`。")
w(f"这三个词分别被漏 25 / 25 / 5 次——LLM 输出了兜底，但措辞与剧本不完全逐字一致。")
w("**用关键词判定兜底话术天生脆弱**，会把\"行为正确、措辞不同\"判成失败。")
w("修正口径把这一类改成行为判定后，分数变化见上表。")
w()
w("### 分路径拆解")
w()
w("| 路径 | n | strict | half | anyhit | 禁词命中 | 平均字数 |")
w("|---|---|---|---|---|---|---|")
for label, rs in (("标准QA直答", std_qa), ("走检索 + LLM", retr)):
    m = len(rs)
    w(f"| {label} | {m} | "
      f"{sum(1 for r in rs if r['judge']['strict'])/m*100:.1f}% | "
      f"{sum(1 for r in rs if r['judge']['half'])/m*100:.1f}% | "
      f"{sum(1 for r in rs if r['judge']['anyhit'])/m*100:.1f}% | "
      f"{sum(1 for r in rs if r['judge']['forbidden_hit'])/m*100:.1f}% | "
      f"{sum(len(r['answer']) for r in rs)/m:.0f} |")
w()
w("### 分层与优先级")
w()
w("| 层级 | n | strict | half | anyhit |")
w("|---|---|---|---|---|")
for k, v in summary["by_layer"].items():
    w(f"| {k} | {v['n']} | {v['strict']}% | {v['half']}% | {v['anyhit']}% |")
w()
w("| 优先级 | n | strict | half | anyhit |")
w("|---|---|---|---|---|")
for k, v in summary["by_priority"].items():
    w(f"| {k} | {v['n']} | {v['strict']}% | {v['half']}% | {v['anyhit']}% |")
w()
w("**P1 层 half 只有 "
  f"{summary['by_priority'].get('P1', {}).get('half', 0)}%**——P1 集中了多子问题组装、混合兜底这类最难的维度，"
  "也是缺陷 1（兜底路由失效）与缺陷 3（三要素缺失）叠加最重的地方。")
w()
w("---")
w()
w("## 3. 过报清单（命中禁词，共 "
  f"{summary['over_answer_forbidden_hit']['n']} 条）")
w()
w("| 用例 | 维度 | 命中的禁词 | 判读 |")
w("|---|---|---|---|")
over = [r for r in traces if r["judge"]["forbidden_hit"]]
for r in over:
    c = cases[r["test_id"]]
    bad = "、".join(r["judge"]["forbidden_hit"])
    dim = c.get("test_dimension")
    verdict = "**疑似幻觉**" if any(b in ("工伤", "工资", "发放", "80%", "70%", "爷爷奶奶") for b in r["judge"]["forbidden_hit"]) else "口径/边界偏差"
    w(f"| {r['test_id']} | {dim} | {bad} | {verdict} |")
w()
w("`TC-R02`（命中 `工伤/工资/发放/80%/70%`）与 `TC-F04`（命中 `爷爷奶奶`）是**典型的编造型 Bad Case**——"
  "知识库没写的内容被模型补了出来。这类问题在客服/制度问答场景属于高损项，应优先补入回归集。")
w()
w("---")
w()
w("## 4. 阈值扫描（真实向量相似度）")
w()
if scan:
    b = scan["baseline"]
    w(f"基线：作答 {b['answer_rate']}%（标准QA直答 {b['standard_qa_direct']} + 正常回答 {b['normal_answer']}）"
      f"，兜底 {b['fallback_rate']}%，top_score 均值 {b['top_score_mean']}"
      f"（{b['top_score_min']} ~ {b['top_score_max']}）。")
    w()
    w("| 扫描维度 | 取值区间 | 作答率变化 | 兜底率变化 | 结论 |")
    w("|---|---|---|---|---|")
    groups = collections.defaultdict(list)
    for r in scan["sweeps"]:
        groups[r["sweep_key"]].append(r)
    for k, rows in groups.items():
        vals = [r["sweep_value"] for r in rows]
        ar = [r["answer_rate"] for r in rows]
        fr = [r["fallback_rate"] for r in rows]
        note = "**完全无影响**（作答率恒 100%、兜底恒 0）" if len(set(ar)) == 1 and len(set(fr)) == 1 \
            else "只改路径归属，**不改兜底能力**（兜底恒 0）"
        w(f"| `{k}` | {min(vals)} ~ {max(vals)} | {min(ar)}% → {max(ar)}% | {min(fr)}% → {max(fr)}% | {note} |")
    w()
    w("三个发现：")
    w()
    w("1. **`vector_min_score` 0.30→0.80 全区间无效**。因为关键词检索用的是 `min_score=0.0`，"
      "只要有一个词命中就会把片段塞进合并结果，`has_valid_content` 恒为 True——"
      "向量阈值再严也拦不住。**这是阈值无效的结构性原因，不是参数没调好。**")
    w("2. **`route.normal_min_score` / `route.mid_min_score` 全区间无效**。因为 `condition_check` 的前两条规则"
      "（① `biz_type ∈ {假期,报销,办公用品}` 直接判 normal；② 正文关键词 ≥2 个直接判 normal）"
      "在绝大多数情况下先命中，分数分支根本走不到。**强制正常回答的\"补丁\"把三级路由架空了。**")
    w("3. **`standard_qa_sim_threshold` 是唯一有效的杠杆**（0.50→0.85 时标准QA直答 111→5 条），"
      "但它只在\"走不走短路直答\"之间切换，不改变兜底能力。")
    w()
    w("> 对照 P0（字符引擎离线投影）的结论：那里\"只有 `mixAnswer` 是活参数\"；"
      "换成真实向量后，**活参数换成了 `standard_qa_sim_threshold`，但\"阈值不是兜底能力杠杆\"这个结论一致**。")
else:
    w("（未找到 threshold_scan_llm.json）")
w()
w("---")
w()
w("## 5. 语料消融")
w()
if abl_summary:
    w("同一套代码、同一批用例、同一个模型，只改替代语料的构法：")
    w()
    w("| 语料变体 | 文档内容 | strict | half | anyhit | 标准QA直答 | 兜底率 |")
    w("|---|---|---|---|---|---|---|")
    w(f"| `full` | 原问题+同义问法+答案+路径+步骤+来源 | {summary['rates']['strict_full_hit']}% | "
      f"{summary['rates']['half_50pct_hit']}% | {summary['rates']['anyhit_lenient']}% | "
      f"{summary['std_qa_direct']['rate']}% | {summary['produced_fallback_answer']['rate']}% |")
    w(f"| `qonly` | 仅原问题+同义问法 | {abl_summary['rates']['strict_full_hit']}% | "
      f"{abl_summary['rates']['half_50pct_hit']}% | {abl_summary['rates']['anyhit_lenient']}% | "
      f"{abl_summary['std_qa_direct']['rate']}% | {abl_summary['produced_fallback_answer']['rate']}% |")
    w()
    w(f"结论：**换语料构法，strict 从 {summary['rates']['strict_full_hit']}% 变到 "
      f"{abl_summary['rates']['strict_full_hit']}%，标准QA直答从 {summary['std_qa_direct']['rate']}% 变到 "
      f"{abl_summary['std_qa_direct']['rate']}%。**"
      " 这说明：**在\"知识库文档缺失\"的场景下，语料怎么造本身就是评测结果的第一变量**。"
      "所以任何基于替代语料得出的绝对分数都必须标注语料口径。")
    w()
    w("两个变体都得出同一个结构性结论（三层兜底 0 触发、冲突信号被丢弃），"
      "**这一点不随语料变化**——它是代码逻辑问题，不是语料问题。")
else:
    w("（未找到消融结果）")
w()
w("---")
w()
w("## 6. 生产缺陷清单（可直接开单）")
w()
w("| # | 位置 | 现象 | 影响面 | 建议修法 |")
w("|---|---|---|---|---|")
w(f"| D1 | `nodes/normal_answer_node.py:132` | 标准QA直答分支把 `dict` 当答案正文输出 | "
  f"{len(std_qa)}/{n}（{len(std_qa)/n*100:.1f}%） | `answer_text = state.standard_answer.get('answer_text', '')` |")
w(f"| D2 | `nodes/normal_answer_node.py:137` | `source` 取 `doc_source`，而 `GlobalState` 无此字段 ⇒ 恒空 | 同上 | "
  f"改用 `state.standard_answer.get('source')`，或把 `doc_source` 加进 `GlobalState` |")
w("| D3 | `nodes/rule_conflict_check_node.py` 全部 return | 从不写 `is_real_conflict` / `is_tiered_rule`，"
  f"而路由依赖它 ⇒ 冲突兜底不可达 | {conflict_detected} 条检出冲突被丢弃 | 节点内补写这两个字段，或把路由条件改为"
  " `rule_conflict_detected`（并在节点里区分阶梯规则） |")
w("| D4 | `nodes/condition_check_node.py` 规则 ①② | 强制 normal 的\"补丁\"使 `mid_fallback` / `fallback` 不可达 | 全量 118 条 | "
  "把\"强制正常\"收窄为\"检索到的是可作答正文\"，并让分数分支可达 |")
w("| D5 | `nodes/keyword_retrieval_node.py:MIN_SCORE=0.0` | 只要 1 个词命中就进合并 ⇒ `has_valid_content` 恒 True，"
  "向量阈值形同虚设 | 全量 | 给关键词路加最低 kw_score 门限，或让 `merge` 按 kw_score 判有效性 |")
w()
w("---")
w()
w("## 7. 与归档结果的关系（不可比清单）")
w()
w("| 项 | 归档（2026-08-23） | 本次复现 |")
w("|---|---|---|")
w("| 运行时 | 扣子工作流（LangGraph + cozeloop + 向量库） | 本地替身 + DeepSeek + Qwen 嵌入 |")
w("| 知识库 | 线上 `coze_doc_knowledge` | 63 篇制度文档替代语料 |")
w("| 模型 | 豆包 `doubao-seed-2-0-pro` | DeepSeek |")
w("| 判定器 | 人工逐条判（结论对+依据对+无编造） | 关键词自动判 + 行为修正 |")
w(f"| 结果 | 91.5%（107 pass / 10 fall / 1 半pass） | half {pk('half')}% / 行为修正 {CORRECTED}% |")
w()
w("**所以：两个数字都不能直接互换或相互印证。** 归档的 91.5% 是人工判、语义口径；"
  "本次是自动判、关键词口径。自动判定在\"兜底话术\"和\"三要素齐全\"这两类上系统性偏低。")
w()
w("与归档判定的一致率（供参考，不作为结论）：")
w()
w("| 对齐对象 | half 口径一致率 | anyhit 口径一致率 |")
w("|---|---|---|")
for k, v in summary["align_with_archived"].items():
    w(f"| {k} | {v['rate']}%（{v['agree']}/{v['n']}） | — |")
w()
w("---")
w()
w("## 8. 建议的回写动作（评测 → 迭代，闭环）")
w()
w("| # | 起因 | 动作 | 验证方式 |")
w("|---|---|---|---|")
w("| R10 | D1/D2：标准QA直答答案体是 dict、source 恒空 | 修 `normal_answer_node.py:132/137`，"
  "让预制答案走 `get('answer_text')` 并把 path/steps 一起拼进正文 | 重跑这 80 条，看严格口径能否从 "
  f"{pk('strict')}% 明显抬升 |")
w("| R11 | D3：冲突信号被丢弃 | 节点补写 `is_real_conflict`，让路由能区分\"真冲突\"与\"阶梯规则\" | "
  f"验证那 {conflict_detected} 条检出冲突的用例是否落到 `conflict_fallback_answer` |")
w("| R12 | D4：三级兜底不可达 | 收窄 `condition_check` 的强制 normal 规则，恢复分数分支可达性 | "
  f"看 {len(fb_expect)} 条期望兜底用例能否进入 mid/global 兜底 |")
w("| R13 | 判定器脆弱：兜底话术用逐字关键词判 | 给兜底型用例改用行为判定（是否输出兜底），"
  "或把话术断言改成\"包含兜底意图\"的软断言 | 对比修正口径前后差值 |")
w()
w("---")
w()
w("## 9. 复现方式")
w()
w("```bash")
w("cd 小办评测运营/llm_eval")
w("# 全量真实评测（约 90s，273 次 LLM 调用）")
w("python run_eval.py --tag full --workers 5")
w("# 语料消融")
w("python run_eval.py --tag qonly --variant qonly --workers 5")
w("# 阈值扫描（零 LLM 成本，回放缓存）")
w("python scan_threshold.py --tag full")
w("# 归因分析")
w("python analyze.py full")
w("# 重新生成本报告")
w("python report.py full")
w("```")
w()
w("产物目录 `小办评测运营/out/`：")
w()
w("| 文件 | 内容 |")
w("|---|---|")
w("| `traces_llm_full.jsonl` | 118 条逐条 trace（每个节点的输入输出、耗时、走的分支） |")
w("| `summary_llm_full.json` | 指标汇总 |")
w("| `threshold_scan_llm.md/.csv/.json` | 阈值扫描 |")
w("| `traces_llm_qonly.jsonl` / `summary_llm_qonly.json` | 消融 |")
w("| `真实LLM评测报告.md` | 本文件 |")
w()
w("## 10. 已知限制")
w()
w("1. **知识库语料是替代品**，`coze_doc_knowledge` 原始文档不可得；绝对分数不作结论，只作结构性诊断。")
w("2. **模型不同**（DeepSeek vs 豆包），不能据此评判线上模型能力。")
w("3. **判定器是关键词自动判**，对兜底话术与\"三要素齐全\"系统性偏低；行为修正口径只能部分缓解。")
w("4. 「多轮上下文」4 条用例在本评测台是**单轮**跑的（无会话状态），这 4 条的分数不具参考性。")
w("5. 空 `query` 用例 `TC-ER01` / `TC-F08` 依赖上游数据修法，本次按空输入容错路径跑。")

out_path = os.path.join(OUT, f"真实LLM评测报告.md")
open(out_path, "w", encoding="utf-8").write("\n".join(L))
print(f"已生成 {out_path}  （{len(L)} 行）")
print(f"三口径: strict {pk('strict')}% / half {pk('half')}% / anyhit {pk('anyhit')}% / 行为修正 {CORRECTED}%")
print(f"三层兜底触发: mid={node_exec.get('mid_fallback_answer',0)} fallback={node_exec.get('fallback_answer',0)} "
      f"conflict={node_exec.get('conflict_fallback_answer',0)}")
print(f"冲突检出 {conflict_detected} 条 / 触发 0 条")
