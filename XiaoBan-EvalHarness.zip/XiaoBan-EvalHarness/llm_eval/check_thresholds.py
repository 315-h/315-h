"""
阈值配置自检：确认 eval_thresholds.json 是合法 JSON，且节点读到的就是配置里的值。
这条检查是刚需——JSON 写坏时 get_threshold 会静默回落默认值，
评测会「跑得好好的但用的是旧阈值」，非常难发现（本次就踩了一次尾逗号）。
用法：
  python check_thresholds.py
"""
from __future__ import annotations

import importlib
import json
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import harness as H  # noqa: E402

path = os.path.join(H.CONFIG_DIR, "eval_thresholds.json")
print(f"配置文件：{path}")

raw = open(path, encoding="utf-8").read()
try:
    cfg = json.loads(raw)
    print("JSON 解析：OK")
except Exception as e:  # noqa: BLE001
    print(f"JSON 解析：**失败** —— {type(e).__name__}: {e}")
    print("  ⇒ 此时节点会静默回落代码默认值，评测结果不代表配置！")
    sys.exit(1)

th = importlib.import_module("graphs.nodes.thresholds")
print(f"thresholds 读取路径：{getattr(th, 'CONFIG_PATH', '(未暴露)')}")

KEYS = [
    ("retrieval.vector_min_score", 0.6),
    ("retrieval.keyword_min_score", 0.0),
    ("retrieval.secondary_min_score", 0.0),
    ("retrieval.standard_qa_sim_threshold", 0.70),
    ("merge.vector_weight", 0.65),
    ("merge.keyword_weight", 0.35),
    ("route.normal_min_score", 0.6),
    ("route.mid_min_score", 0.2),
]
ok = True
print(f"\n  {'键':<40} {'配置值':<10} {'节点读到':<10} {'代码默认':<10} 判定")
for key, default in KEYS:
    sec, k = key.split(".")
    want = cfg.get(sec, {}).get(k, "(缺键)")
    got = th.get_threshold(key, default)
    flag = "OK"
    if want != "(缺键)" and abs(float(got) - float(want)) > 1e-9:
        flag = "**不一致**"
        ok = False
    if want == "(缺键)":
        flag = "缺键(走默认)"
    print(f"  {key:<40} {str(want):<10} {str(got):<10} {str(default):<10} {flag}")

# 顺手检查节点模块级常量是否与配置一致（模块导入时就固化了）
CHECKS = [
    ("keyword_retrieval_node", "MIN_SCORE", "retrieval.keyword_min_score"),
    ("secondary_retrieval_node", "SECONDARY_MIN_SCORE", "retrieval.secondary_min_score"),
    ("merge_retrieval_node", "VECTOR_WEIGHT", "merge.vector_weight"),
    ("condition_check_node", "ROUTE_NORMAL_MIN", "route.normal_min_score"),
]
print(f"\n  {'节点常量':<44} 值")
for mod, attr, key in CHECKS:
    try:
        m = importlib.import_module(f"graphs.nodes.{mod}")
        v = getattr(m, attr, "(无此属性)")
        exp_sec, exp_k = key.split(".")
        want = cfg.get(exp_sec, {}).get(exp_k)
        flag = "" if want is None or abs(float(v) - float(want)) < 1e-9 else "  **与配置不一致**"
        if flag:
            ok = False
        print(f"  {mod}.{attr:<30} {v}{flag}")
    except Exception as e:  # noqa: BLE001
        print(f"  {mod}.{attr:<30} 加载失败 {type(e).__name__}: {e}")
        ok = False

print("\n结论：" + ("全部一致，配置生效" if ok else "**存在不一致，请先修配置再跑评测**"))
sys.exit(0 if ok else 1)
