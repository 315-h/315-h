"""
路由探针（零 LLM 成本，复用 llm_cache 回放）。
目的：为 D4 量化「condition_check 前两条强制 normal 规则」到底吃掉了多少用例，
并对比几种收窄方案的后果，改代码前先把影响面试算清楚。

方案对照：
  current   —— 现状：① biz_type ∈ 核心业务 → normal（无条件）
  fixA      —— 方案A：① 额外要求「检索文本确实含该业务的 ≥2 个业务词」
  fixB      —— 方案B：删掉①，纯按 top_score 三级路由
  fixC      —— 方案C：① 额外要求 top_score ≥ route.mid_min_score

用法：
  python probe_route.py [tag]
"""
from __future__ import annotations

import collections
import json
import os
import sys
from typing import Any, Dict, List

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import harness as H  # noqa: E402

H.STORE.load()
S = H.load_states()

TAG = sys.argv[1] if len(sys.argv) > 1 else "full"
cfg = json.load(open(os.path.join(H.CONFIG_DIR, "eval_thresholds.json"), encoding="utf-8"))
R_NORMAL = cfg["route"]["normal_min_score"]
R_MID = cfg["route"]["mid_min_score"]
MASTERY = set(cfg["route"]["mastery_biz_types"])
KW_MIN = cfg["retrieval"]["keyword_min_score"]
print(f"配置：route.normal_min_score={R_NORMAL} route.mid_min_score={R_MID} "
      f"mastery={sorted(MASTERY)} keyword_min_score={KW_MIN}\n")

cache = json.load(open(os.path.join(H.CACHE_DIR, f"llm_cache_{TAG}.json"), encoding="utf-8"))
cases = [json.loads(l) for l in
         open(os.path.join(os.path.dirname(H.EVAL_DIR), "data", "testset_118.v1.1.jsonl"),
              encoding="utf-8").read().strip().split("\n")]

BUSINESS_KEYWORDS = {
    "假期": ["假期", "年假", "病假", "事假", "婚假", "产假", "陪产假", "丧假", "调休", "请假", "休假", "工作日"],
    "报销": ["报销", "发票", "补贴", "出差", "宴请", "培训", "加班", "费用", "报账", "审批"],
    "办公用品": ["办公用品", "鼠标", "键盘", "显示器", "纸张", "文具", "申领", "设备", "耗材", "采购", "维修"],
}
Node = lambda mod, fn: H.load_node(mod, fn)  # noqa: E731


def has_biz_content(text: str, biz: str) -> bool:
    kws = BUSINESS_KEYWORDS.get(biz) or []
    if not text or not kws:
        return False
    return sum(1 for k in kws if k in text) >= 2


def branch_current(biz, score, text):
    if biz in MASTERY:
        return "normal"
    if text.strip() and has_biz_content(text, biz):
        return "normal"
    return _by_score(score, text)


def branch_fixA(biz, score, text):
    if biz in MASTERY and has_biz_content(text, biz):
        return "normal"
    if text.strip() and has_biz_content(text, biz):
        return "normal"
    return _by_score(score, text)


def branch_fixB(biz, score, text):
    return _by_score(score, text)


def branch_fixC(biz, score, text):
    if biz in MASTERY and score >= R_MID:
        return "normal"
    if text.strip() and has_biz_content(text, biz):
        return "normal"
    return _by_score(score, text)


def _by_score(score, text):
    if score >= R_NORMAL and text.strip():
        return "normal"
    if score >= R_MID:
        return "mid_fallback"
    return "fallback"


rows: List[Dict[str, Any]] = []
n_std = n_invalid = 0
for c in cases:
    cached = cache.get(c["test_id"])
    if not cached:
        continue
    g = {
        "user_input": c.get("query") or "",
        "query_rewrite": cached.get("query_rewrite", ""),
        "split_questions": cached.get("split_questions", []),
        "biz_type": cached.get("biz_type", "其他"),
        "biz_types": cached.get("biz_types", []),
    }
    qa = H.call_node(Node("standard_qa_match_node", "standard_qa_match_node"), S.StandardQaMatchInput, g)
    g.update(qa.model_dump())
    if qa.all_sub_questions_hit:
        n_std += 1
        continue
    vr = H.call_node(Node("vector_retrieval_node", "vector_retrieval_node"), S.VectorRetrievalInput, g)
    g.update(vr.model_dump())
    kr = H.call_node(Node("keyword_retrieval_node", "keyword_retrieval_node"), S.KeywordRetrievalInput, g)
    g.update(kr.model_dump())
    mg = H.call_node(Node("merge_retrieval_node", "merge_retrieval_node"), S.MergeRetrievalInput, g)
    if not mg.has_valid_content:
        n_invalid += 1
        continue
    text = mg.knowledge_retrieval or ""
    biz = cached.get("biz_type", "其他")
    score = float(mg.top_score or 0)
    rows.append({
        "id": c["test_id"], "biz": biz, "score": score,
        "has_biz": has_biz_content(text, biz),
        "cur": branch_current(biz, score, text),
        "A": branch_fixA(biz, score, text),
        "B": branch_fixB(biz, score, text),
        "C": branch_fixC(biz, score, text),
    })

print(f"用例：标准QA直答 {n_std} 条（不进本节点） | has_valid=False（走二次检索）{n_invalid} 条 "
      f"| **走到 condition_check {len(rows)} 条**\n")

print("=== 现状" + "：" + "规则①（核心业务强制 normal）命中 "+f"{sum(1 for r in rows if r['biz'] in MASTERY)}/{len(rows)} 条" + " ===")
print(f"  规则① 命中：{sum(1 for r in rows if r['biz'] in MASTERY)}/{len(rows)}")
print(f"  规则② 若①不存在、单独命中：{sum(1 for r in rows if r['biz'] not in MASTERY and r['has_biz'])} 条")
print(f"  规则③（分数分支）若①②都不存在会走到的分支：")
for k, v in collections.Counter(r["B"] for r in rows).most_common():
    print(f"    {k:<14} {v}")

print("\n=== 各方案下的分支分布 ===")
print(f"  {'用例':<10} {'业务':<8} {'top_score':<10} {'含业务正文':<8} {'现状':<14} {'方案A':<14} {'方案B':<14} {'方案C':<14}")
for r in sorted(rows, key=lambda x: x["score"]):
    mark = "  <-- 变" if len({r["cur"], r["A"], r["B"], r["C"]}) > 1 else ""
    print(f"  {r['id']:<10} {r['biz']:<8} {r['score']:<10.4f} {str(r['has_biz']):<8} "
          f"{r['cur']:<14} {r['A']:<14} {r['B']:<14} {r['C']:<14}{mark}")

print("\n=== 汇总 ===")
for name in ("cur", "A", "B", "C"):
    cc = collections.Counter(r[name] for r in rows)
    changed = sum(1 for r in rows if r[name] != r["cur"])
    print(f"  {name:<4} normal={cc.get('normal', 0):<3} mid_fallback={cc.get('mid_fallback', 0):<3} "
          f"fallback={cc.get('fallback', 0):<3} | 相对现状改变 {changed} 条")

print("\n=== top_score 分布（走到 condition_check 的用例）===")
sc = sorted(r["score"] for r in rows)
if sc:
    n = len(sc)
    print(f"  min={sc[0]:.4f} 中位={sc[n // 2]:.4f} max={sc[-1]:.4f}")
    for th in (R_MID, 0.3, 0.4, 0.5, R_NORMAL, 0.7):
        print(f"    >= {th}: {sum(1 for s in sc if s >= th)} 条")
