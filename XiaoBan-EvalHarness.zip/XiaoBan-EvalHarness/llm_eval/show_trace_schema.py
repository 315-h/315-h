"""查看 trace JSONL 结构（只看第一条记录的键与各节点字段形态）。"""
import json
import sys

path = sys.argv[1] if len(sys.argv) > 1 else r"C:\Users\Lenovo\WorkBuddy\经历翻译官网页\小办评测运营\out\traces_llm_fix_d3.jsonl"

with open(path, encoding="utf-8") as f:
    first = json.loads(f.readline())

print("顶层键:", list(first.keys()))
tr = first.get("trace") or {}
print("trace 键:", list(tr.keys()) if isinstance(tr, dict) else type(tr))
nodes = tr.get("nodes") if isinstance(tr, dict) else None
if nodes:
    print(f"nodes 条数: {len(nodes)}")
    for n in nodes:
        keys = list(n.keys()) if isinstance(n, dict) else "?"
        print("  -", n.get("node") if isinstance(n, dict) else n, "| keys:", keys)
        if isinstance(n, dict):
            out = n.get("output")
            if isinstance(out, dict):
                print("      output keys:", list(out.keys()))
                print("      output:", json.dumps(out, ensure_ascii=False)[:600])
            else:
                print("      output:", str(out)[:400])
