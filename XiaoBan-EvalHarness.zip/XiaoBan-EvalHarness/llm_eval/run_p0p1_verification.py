"""P0' + P1 一体化验证编排（Shell 恢复后单命令执行）。

流程：
  1) 离线负对照 verify_handoff（纯 judge 逻辑，零 LLM）
  2) subprocess: DeepSeek 后端跑全量 118 + FC 回归集  -> v12_fx_p0p1
  3) subprocess: 千问后端跑同名全量                 -> v12_fx_p0p1_qwen
  4) 读两份 summary，对比 must_handoff_gate / conflict_regression_set，出结论

用法：
  python run_p0p1_verification.py
"""
from __future__ import annotations
import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, "out")
os.makedirs(OUT, exist_ok=True)

sys.path.insert(0, HERE)
import run_pipeline as RP  # noqa: E402


# ---------------- 1) 离线负对照 ----------------
def offline_checks() -> bool:
    DISCREPANCY = ["存在差异", "存在规则冲突", "存在冲突", "制度不一致", "规定不一致",
                   "两版规定", "两种制度", "多个版本", "版本不一致", "制度冲突"]
    HANDOFF = ["hr@company.com", "咨询 HR", "联系 HR", "咨询人力", "请示直属上级",
               "与上级确认", "请与财务确认", "与财务确认", "财务确认"]
    cases = [
        ("T1", True, [DISCREPANCY, HANDOFF],
         "公司两版制度对加班打车费的规定存在差异，建议咨询 HR 确认以最新版为准。"),
        ("T2", True, [DISCREPANCY, HANDOFF],
         "加班打车费可以报销，但两版制度存在差异，以最新版为准：打车费不可报销。"),
        ("T3", False, [DISCREPANCY, HANDOFF],
         "加班打车费可以报销，但两版制度存在差异，以最新版为准：打车费不可报销。"),
        ("T4", False, [DISCREPANCY, HANDOFF],
         "报销需先由财务审核，提交发票后三个工作日到账。"),
    ]
    ok = True
    print("\n=== [1] 离线负对照 verify_handoff ===")
    for cid, req, groups, ans in cases:
        j = RP.judge(ans, {"requires_handoff": req, "expected_any": groups})
        if cid == "T1":
            ok &= (j["must_handoff_fail"] is False and j["strict"] is True)
        elif cid == "T2":
            ok &= (j["must_handoff_fail"] is True and not j["strict"] and not j["half"] and not j["anyhit"])
        elif cid == "T3":
            ok &= (j["must_handoff_fail"] is False and j["half"] is True and j["strict"] is False)
        elif cid == "T4":
            ok &= (j["must_handoff_fail"] is False and j["requires_handoff"] is False)
        print(f"  {cid}: req={j['requires_handoff']} handoff={j['handoff_present']} "
              f"fail={j['must_handoff_fail']} strict={j['strict']} half={j['half']} anyhit={j['anyhit']}")
    print("  结果:", "ALL PASS" if ok else "FAILED")
    return ok


# ---------------- 2/3) 子进程跑两套后端 ----------------
def run_backend(backend: str, tag: str) -> bool:
    env = dict(os.environ)
    env["XIAOBAN_LLM_BACKEND"] = backend
    cmd = [sys.executable, "run_eval.py", "--tag", tag, "--workers", "5",
           "--cases", "data/testset_118.v1.2.jsonl",
           "--fixtures", "data/corpus_fixtures.json"]
    log = os.path.join(OUT, f"console_{tag}.txt")
    print(f"\n=== [run] backend={backend} tag={tag} (日志 {log}) ===")
    with open(log, "w", encoding="utf-8") as f:
        proc = subprocess.run(cmd, cwd=HERE, env=env, stdout=f, stderr=subprocess.STDOUT)
    return proc.returncode == 0


def read_summary(tag: str) -> dict:
    p = os.path.join(OUT, f"summary_llm_{tag}.json")
    return json.load(open(p, encoding="utf-8"))


# ---------------- 4) 对比结论 ----------------
def compare(ds: dict, qw: dict) -> None:
    print("\n=== [2] DeepSeek vs 千问 对比（P0' 硬门价值验证）===")
    rows = [("strict", "strict_full_hit"), ("half", "half_50pct_hit"), ("anyhit", "anyhit_lenient")]
    print(f"  {'口径':<8}{'DeepSeek':>10}{'千问':>10}   备注")
    for label, key in rows:
        d = ds["rates"][key]
        q = qw["rates"][key]
        note = "逐位一致" if abs(d - q) <= 1.7 else "有差(噪声窗外需查)"
        print(f"  {label:<8}{d:>9.1f}%{q:>9.1f}%   {note}")

    print("\n  必须转人工硬门 must_handoff_gate:")
    for name, s in (("DeepSeek", ds), ("千问", qw)):
        mh = s.get("must_handoff_gate", {})
        print(f"    {name}: 标记 {mh.get('n_flagged')} 条 | 失败 {mh.get('fail')} 条 {mh.get('fail_cases')}")

    print("\n  冲突回归集 conflict_regression_set:")
    for name, s in (("DeepSeek", ds), ("千问", qw)):
        cf_set = s.get("conflict_regression_set")
        if cf_set:
            print(f"    {name}: n={cf_set['n']} strict={cf_set['strict']}% half={cf_set['half']}% "
                  f"anyhit={cf_set['anyhit']}% {cf_set['cases']}")
        else:
            print(f"    {name}: (未跑 FC 集)")

    # 结论判定
    ds_mh_fail = ds.get("must_handoff_gate", {}).get("fail", 0)
    qw_mh_fail = qw.get("must_handoff_gate", {}).get("fail", 0)
    ds_fc = ds.get("conflict_regression_set", {})
    qw_fc = qw.get("conflict_regression_set", {})
    print("\n--- 结论 ---")
    if ds_mh_fail == 0 and qw_mh_fail >= 1:
        print("  ✓ P0' 价值兑现：DeepSeek 下 TC-C02 不误杀，千问下硬门抓出 R33 的"
              "「必须转人工」跨模型回归（之前关键词口径 half 静默放过）。")
    elif ds_mh_fail == 0 and qw_mh_fail == 0:
        print("  • 两套后端 TC-C02 均未触发硬门（千问本轮未复现 R33 回归，硬门保持 standby）。")
    else:
        print(f"  ⚠ DeepSeek 硬门也失败 {ds_mh_fail} 条——需查 TC-C02 真实答案是否缺转人工。")
    for name, cf_set in (("DeepSeek", ds_fc), ("千问", qw_fc)):
        if cf_set and cf_set["strict"] == 100.0:
            print(f"  ✓ {name} 冲突回归集 FC-CF01/CF02 strict 100%（D6 修复稳定，无跨主题误判）。")
        elif cf_set:
            print(f"  ⚠ {name} 冲突回归集 strict={cf_set['strict']}%（有失败，需查）")


def main() -> int:
    offline_ok = offline_checks()
    if not offline_ok:
        print("\n离线负对照失败，终止（先修 judge 逻辑）。")
        return 1

    ds_ok = run_backend("deepseek", "v12_fx_p0p1")
    qw_ok = run_backend("qwen", "v12_fx_p0p1_qwen")
    if not (ds_ok and qw_ok):
        print("\n有后端运行失败，详见 out/console_v12_fx_p0p1*.txt")
        return 2

    ds = read_summary("v12_fx_p0p1")
    qw = read_summary("v12_fx_p0p1_qwen")
    compare(ds, qw)
    return 0


if __name__ == "__main__":
    sys.exit(main())
