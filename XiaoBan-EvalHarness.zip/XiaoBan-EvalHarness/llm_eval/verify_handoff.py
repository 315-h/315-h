"""P0' 离线单元验证：must_handoff 硬门（不依赖 LLM / 网络）。

负对照设计：
  T1  声明 requires_handoff + 答案含转人工指引  -> 不误杀（strict=True, fail=False）
  T2  声明 requires_handoff + 答案缺失转人工     -> 硬门必 FAIL（strict/half/anyhit 全 False）
  T3  同 T2 的答案但【不】声明 requires_handoff  -> 门不生效（证明只拦标记用例，向后兼容）
  T4  普通用例（无标记）答案含「财务」          -> 完全不受影响
"""
from __future__ import annotations
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import run_pipeline as RP  # noqa: E402

# 复用 TC-C02 的真实期望组，保证语义贴近线上
DISCREPANCY = ["存在差异", "存在规则冲突", "存在冲突", "制度不一致", "规定不一致",
               "两版规定", "两种制度", "多个版本", "版本不一致", "制度冲突"]
HANDOFF = ["hr@company.com", "咨询 HR", "联系 HR", "咨询人力", "请示直属上级",
           "与上级确认", "请与财务确认", "与财务确认", "财务确认"]

CASES = [
    # T1：标记 + 有转人工 -> 应通过
    {"id": "T1", "requires_handoff": True,
     "expected_any": [DISCREPANCY, HANDOFF],
     "answer": "公司两版制度对加班打车费的规定存在差异，建议咨询 HR 确认以最新版为准。"},
    # T2：标记 + 无转人工 -> 硬门必 FAIL
    {"id": "T2", "requires_handoff": True,
     "expected_any": [DISCREPANCY, HANDOFF],
     "answer": "加班打车费可以报销，但两版制度存在差异，以最新版为准：打车费不可报销。"},
    # T3：同答案但不标记 -> 门不生效（half 应 True，证明只拦标记用例）
    {"id": "T3", "requires_handoff": False,
     "expected_any": [DISCREPANCY, HANDOFF],
     "answer": "加班打车费可以报销，但两版制度存在差异，以最新版为准：打车费不可报销。"},
    # T4：普通用例含「财务」-> 不受影响
    {"id": "T4", "requires_handoff": False,
     "expected_any": [DISCREPANCY, HANDOFF],
     "answer": "报销需先由财务审核，提交发票后三个工作日到账。"},
]


def main():
    ok = True
    for c in CASES:
        j = RP.judge(c["answer"], {"requires_handoff": c["requires_handoff"],
                                   "expected_any": c["expected_any"]})
        flag = "✓" if True else "✗"
        line = (f"[{c['id']}] requires_handoff={j['requires_handoff']} "
                f"handoff_present={j['handoff_present']} must_handoff_fail={j['must_handoff_fail']} "
                f"strict={j['strict']} half={j['half']} anyhit={j['anyhit']}")
        # 断言
        if c["id"] == "T1":
            ok &= (j["must_handoff_fail"] is False and j["strict"] is True)
        elif c["id"] == "T2":
            ok &= (j["must_handoff_fail"] is True and j["strict"] is False
                   and j["half"] is False and j["anyhit"] is False)
        elif c["id"] == "T3":
            ok &= (j["must_handoff_fail"] is False and j["half"] is True
                   and j["strict"] is False)
        elif c["id"] == "T4":
            ok &= (j["must_handoff_fail"] is False and j["requires_handoff"] is False)
        print(f"{flag} {line}")
    print("\nRESULT:", "ALL PASS" if ok else "FAILED")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
