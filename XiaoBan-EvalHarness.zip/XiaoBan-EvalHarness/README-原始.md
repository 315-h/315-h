# 小办评测运营 · 工具链

> 闭环：**约束 → 执行 → 观测 → 评测 → 回写约束**
> 本目录承担后三步：**观测（trace）/ 评测（口径 + lint + 网格）/ 回写（记录表）**。

## 为什么需要它

原来小办的评测状态是：跑一批用例 → 得到一个通过率 → 存档。
问题有三个：

1. **没有留痕**：只有汇总数字，回答不了「这条为什么走了兜底」；
2. **没有口径**：一个百分比孤零零地放在文档里，换一种判定方式能差 40pt；
3. **没有回写**：报告出来后没有任何"据此改了什么"的记录 —— 这是「机械标注」和「评测运营」的分界线。

## 目录

```
小办评测运营/
├── engine/                    ① 字符引擎线（离线投影，第一轮）
│   ├── build_engine.py      从 xiaoban.html 抽取本地引擎 → xiaoban_engine.js（含阈值注入）
│   ├── xiaoban_engine.js    【自动生成，勿手改】离线可运行的引擎投影
│   ├── lib_eval.js          用例加载 / 三档判定口径 / 汇总（唯一判定实现）
│   ├── run_baseline.js      118 条全量评测 + JSONL trace
│   ├── lint_testset.py      测试集静态健康检查（BLOCKER / WARN / INFO）
│   ├── fix_testset.py       用例修复 + diff 生成
│   ├── bump_testset_v12.py  生成 v1.2 测试集（重写 TC-C01/C02 期望表达，规则写在代码里可复核）
│   ├── judge_selftest.py    判定器自检：向后兼容 / 行为级期望有效性 / 双线一致
│   ├── threshold_grid.js    阈值 1D / 2D 网格 + 候选搜索
│   ├── align_calibers.py    本次重跑 vs 归档人工判定的逐例对齐
│   ├── check_syntax.py      源码树 ast.parse 语法自检（绕开 Windows py_compile 的 os.devnull 坑）
│   ├── diff_vs_baseline.py  当前源码树 vs baseline 备份逐字节 diff（复核改动范围是否溢出）
│   └── describe_testset.py  测试集结构体检（维度 22 类分布 / 兜底分支覆盖度）
├── llm_eval/                  ② 真实模型线（生产节点 + 真 LLM + 真向量，第二轮）
│   ├── harness.py           替身注入：Coze SDK → DeepSeek / Qwen 嵌入；`graphs.*` 指向 Desktop 真源码
│   ├── run_pipeline.py      按 graph.py 真实路由驱动 13 个生产节点（节点逻辑零改动）
│   ├── run_eval.py          全量 118 条真实评测 + trace + 指标
│   ├── scan_threshold.py    阈值扫描（回放缓存，零 LLM 成本）
│   ├── analyze.py           归因分析（分路径 / 缺失词 / 兜底证据 / 缺陷影响面）
│   ├── report.py            生成《真实LLM评测报告.md》
│   ├── compare_runs.py      跨轮对比表（含噪声基线列 + 可比性守卫）
│   ├── trace_util.py        ⚠️ trace 读取工具：节点 out 的值是**字符串**，必须过 as_bool/as_list
│   ├── diff_runs_cases.py   逐例对比两个 tag 的任意字段（支持 judge.strict 等点号路径）
│   ├── probe.py             冒烟探针（节点可加载性 + 相似度分布 + 端到端 3 条）
│   ├── probe_kw.py          关键词分 / 嵌入相似度探针（零 LLM 成本）
│   ├── probe_route.py       condition_check 分支影响面探针
│   ├── probe_conflict.py    冲突检出探针（修 D3 前后对比）
│   ├── probe_stdqa.py       标准QA短路诊断：这条用例被哪篇文档短路掉的
│   ├── probe_corpus_rank.py 语料 top-N 排名（零 LLM 成本，写 fixture 必备）
│   ├── show_case_trace.py   单条用例完整节点轨迹 + 合并检索原文
│   ├── verify_d3.py         改动影响面复核（路由变化 / 文本变化 / 噪声对照 / 覆盖度）
│   ├── check_thresholds.py  阈值一致性断言（配置值 == 节点读到值，防静默回落）
│   ├── semantic_judge.py    🆕 第二判官：轻量语义判定（可切厂商 deepseek／qwen，三项事实 + 强制原文证据）
│   ├── bias_matrix.py       🆕 判官自评偏差矩阵（同用例两模型作答 × 两判官交叉评）
│   ├── show_trace_schema.py 打印 trace 结构（下结论前先确认取值形态）
│   ├── _peek_out_type.py    一次性诊断：确认 trace 里 out 的真实类型（字符串真值陷阱取证）
│   └── cache/               嵌入缓存 + LLM 回放缓存（可删，重跑会重建）
├── backup/                   baseline 备份（改动前的完整源码树快照）
├── data/
│   ├── testset_118.jsonl               v1.0 原始用例（保留不动）
│   ├── testset_118.v1.1.jsonl          v1.1 修复版（保留，供跨版本对账）
│   ├── testset_118.v1.2.jsonl          ✅ **当前基准集**（v1.1 + 重写 TC-C01/C02 期望表达）
│   ├── testset_fixture_conflict.jsonl  注入型探针（FC-CF01/02，**不计入 118 分母**）
│   ├── corpus_fixtures.json            按用例语料注入声明（配合 --fixtures）
│   ├── semantic_checks.json            🆕 语义判定项 + 纳入范围（_default / _cases）
│   └── semantic_judge_samples.jsonl    🆕 语义判官标注集（15 条 / 45 项，含真实输出与疑难样本）
├── out/                      全部产物（报告 / trace / csv / console 日志）
├── 迭代回写记录表.md           R1–R33 改动记录
├── 真实LLM评测报告.md         第二轮真实 LLM 复现评测报告（在 out/ 内）
├── 缺陷修复验证报告.md        ✅ 第三轮 D1–D5 修复与验证报告
├── 语料注入能力与冲突维度解锁报告.md  ✅ 第四轮 按用例语料注入 + 冲突分支打通
├── 用例期望改写与判定器升级报告.md    ✅ 第五轮 C01/C02 期望改写 + expected_any
├── 语义判定接入报告.md                ✅ 第六轮 第二判官 + 三重验证
├── 跨厂商判官与自评偏差报告.md        ✅ 第七轮 千问判官 + 2×2 偏差矩阵
├── 跨模型回归报告.md                  ✅ 第八轮 全量 118 换模型复跑
└── P0执行报告.md              P0 交付报告
```

## 两条评测线怎么分工

| | `engine/`（字符引擎线） | `llm_eval/`（真实模型线） |
|---|---|---|
| 被测对象 | `xiaoban.html` 里的本地字符匹配引擎 | **13 个生产节点源码**（原样复用） |
| LLM | 无 | **DeepSeek 真实调用** |
| 检索 | 字符/关键词 | **Qwen `text-embedding-v3` 真实向量** |
| 成本 | 0 | 118 条约 40 万 tokens（≈ 几毛钱） |
| 能回答 | 阈值有没有用、用例有没有病、口径差多少 | 三层兜底能不能触发、模型答得对不对、缺陷在哪一行 |
| 局限 | 天花板低，测不出模型能力 | 知识库语料是替代品，绝对分数不作结论 |

**两条线互相印证**：都得出「阈值不是兜底能力的杠杆」，但活参数不同（`mixAnswer` vs `standard_qa_sim_threshold`）。


## 跑起来

```bash
cd "C:/Users/Lenovo/WorkBuddy/经历翻译官网页/小办评测运营"

# ① 字符引擎线
python engine/lint_testset.py --file data/testset_118.v1.1.jsonl      # 健康检查
node   engine/run_baseline.js --file data/testset_118.v1.1.jsonl      # 全量评测 + trace
node   engine/threshold_grid.js                                       # 阈值网格
python engine/build_engine.py                                         # 引擎变更后重建投影

# ② 真实模型线（用 backend/.venv 的 python，它装了 openai / langchain_core / jinja2）
PY="C:/Users/Lenovo/WorkBuddy/经历翻译官网页/backend/.venv/Scripts/python.exe"
"$PY" llm_eval/probe.py                                     # 冒烟：节点可加载 + 相似度分布
"$PY" llm_eval/run_eval.py --tag full --workers 5            # 全量真实评测（约 90s）
"$PY" llm_eval/run_eval.py --tag qonly --variant qonly --workers 5   # 语料消融对照
"$PY" llm_eval/scan_threshold.py --tag full                  # 阈值扫描（零 LLM 成本）
"$PY" llm_eval/analyze.py full                               # 归因分析
"$PY" llm_eval/report.py full                                # 生成报告
```

密钥来源：`backend/.env` 的 `DEEPSEEK_API_KEY`（LLM）与 `QWEN_API_KEY`（`text-embedding-v3`）。
`llm_eval/cache/embed_cache.json` 缓存全部嵌入向量，删掉会重新嵌入（63 篇文档 + 118 条提问）。

复核 / 自检（改动前后都要跑）：

```bash
"$PY" engine/check_syntax.py                    # 源码树语法自检，应为 19/0
"$PY" llm_eval/check_thresholds.py              # 阈值一致性，应 8/8 OK（防配置写坏后静默回落）
"$PY" engine/diff_vs_baseline.py                # 改动范围逐字节复核（确认没溢出）
"$PY" engine/describe_testset.py                # 测试集结构体检（维度 / 分支覆盖度）
"$PY" llm_eval/compare_runs.py <tag...> --base <tag>   # 跨轮对比（含噪声基线列）
"$PY" llm_eval/verify_d3.py                     # 通用：改动影响面复核（路由 vs 文本 vs 噪声）
```

定向验证 / 语料注入：

```bash
# 只跑指定用例（省钱的定向验证）
"$PY" llm_eval/run_eval.py --tag mytag --only TC-C01,TC-C02 --workers 2

# 按用例注入语料（fixture）—— 不传 --fixtures 则与历史轮次完全可比
"$PY" llm_eval/run_eval.py --tag fixture_c01c02 --only TC-C01,TC-C02 \
      --fixtures data/corpus_fixtures.json --workers 2

# 注入型探针（不计入 118 分母）
"$PY" llm_eval/run_eval.py --tag fixture_conflict \
      --cases data/testset_fixture_conflict.jsonl \
      --fixtures data/corpus_fixtures.json --workers 2

# 查语料排名（零 LLM 成本）／查被哪篇文档短路／看单条用例完整轨迹
"$PY" llm_eval/probe_corpus_rank.py "事假最多能请几天？" --table coze_doc_knowledge
"$PY" llm_eval/probe_stdqa.py fix_d3 TC-C01 TC-C02
"$PY" llm_eval/show_case_trace.py fixture_c01c02 TC-C01 --retrieval
```

### 按用例语料注入（fixture）

有些用例的场景在**基础语料里根本不存在**（例如「制度冲突校验」需要两份互相矛盾的文件），
靠关键词判定永远测不出来——因为模型无从"看到"那个场景。`data/corpus_fixtures.json` 为这些用例声明专属语料：

```json
{
  "<test_id>": {
    "why": "为什么要注入（写给人看）",
    "tables": {
      "<表名>": {
        "exclude": ["要排除的基线 doc_id"],
        "append": [{ "doc_id": "可选", "content": "六行格式：问题/同义问法/答案/路径/步骤/来源" }]
      }
    }
  }
}
```

四条硬规则：

1. **表名有两张**：`standard_qa_kb`（标准QA短路命中用）与 `coze_doc_knowledge`（向量/关键词检索用），按需分别声明。
2. **`exclude` 往往是必需的**：若标准QA在 `standard_qa_match` 阶段就「全部命中」，工作流直接返回预制答案，
   **根本走不到检索与冲突校验节点**，注入再多冲突语料也没用。先用 `probe_stdqa.py` 查清是谁短路的。
3. **注入探针只 append 到 `coze_doc_knowledge`**，不碰 `standard_qa_kb`——否则标准QA会先命中注入文档，同样绕过冲突校验。
4. **默认关闭**：不传 `--fixtures` = 不启用，历史轮次数字继续可比。fixture 用 `threading.local()` 隔离，
   `run_case` 用 `try/finally` 清理；**改这一段时务必保住 try/finally**，否则异常时注入语料会泄漏到后续用例。

用法示例见 `语料注入能力与冲突维度解锁报告.md`；词表 doc_id 清单见 `out/console_kb_docids.txt`。

## 期望怎么写在「行为」上（v1.2 起）

用例的期望有**两种写法**，判定器都支持：

| 字段 | 语义 | 什么时候用 |
|---|---|---|
| `expected_keywords` | 每词都必须出现（AND） | 有确定事实要断言时（如「5天」「提前1周」） |
| `expected_any` | 每个组内**任一**命中即算该组满足，所有组都要满足（AND of OR） | **合规做法有多种合理措辞**时（如「存在差异 / 存在规则冲突 / 两版规定 / 规定不一致……」） |

四条经验（都是踩出来的）：

1. **别把某个节点的措辞写进期望**。`TC-C01/C02` 原来期望的是「过渡兜底」话术，而图把真冲突路由去**冲突兜底** —— 引擎答对了照样判失败。
2. **禁词要慎用**。逐字禁词无法区分「断言某一个版本」与「并列引述两版」，会把合规回答判过报（C02 就是这么被误杀的）。
3. **多要求用例对外只读 `strict`**。`half` 只要求满足 ≥50%，2 组要求下「满足一半」就会过。
4. **`expected_any` 的词表是措辞空间，不是标准答案**；漏一个词就误杀一条合规回答。它同时证明**关键词断言已到天花板** —— 同一语义已被观察到 5 种说法，durable 方案是轻量语义判定。

判定器一动就必须自检（三条断言，见 `engine/judge_selftest.py`）：

```bash
"$PY" engine/judge_selftest.py v12_fx2     # A 向后兼容 / B 行为级期望有效 / C Python-JS 双线一致
```

**当前基准（v1.2 + 注入，`out/summary_llm_v12_fx2.json`）**：

| 口径 | 值 |
|---|---|
| 全命中 strict | 26.3% |
| **50% half（对外报数）** | **54.2%** |
| 宽松 anyhit | 64.4% |
| 三层兜底合计 / 其中冲突兜底 | 12 / 1 |

```bash
# 复现当前基准（v1.2 + 语料注入）
"$PY" llm_eval/run_eval.py --tag v12_fx2 --cases data/testset_118.v1.2.jsonl \
      --fixtures data/corpus_fixtures.json --workers 5
```

⚠️ **跨版本对比必须写明用的哪一版测试集**（v1.1 / v1.2），否则数字不可比。
⚠️ 判定「某条为什么变了」用 `diff_runs_cases.py <tagA> <tagB> --field judge.strict`：
它能分清「改动生效」与「采样噪声」——上游 `split_questions` 同配置两次跑约 19% 用例会不同。

## 第二判官：轻量语义判定（行为型用例）

关键词断言有两个硬伤：**措辞空间追不完**、**表达不了否定式要求**
（「不得在未提示不确定性的情况下给出唯一确定结论」）。语义判定作为**并行第二口径**补这一块。

```bash
"$PY" llm_eval/semantic_judge.py --validate                    # 跑标注集，报一致率（默认判官 deepseek）
"$PY" llm_eval/semantic_judge.py --validate --judge-model qwen  # 换跨厂商判官（通义千问）
"$PY" llm_eval/semantic_judge.py --compare-models               # 跨厂商判官对比
"$PY" llm_eval/semantic_judge.py --validate --no-cache         # 强制重判（测稳定性）
"$PY" llm_eval/semantic_judge.py --validate --flip --no-cache  # 阴性对照：标注反转，一致率应崩到 ~0%
"$PY" llm_eval/semantic_judge.py --from-trace v12_fx2 [--judge-model qwen]
"$PY" llm_eval/semantic_judge.py --dump-answers v12_fx2 --ids TC-C01,TC-C02   # 导出真实答案

# 生成侧换厂商（默认 deepseek；用于跨模型鲁棒性 / 偏差实验）
XIAOBAN_LLM_BACKEND=qwen "$PY" llm_eval/run_eval.py --tag myqwen --only ... --cases ... --fixtures ...

# 判官自评偏差矩阵（同用例两模型作答 × 两判官交叉评）
"$PY" llm_eval/bias_matrix.py --pair v12_fx2 v12_fx_qwengen --pair fixture_conflict fc_qwengen --show-answers
```

四条使用规矩：

1. **不替换主判定**：语义判定不参与 strict/half/anyhit，历史数字继续可比；两者分歧的样本落盘 → 人工复核队列。
2. **范围必须显式限定**（`data/semantic_checks.json` 的 `_cases`）。判定项是**场景专用**的——
   实测把它用到非该场景用例上，一致率 **0/2**（`TC-S01` 本就该给确定答案）。它不是"更好的尺子"，是"另一把尺子"。
3. **判定项要带 `expect`（true/false）并强制引用原文证据**。`quote` 是复核的唯一抓手；
   例：「提到部门经理审批」→ `handoff` 证据为空（正确区分"流程描述"与"建议用户去问"）。
4. **任何"判官/标注"类结论必须配阴性对照**：把标注意义反转，若一致率不崩，说明测的是标注而不是被测对象。
   本项目结果：正向 45/45 = 100%、禁缓存重跑 100%、**阴性对照 0/45 = 0.0%**。

⚠️ **已知局限（未解）**：判官默认与被测系统同厂商 → 自评偏差风险。**已做 2×2 交叉实验量化**：
作者=DeepSeek 时两判官均 4/4；作者=千问时两判官均 3/4 → **偏差 +0.0pt（未观察到）**，
但只有 8 个组合 / 45 项标注，**不足以排除 <10pt 偏差**（详见 `跨厂商判官与自评偏差报告.md`）。
标注集是单方标注，不是人工双标。改指令措辞**必须**同步改 `semantic_judge.py` 的 `PROMPT_VERSION`，
否则缓存会返回旧结论。

**判官换厂商后顺带验证到一件事**：TC-C02 上「关键词判 half=True、语义判 FAIL」——
关键词口径只数"满足了几组要求"，`2 组里满足 1 组 = 50%` 就把「必须转人工」这条**按一半权重抹掉了**；
两个厂商的语义判官都指出该要求未满足。这就是第二判官的价值兑现点，也是分歧队列的第一条真实样本。

## 跨模型回归（换生成厂商）

唯一变量 = 生成模型；测试集、fixtures、判官、嵌入缓存全部不变。

```bash
XIAOBAN_LLM_BACKEND=qwen "$PY" llm_eval/run_eval.py --tag v12_fx_qwen \
      --cases data/testset_118.v1.2.jsonl --fixtures data/corpus_fixtures.json --workers 6
"$PY" llm_eval/diff_runs_cases.py v12_fx2 v12_fx_qwen --field judge.half   # 逐例对账
```

实测（`v12_fx2` DeepSeek ↔ `v12_fx_qwen` 千问）：

| | DeepSeek | 千问 | 判读 |
|---|---|---|---|
| 终端分支分布 | 106 / 11 / 1 | **106 / 11 / 1** | **逐格相同**（强结论） |
| 全命中 strict | 26.3% | **26.3%** | 逐位相同 |
| 宽松 anyhit | 64.4% | **64.4%** | 逐位相同 |
| 50% half | 54.2% | 51.7% | −2.5pt（弱结论，答案用词波动） |
| 失败/错误 | 0 | **0** | 13 个生产节点**不改一行**即可换厂商 |
| 耗时 | 70.8s | 371.9s | 5.3× |

**判读规则**：**离散量（分支分布 / 是否写入）→ 强结论；文本类指标（half / 欠报 / 兜底话术）→ 弱结论。**
7 条路由漂移**全部**发生在 `标准QA直答 ↔ 检索后正常作答` 之间（上游 `split_questions` 同配置两次跑约 19% 会变）
→ 属采样噪声，**不是模型能力差异**。详见 `跨模型回归报告.md`。


Windows 环境提示：Graph Bash 的 shim 在本机不稳定（`ls/grep/head/tail` 会报 command not found），
命令尽量**不要接管道**，输出重定向到文件再用 Read 看。

## 三档判定口径（重要）

| 口径 | 定义 | 用途 |
|---|---|---|
| `全命中` | 全部期望词命中 且 无禁止词 | 抓「答得不全」 |
| `50% 口径` | 期望词命中率 ≥ 50% 且 无禁止词（= 旧脚本 80 分线） | **对外报数用这档** |
| `宽松` | 命中 ≥ 1 个期望词 且 无禁止词 | 历史归档实际用的是这档 |

三档必须同时报。**只报一个数字 = 埋雷**：面试官按常规口径复算会对不上。

## 改动前必做

```bash
node engine/run_baseline.js --tag before_<改动名>     # 先存 baseline
# ...改东西...
node engine/run_baseline.js --tag after_<改动名>      # 再复测
```
然后往 `迭代回写记录表.md` 加一行：**触发 → 改了什么 → 改前/改后 → 驱动证据 → 是否回归复测**。
没有这一步，评测就还是存档。

## 阈值在哪配

`../小办源文件/xiaoban-workflow-src/config/eval_thresholds.json`（工作流源码树内，单一事实源）。
每个值都带 `_evidence` 字段说明数据依据；节点通过 `nodes/thresholds.py` 读取，
配置缺失 / 键缺失 / 文件损坏均回落到代码内默认值（= 改动前原值），不会影响主流程。

⚠️ **配置写坏是静默失效**（踩过：JSON 一个尾随逗号 → `json.load` 失败 → 全部回落默认值 → 那一轮评测跑了等于没改）。
所以改完配置**必须**跑 `llm_eval/check_thresholds.py` 断言「配置值 == 节点读到值」。

## 先量噪声，再谈效果（真实 LLM 评测的铁律）

用**同一份配置连跑两次**标定噪声上限：

| 项 | 实测极差 |
|---|---|
| 全命中 strict | ±0.8pt |
| 50% 口径 half | ±0.9pt |
| 宽松 anyhit | ±1.7pt |
| 答案文本不同的用例数 | **34 / 118 条** |

推论：**小于约 2pt 的差异、以及任何「答案文本变了」的观察，都不作为改动有效的证据。**
相反，**离散量（终端分支分布、字段是否写入）不受采样噪声影响，是最硬的证据**——
本轮的「检索后正常作答 37→28」「三层兜底 0→11」就是靠这个立住的。

## 第三轮实测：D1–D5 修复后（118 条全量，0 失败）

| 指标（口径） | 改前 | 改后 | 变化 | 是否超噪声 |
|---|---|---|---|---|
| 全命中 strict | 16.9% | 23.7% | **+6.8pt** | ✅ |
| **50% half（对外报数口径）** | 46.6% | 52.5% | **+5.9pt** | ✅ |
| 宽松 anyhit | 58.5% | 63.6% | +5.1pt | ✅ |
| 禁词命中（过报） | 10.2% | 8.5% | −1.7pt | 边缘 |
| 答案正文是 dict 字面量 | 80 条 | **0 条** | 清零 | 确定性 |
| 冲突校验误报 | 23 条 | **0 条** | 清零 | 确定性 |
| 全局兜底触发 | 0 条 | **11 条** | 首次可达 | 确定性（路由） |

详细归因、逐个缺陷的证据链、以及「哪些改动其实 0 效果」的诚实说明，见 **`缺陷修复验证报告.md`**。
