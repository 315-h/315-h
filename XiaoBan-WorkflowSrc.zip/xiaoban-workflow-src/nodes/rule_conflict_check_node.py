"""
制度冲突校验节点：校验报销额度、休假天数、设备年限、审批人等量化规则是否存在矛盾
区分【条件分段规则】和【真实规则冲突】：
- 带前置条件（工龄、区间、职级）的多组不同数值不算冲突
- 只有同一条件下出现多个不一样的数值，才判定为制度冲突
- 年假天数等分段阶梯规则，禁止单纯凭借数值不同判定冲突
"""
import logging
import re
from typing import List, Dict, Any, Set, Tuple, Optional
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from graphs.state import RuleConflictCheckInput, RuleConflictCheckOutput

logger = logging.getLogger(__name__)

# 分段阶梯规则类型（不同条件下的不同数值不算冲突）
TIERED_RULE_TYPES = {'leave_days', 'reimbursement_tier'}

# 前置条件关键词（用于识别分段规则）
PRECONDITION_KEYWORDS = {
    'seniority': ['工作', '工龄', '入职', '满', '年', '年限', '连续'],
    'range': ['超过', '以上', '以下', '以内', '区间', '范围', '至', '到'],
    'level': ['职级', '级别', '等级', 'P', 'M', '级', '档'],
    'amount_tier': ['超过', '大于', '小于', '以上', '以下', '满']
}

# 量化规则类型及其关键词
RULE_TYPES = {
    'reimbursement_amount': {
        'keywords': ['报销', '额度', '上限', '元', '费用', '限额'],
        'patterns': [
            r'(\d+(?:\.\d+)?)\s*(?:元|万元)',
            r'(?:上限|额度|限额)\s*(?:为|是|不超过)?\s*(\d+(?:\.\d+)?)\s*(?:元|万元)?'
        ]
    },
    'leave_days': {
        'keywords': ['年假', '病假', '事假', '婚假', '产假', '天', '日', '休假'],
        'patterns': [
            r'(\d+)\s*(?:天|日)',
            r'(?:享有|享受|可以|为)\s*(\d+)\s*(?:天|日)'
        ]
    },
    'equipment_years': {
        'keywords': ['设备', '显示器', '键盘', '鼠标', '座椅', '年', '更换', '维修', '周期'],
        'patterns': [
            r'(\d+)\s*年',
            r'(?:周期|年限|使用)\s*(?:为|是)?\s*(\d+)\s*年'
        ]
    },
    'approval_level': {
        'keywords': ['审批', '审核', '总经理', '部门经理', '总监', '主管', '批准'],
        'patterns': [
            r'(?:需要|由|经|需)\s*(\S{2,10})\s*(?:审批|审核|批准)'
        ]
    }
}


def _extract_precondition(context: str) -> Optional[str]:
    """
    从上下文中提取前置条件（工龄区间、金额区间、职级等）
    返回条件标识字符串，无前置条件返回None
    """
    preconditions = []
    
    # 提取工龄/年限条件
    seniority_patterns = [
        r'(?:工作|连续工作|工龄)\s*(\d+)\s*[-~至到]\s*(\d+)\s*年',
        r'(?:工作|连续工作|工龄)\s*(?:满|超过|以上)\s*(\d+)\s*年',
        r'(\d+)\s*[-~至到]\s*(\d+)\s*年\s*(?:工作|工龄)',
    ]
    for pattern in seniority_patterns:
        match = re.search(pattern, context)
        if match:
            preconditions.append(f"seniority:{match.group(0)}")
            break
    
    # 提取金额区间条件
    amount_patterns = [
        r'(?:超过|大于|高于)\s*(\d+(?:\.\d+)?)\s*(?:元|万)',
        r'(?:总额|总金额|金额)\s*(?:超过|大于)\s*(\d+(?:\.\d+)?)',
        r'(\d+(?:\.\d+)?)\s*(?:元|万)\s*(?:以上|以下|以内)',
    ]
    for pattern in amount_patterns:
        match = re.search(pattern, context)
        if match:
            preconditions.append(f"amount:{match.group(0)}")
            break
    
    # 提取职级条件
    level_patterns = [
        r'[PpMm]\d+',
        r'(?:职级|级别|等级)\s*(?:为|是)?\s*(\S+)',
    ]
    for pattern in level_patterns:
        match = re.search(pattern, context)
        if match:
            preconditions.append(f"level:{match.group(0)}")
            break
    
    # 提取人数条件
    people_patterns = [
        r'(?:单人|每人|人均)\s*(?:上限|标准)?\s*(\d+(?:\.\d+)?)\s*(?:元|万)',
        r'(\d+)\s*(?:人|位)\s*(?:以上|以下)',
    ]
    for pattern in people_patterns:
        match = re.search(pattern, context)
        if match:
            preconditions.append(f"people:{match.group(0)}")
            break
    
    return "|".join(preconditions) if preconditions else None


def _extract_quantitative_rules(content: str, source: str = "") -> Dict[str, List[Dict[str, Any]]]:
    """
    从内容中提取量化规则
    返回 {规则类型: [{value, context, precondition, source}]}
    """
    rules: Dict[str, List[Dict[str, Any]]] = {}
    
    for rule_type, config in RULE_TYPES.items():
        # 检查是否包含相关关键词
        has_keywords = any(kw in content for kw in config['keywords'])
        if not has_keywords:
            continue
        
        # 提取数值规则
        for pattern in config['patterns']:
            matches = re.finditer(pattern, content)
            for match in matches:
                value = match.group(1) if match.groups() else match.group(0)
                # 获取上下文（前后30个字符，扩大范围以捕获前置条件）
                start = max(0, match.start() - 40)
                end = min(len(content), match.end() + 40)
                context = content[start:end]
                
                # 提取前置条件
                precondition = _extract_precondition(context)
                
                if rule_type not in rules:
                    rules[rule_type] = []
                rules[rule_type].append({
                    'value': value,
                    'context': context,
                    'precondition': precondition,
                    'source': source
                })
    
    return rules


def _is_tiered_rule(rule_type: str, rules_list: List[Dict[str, Any]]) -> bool:
    """
    判断是否为分段阶梯规则
    1. 规则类型本身是分段类型（如leave_days）
    2. 或者多条规则都有不同的前置条件
    """
    if rule_type in TIERED_RULE_TYPES:
        return True
    
    # 检查是否所有规则都有不同的前置条件
    preconditions = [r.get('precondition') for r in rules_list if r.get('precondition')]
    if len(preconditions) >= 2:
        unique_preconditions = set(preconditions)
        # 如果大部分规则都有不同的前置条件，视为分段规则
        if len(unique_preconditions) >= len(rules_list) * 0.6:
            return True
    
    return False


def _detect_real_conflicts(
    rules_from_chunks: List[Tuple[Dict[str, List[Dict[str, Any]]], str]]
) -> Tuple[bool, List[str], str]:
    """
    检测真实的规则冲突
    区分条件分段规则和真实冲突：
    - 带前置条件的不同数值不算冲突
    - 分段阶梯规则（如年假天数）不算冲突
    - 只有同一条件下出现多个不同数值才算冲突
    """
    if len(rules_from_chunks) < 2:
        return False, [], ""
    
    conflict_details: List[str] = []
    conflict_sources: Set[str] = set()
    
    # 合并所有规则，按规则类型分组
    all_rules: Dict[str, List[Dict[str, Any]]] = {}
    
    for rules, source in rules_from_chunks:
        for rule_type, rule_list in rules.items():
            if rule_type not in all_rules:
                all_rules[rule_type] = []
            for rule in rule_list:
                rule_with_source = {**rule, 'source': source}
                all_rules[rule_type].append(rule_with_source)
    
    # 检查每种规则类型是否存在真实冲突
    for rule_type, rule_list in all_rules.items():
        if len(rule_list) < 2:
            continue
        
        # 分段阶梯规则不判定冲突
        if _is_tiered_rule(rule_type, rule_list):
            logger.info(f"规则类型 {rule_type} 为分段阶梯规则，跳过冲突检测")
            continue
        
        # 按前置条件分组
        rules_by_precondition: Dict[Optional[str], List[Dict[str, Any]]] = {}
        for rule in rule_list:
            precondition = rule.get('precondition')
            if precondition not in rules_by_precondition:
                rules_by_precondition[precondition] = []
            rules_by_precondition[precondition].append(rule)
        
        # 在每个前置条件组内检查冲突
        for precondition, group_rules in rules_by_precondition.items():
            if len(group_rules) < 2:
                continue
            
            # 提取数值
            numeric_values = []
            for rule in group_rules:
                try:
                    num_value = float(rule['value'])
                    numeric_values.append((num_value, rule))
                except (ValueError, TypeError):
                    # 非数值（如审批人名称），检查是否完全一致
                    pass
            
            # 检查数值冲突
            if len(numeric_values) >= 2:
                unique_values = set(v[0] for v in numeric_values)
                if len(unique_values) > 1:
                    # 同一前置条件下存在多个不同数值 = 真实冲突
                    sources_in_conflict = set(r['source'] for _, r in numeric_values if r.get('source'))
                    conflict_sources.update(sources_in_conflict)
                    
                    values_str = ", ".join([f"{v}({r.get('source', 'unknown')})" for v, r in numeric_values])
                    condition_str = f"条件[{precondition}]" if precondition else "无前置条件"
                    conflict_details.append(
                        f"{rule_type}在{condition_str}下存在冲突数值: {values_str}"
                    )
            
            # 检查非数值冲突（如审批人）
            non_numeric_values = []
            for rule in group_rules:
                try:
                    float(rule['value'])
                except (ValueError, TypeError):
                    non_numeric_values.append(rule)
            
            if len(non_numeric_values) >= 2:
                unique_non_numeric = set(r['value'] for r in non_numeric_values)
                if len(unique_non_numeric) > 1:
                    sources_in_conflict = set(r.get('source', '') for r in non_numeric_values if r.get('source'))
                    conflict_sources.update(sources_in_conflict)
                    values_str = ", ".join([f"{r['value']}({r.get('source', 'unknown')})" for r in non_numeric_values])
                    condition_str = f"条件[{precondition}]" if precondition else "无前置条件"
                    conflict_details.append(
                        f"{rule_type}在{condition_str}下存在冲突: {values_str}"
                    )
    
    has_conflict = len(conflict_details) > 0
    return has_conflict, list(conflict_sources), "; ".join(conflict_details)


def _extract_source_from_chunk(chunk: str) -> str:
    """从片段中提取来源信息"""
    # 匹配【来源：xxx】或【source: xxx】格式
    source_match = re.search(r'【(?:来源|source)[：:]\s*([^】]+)】', chunk)
    if source_match:
        return source_match.group(1).strip()
    
    # 匹配"来源：xxx"格式
    source_match = re.search(r'(?:来源|source)[：:]\s*([^\n，,]+)', chunk)
    if source_match:
        return source_match.group(1).strip()
    
    return ""


def rule_conflict_check_node(
    state: RuleConflictCheckInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> RuleConflictCheckOutput:
    """
    title: 制度冲突校验
    desc: 校验报销额度、休假天数、设备年限、审批人等量化规则是否存在矛盾。区分条件分段规则和真实冲突：带前置条件的多组不同数值不算冲突，年假等分段阶梯规则不判定冲突，只有同一条件下出现多个不同数值才判定为制度冲突。若已命中标准QA，优先采信标准答案，跳过冲突校验。
    """
    knowledge_retrieval: str = state.knowledge_retrieval if state.knowledge_retrieval else ""
    has_valid_content: bool = state.has_valid_content
    standard_hit: bool = state.standard_hit
    
    # 优先级规则：若已命中标准QA，优先采信标准答案，跳过冲突校验
    if standard_hit:
        logger.info("冲突校验：已命中标准QA，优先采信标准答案，跳过冲突校验")
        return RuleConflictCheckOutput(
            rule_conflict_detected=False,
            rule_conflict_sources=[],
            rule_conflict_details=""
        )
    
    if not knowledge_retrieval or not has_valid_content:
        logger.info("冲突校验：无有效内容，跳过校验")
        return RuleConflictCheckOutput(
            rule_conflict_detected=False,
            rule_conflict_sources=[],
            rule_conflict_details=""
        )
    
    # 按片段分割内容
    chunks = knowledge_retrieval.split("\n\n")
    rules_from_chunks: List[Tuple[Dict[str, List[Dict[str, Any]]], str]] = []
    
    for chunk in chunks:
        # 提取来源
        source = _extract_source_from_chunk(chunk)
        
        # 提取纯内容（去除前缀标记）
        content = re.sub(r'^【.*?】.*?\n', '', chunk).strip()
        if content:
            rules = _extract_quantitative_rules(content, source)
            if rules:
                rules_from_chunks.append((rules, source))
    
    # 检测真实冲突
    has_conflict, conflict_sources, conflict_details = _detect_real_conflicts(rules_from_chunks)
    
    if has_conflict:
        logger.warning(f"检测到真实规则冲突: {conflict_details}, 来源: {conflict_sources}")
    else:
        logger.info("冲突校验：未检测到真实规则冲突（分段阶梯规则和条件分段规则已排除）")
    
    return RuleConflictCheckOutput(
        rule_conflict_detected=has_conflict,
        rule_conflict_sources=conflict_sources,
        rule_conflict_details=conflict_details
    )
