"""
条件判断节点：三级路由逻辑
- score >= 0.6 或 核心业务分类 → normal
- 0.2 <= score < 0.6 → mid_fallback
- score < 0.2 → fallback
"""
import logging
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from graphs.state import ConditionCheckInput, ConditionCheckOutput

logger = logging.getLogger(__name__)


def condition_check_node(
    state: ConditionCheckInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> ConditionCheckOutput:
    """
    title: 条件判断
    desc: 三级路由判断——业务分类优先；检索文本含业务正文则强制正常回答，避免"有答案却兜底"；其余按检索得分分三档路由
    """
    ctx = runtime.context

    biz_type: str = state.biz_type if state.biz_type else "其他"
    top_score: float = float(state.top_score) if state.top_score else 0.0
    knowledge_text: str = state.knowledge_retrieval if state.knowledge_retrieval else ""

    # 辅助：检索文本是否包含业务制度正文（>=2 个业务关键词视为含正文）
    def _has_business_content(text: str, biz: str) -> bool:
        keyword_map = {
            "假期": ["假期", "年假", "病假", "事假", "婚假", "产假", "陪产假", "丧假", "调休", "请假", "休假", "工作日"],
            "报销": ["报销", "发票", "补贴", "出差", "宴请", "培训", "加班", "费用", "报账", "审批"],
            "办公用品": ["办公用品", "鼠标", "键盘", "显示器", "纸张", "文具", "申领", "设备", "耗材", "采购", "维修"],
        }
        kws = keyword_map.get(biz) or []
        if not text or not kws:
            return False
        return sum(1 for k in kws if k in text) >= 2

    # 1) 核心业务分类强制走正常回答（优先级最高）
    if biz_type in ["假期", "报销", "办公用品"]:
        return ConditionCheckOutput(route_branch="normal")

    # 2) 检索文本含业务正文 → 强制正常回答，避免"有答案却兜底"
    if knowledge_text.strip() and _has_business_content(knowledge_text, biz_type):
        return ConditionCheckOutput(route_branch="normal")

    # 3) 非核心业务：按检索得分三级路由
    if top_score >= 0.6 and knowledge_text.strip():
        return ConditionCheckOutput(route_branch="normal")
    elif top_score >= 0.2:
        return ConditionCheckOutput(route_branch="mid_fallback")
    else:
        return ConditionCheckOutput(route_branch="fallback")
