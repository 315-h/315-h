"""
高频标准问答匹配节点：子问题独立匹配，不截断流程
1. 每条子问题独立匹配标准QA知识库（standard_qa_kb）
2. 使用向量检索（D方案），直接从 chunk content 解析结构化答案
3. 命中子问题缓存预制答案，未命中子问题继续走检索流程
"""
import os
import logging
from typing import List, Any, Dict, Optional
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from coze_coding_dev_sdk import KnowledgeClient, Config
from graphs.state import StandardQaMatchInput, StandardQaMatchOutput, SubQuestionStandardHit

logger = logging.getLogger(__name__)

# ===== 标准问答知识库配置（向量检索）=====
STANDARD_QA_KB = "standard_qa_kb"
STANDARD_QA_SIM_THRESHOLD = 0.70
STANDARD_QA_TOP_K = 1


def _parse_qa_content(content: str) -> Dict[str, str]:
    """
    解析 standard_qa_kb 中的文档内容，提取结构化答案。
    格式：
    Line 1: 原问题
    Line 2: 同义问法：...
    Line 3: 答案：...
    Line 4: 路径：...
    Line 5: 步骤：...
    Line 6: 来源：...
    """
    if not content:
        return {}
    
    lines = content.strip().split('\n')
    result = {
        'question': '',
        'answer': '',
        'path': '',
        'steps': '',
        'source': ''
    }
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
        # Line 1: question (no prefix)
        if not any(line.startswith(p) for p in ['同义问法', '答案', '路径', '步骤', '来源', '飞书路径', '填写步骤']):
            if not result['question']:
                result['question'] = line
            continue
        # Parse prefixed lines
        if line.startswith('答案：') or line.startswith('答案:'):
            result['answer'] = line.split('：', 1)[-1].split(':', 1)[-1].strip()
        elif line.startswith('路径：') or line.startswith('路径:') or line.startswith('飞书路径：') or line.startswith('飞书路径:'):
            for prefix in ['路径：', '路径:', '飞书路径：', '飞书路径:']:
                if line.startswith(prefix):
                    result['path'] = line[len(prefix):].strip()
                    break
        elif line.startswith('步骤：') or line.startswith('步骤:') or line.startswith('填写步骤：') or line.startswith('填写步骤:'):
            for prefix in ['步骤：', '步骤:', '填写步骤：', '填写步骤:']:
                if line.startswith(prefix):
                    result['steps'] = line[len(prefix):].strip()
                    break
        elif line.startswith('来源：') or line.startswith('来源:'):
            for prefix in ['来源：', '来源:']:
                if line.startswith(prefix):
                    result['source'] = line[len(prefix):].strip()
                    break
    
    return result


def _match_single_question(
    question: str,
    client: "KnowledgeClient"
) -> Optional[Dict[str, Any]]:
    """
    单条问题匹配标准QA知识库。
    使用向量检索，直接从 chunk content 解析结构化答案。
    """
    if not question or not client:
        return None
    try:
        response = client.search(
            query=question.strip(),
            table_names=[STANDARD_QA_KB],
            top_k=STANDARD_QA_TOP_K,
            min_score=STANDARD_QA_SIM_THRESHOLD
        )
        if response.code != 0 or not response.chunks:
            return None
        chunk = response.chunks[0]
        content = str(chunk.content) if chunk.content else ""
        score = float(chunk.score) if chunk.score else 0.0
        if score < STANDARD_QA_SIM_THRESHOLD:
            return None
        
        # 直接从 chunk content 解析结构化答案
        qa_data = _parse_qa_content(content)
        
        # 跳过空答案条目
        if not qa_data.get('answer', '').strip():
            return None
        
        return {
            "question": qa_data.get("question", ""),
            "answer": qa_data.get("answer", ""),
            "path": qa_data.get("path", ""),
            "steps": qa_data.get("steps", ""),
            "source": qa_data.get("source", ""),
            "score": score
        }
    except Exception as e:
        logger.error(f"标准问答向量检索失败: {e}")
        return None


def standard_qa_match_node(
    state: StandardQaMatchInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> StandardQaMatchOutput:
    """
    title: 高频标准问答匹配
    desc: 子问题独立匹配标准QA知识库（standard_qa_kb），命中缓存预制答案，未命中继续走检索流程，不截断整体工作流
    integrations: 知识库
    """
    ctx = runtime.context

    query_rewrite: str = state.query_rewrite if state.query_rewrite else ""
    split_questions: List[str] = state.split_questions if state.split_questions else []

    if not query_rewrite and not split_questions:
        logger.warning("无有效输入")
        return StandardQaMatchOutput(
            standard_hit=False,
            standard_match_type="none",
            standard_answer={},
            sub_question_standard_hits=[],
            all_sub_questions_hit=False
        )

    # 初始化标准问答知识库客户端
    qa_client: Optional["KnowledgeClient"] = None
    try:
        sdk_config = Config()
        qa_client = KnowledgeClient(config=sdk_config, ctx=ctx)
        logger.info("标准问答知识库客户端初始化成功")
    except Exception as e:
        logger.error(f"初始化标准问答知识库客户端失败: {e}")
        return StandardQaMatchOutput(
            standard_hit=False,
            standard_match_type="none",
            standard_answer={},
            sub_question_standard_hits=[],
            all_sub_questions_hit=False
        )

    # 子问题级别匹配结果
    sub_question_hits: List[SubQuestionStandardHit] = []
    any_hit = False
    match_type = "none"

    # 对每条子问题独立匹配
    if split_questions:
        logger.info(f"开始子问题逐条独立匹配({len(split_questions)}条)...")
        for idx, sub_q in enumerate(split_questions):
            if not isinstance(sub_q, str) or not sub_q.strip():
                sub_question_hits.append(SubQuestionStandardHit(
                    sub_question=sub_q if isinstance(sub_q, str) else "",
                    hit=False
                ))
                continue

            sub_match = _match_single_question(sub_q.strip(), qa_client)
            if sub_match:
                logger.info(f"子问题{idx+1}匹配命中: {sub_q[:30]}... (score={sub_match['score']:.2f})")
                sub_question_hits.append(SubQuestionStandardHit(
                    sub_question=sub_q,
                    hit=True,
                    answer_text=sub_match.get("answer", ""),
                    source=sub_match.get("source", ""),
                    path=sub_match.get("path", ""),
                    steps=sub_match.get("steps", "")
                ))
                any_hit = True
                if match_type == "none":
                    match_type = "sub_question_match"
            else:
                logger.info(f"子问题{idx+1}未命中: {sub_q[:30]}...")
                sub_question_hits.append(SubQuestionStandardHit(
                    sub_question=sub_q,
                    hit=False
                ))

    # 判断是否所有子问题都命中
    all_hit = len(sub_question_hits) > 0 and all(h.hit for h in sub_question_hits)

    # 构建标准答案（仅当所有子问题都命中时使用）
    standard_answer = {}
    if all_hit:
        answer_parts = []
        sources = []
        for hit in sub_question_hits:
            if hit.hit and hit.answer_text:
                answer_parts.append(hit.answer_text)
            if hit.source and hit.source not in sources:
                sources.append(hit.source)

        standard_answer = {
            "answer_text": "\n\n".join(answer_parts),
            "source": "；".join(sources) if sources else "",
            "handoff_label": "",
            "handoff_url": ""
        }
        match_type = "all_sub_questions_hit"
        logger.info(f"所有子问题都命中标准QA，共{len(sub_question_hits)}条")

    return StandardQaMatchOutput(
        standard_hit=any_hit,
        standard_match_type=match_type,
        standard_answer=standard_answer,
        sub_question_standard_hits=sub_question_hits,
        all_sub_questions_hit=all_hit
    )
