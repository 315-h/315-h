"""
问题拆分 & 业务分类节点：合并拆分与分类为一次LLM调用
每条子问题独立打分类标签，支持后续按分类独立检索
"""
import os
import json
import logging
import re
from typing import Any, Dict, List
from jinja2 import Template
from langchain_core.runnables import RunnableConfig
from langchain_core.messages import SystemMessage, HumanMessage
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context, new_context
from coze_coding_dev_sdk import LLMClient
from graphs.state import SplitAndClassifyInput, SplitAndClassifyOutput

logger = logging.getLogger(__name__)


def _extract_text_content(content: Any) -> str:
    """安全提取LLM响应中的文本内容"""
    if isinstance(content, str):
        return content
    elif isinstance(content, list):
        if content and isinstance(content[0], str):
            return " ".join(content)
        else:
            text_parts = [
                item.get("text", "")
                for item in content
                if isinstance(item, dict) and item.get("type") == "text"
            ]
            return " ".join(text_parts)
    return str(content)


def split_and_classify_node(
    state: SplitAndClassifyInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> SplitAndClassifyOutput:
    """
    title: 问题拆分 & 业务分类
    desc: 一次LLM调用同时完成问题拆分和业务分类，每条子问题独立打分类标签（办公用品/假期/报销），支持后续按分类独立检索
    integrations: 大语言模型
    """
    ctx = runtime.context

    # 从config的metadata读取LLM配置文件路径
    cfg_file: str = os.path.join(
        os.getenv("COZE_WORKSPACE_PATH", ""),
        config["metadata"]["llm_cfg"]
    )
    with open(cfg_file, "r", encoding="utf-8") as f:
        _cfg: Dict[str, Any] = json.load(f)

    llm_config: Dict[str, Any] = _cfg.get("config", {})
    sp: str = _cfg.get("sp", "")
    up: str = _cfg.get("up", "")

    # 使用jinja2渲染用户提示词模板
    up_tpl = Template(up)
    rendered_up: str = up_tpl.render(user_rewrite_query=state.query_rewrite)

    # 初始化LLM客户端
    llm_client = LLMClient(ctx=ctx)

    # 构建消息
    messages = [
        SystemMessage(content=sp),
        HumanMessage(content=rendered_up)
    ]

    # 调用大模型
    response = llm_client.invoke(
        messages=messages,
        model=llm_config.get("model", "doubao-seed-2-0-pro-260215"),
        temperature=llm_config.get("temperature", 0.0),
        top_p=llm_config.get("top_p", 0.7),
        max_completion_tokens=llm_config.get("max_completion_tokens", 1500),
        thinking=llm_config.get("thinking", "disabled")
    )

    # 安全提取响应内容
    content_text: str = _extract_text_content(response.content)
    logger.info(f"split_and_classify LLM响应: {content_text[:200]}...")

    # 解析响应：期望JSON数组格式
    # [{"sub_question": "...", "category": "办公用品/假期/报销"}, ...]
    split_questions: List[str] = []
    biz_types: List[str] = []
    biz_type: str = "其他"

    try:
        # 尝试提取JSON数组
        json_match = re.search(r'\[[\s\S]*\]', content_text)
        if json_match:
            parsed_list = json.loads(json_match.group())
            if isinstance(parsed_list, list) and len(parsed_list) > 0:
                # 解析每个子问题及其分类
                category_count: Dict[str, int] = {}
                for item in parsed_list:
                    if isinstance(item, dict):
                        sub_q = item.get("sub_question", "")
                        category = item.get("category", "其他")
                        if sub_q:
                            split_questions.append(sub_q)
                            # 确保category是有效值
                            if category not in ["办公用品", "假期", "报销"]:
                                category = "其他"
                            biz_types.append(category)
                            # 统计分类频率
                            category_count[category] = category_count.get(category, 0) + 1
                
                # 确定主分类（出现频率最高的）
                if category_count:
                    biz_type = max(category_count.keys(), key=lambda k: category_count[k])
                
                logger.info(f"解析成功: {len(split_questions)}个子问题, 主分类={biz_type}")
        
        # 如果解析失败，使用默认值
        if not split_questions:
            split_questions = [state.query_rewrite]
            biz_types = ["其他"]
            biz_type = "其他"
            logger.warning("LLM响应解析失败，使用默认值")

    except Exception as e:
        logger.error(f"解析LLM响应失败: {e}, 原始内容: {content_text[:200]}")
        split_questions = [state.query_rewrite]
        biz_types = ["其他"]
        biz_type = "其他"

    return SplitAndClassifyOutput(
        split_questions=split_questions,
        biz_type=biz_type,
        biz_types=biz_types
    )
