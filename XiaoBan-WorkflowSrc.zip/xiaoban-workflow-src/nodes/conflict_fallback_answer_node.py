"""
制度冲突专属兜底回答节点
当检测到真实制度冲突时，输出专属兜底话术
"""
import logging
from typing import List
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from graphs.state import ConflictFallbackAnswerInput, ConflictFallbackAnswerOutput

logger = logging.getLogger(__name__)


def conflict_fallback_answer_node(
    state: ConflictFallbackAnswerInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> ConflictFallbackAnswerOutput:
    """
    title: 制度冲突专属兜底回答
    desc: 当检测到真实制度冲突时，输出专属兜底话术，提示用户咨询HR确认最新规则
    """
    ctx = runtime.context

    user_input: str = state.user_input if state.user_input else ""
    conflict_sources: List[str] = state.rule_conflict_sources if state.rule_conflict_sources else []
    conflict_details: str = state.rule_conflict_details if state.rule_conflict_details else ""

    # 构建来源信息
    source_text = ""
    if conflict_sources:
        source_text = "、".join(conflict_sources)
    else:
        source_text = "相关制度文档"

    # 制度冲突专属兜底话术
    answer_text = (
        f"关于「{user_input}」的问题，检测到多条制度条款存在规则冲突，"
        f"为避免误导，建议您咨询 HR 确认最新规则。\n\n"
        f"本条规则来源：{source_text}"
    )

    if conflict_details:
        answer_text += f"\n\n冲突详情：{conflict_details}"

    logger.info(f"制度冲突专属兜底回答生成，来源: {source_text}")

    return ConflictFallbackAnswerOutput(
        conflict_fallback_answer=answer_text
    )
