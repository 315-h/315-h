"""
正常回答节点：基于知识库检索结果生成正式回答
支持标准问答直答 + 前置校验逻辑，强制携带source来源字段
所有回答末尾统一拼接规则来源与办事入口路径
"""
import os
import json
import logging
import re
from typing import Any, Dict, List
from jinja2 import Template
from langchain_core.runnables import RunnableConfig
from langchain_core.messages import SystemMessage, HumanMessage
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context, new_context
from coze_coding_dev_sdk import LLMClient
from graphs.state import NormalAnswerInput, NormalAnswerOutput

logger = logging.getLogger(__name__)

# 业务制度关键词（用于前置校验）
BUSINESS_KEYWORDS = {
    "假期": ["假期", "年假", "病假", "事假", "婚假", "产假", "陪产假", "丧假", "调休", "请假", "休假", "工作日"],
    "报销": ["报销", "发票", "补贴", "出差", "宴请", "培训", "加班", "费用", "报账", "审批"],
    "办公用品": ["办公用品", "鼠标", "键盘", "显示器", "纸张", "文具", "申领", "设备", "耗材", "采购", "维修"]
}

# 业务类型到飞书办理路径的映射
FEISHU_PATH_MAP = {
    "假期": "飞书-请假管理-对应假期申请单",
    "报销": "飞书首页 > 费用报销 > 新建报销",
    "办公用品": "飞书首页 > 办公用品 > 新建申领",
    "其他": ""
}


def _extract_text_content(content: Any) -> str:
    """安全提取LLM响应中的文本内容"""
    if isinstance(content, str):
        return content
    elif isinstance(content, list):
        if content and isinstance(content[0], str):
            return " ".join(content)
        else:
            text_parts = [
                item.get("text", "")
                for item in content
                if isinstance(item, dict) and item.get("type") == "text"
            ]
            return " ".join(text_parts)
    return str(content)


def _check_retrieval_contains_business_content(retrieval_text: str, biz_type: str) -> bool:
    """
    前置校验：检查检索结果是否包含对应业务制度的正文内容
    如果包含，则强制禁止输出兜底话术
    """
    if not retrieval_text or not biz_type or biz_type == "其他":
        return False
    
    # 获取该业务类型的关键词
    keywords = BUSINESS_KEYWORDS.get(biz_type, [])
    if not keywords:
        return False
    
    # 检查检索结果中是否包含业务关键词
    match_count = 0
    for keyword in keywords:
        if keyword in retrieval_text:
            match_count += 1
    
    # 如果匹配到2个以上关键词，认为包含业务制度正文
    return match_count >= 2


def _extract_source_from_retrieval(retrieval_text: str) -> str:
    """从检索结果中提取来源信息"""
    if not retrieval_text:
        return ""
    
    # 尝试提取文件名
    source_match = re.search(r'[\u4e00-\u9fa5\w\-]+\.txt', retrieval_text)
    if source_match:
        return source_match.group(0)
    
    # 尝试提取"来源："后的内容
    source_match = re.search(r'来源[：:]\s*([^\n]+)', retrieval_text)
    if source_match:
        return source_match.group(1).strip()
    
    return ""


def _append_source_and_path(answer_text: str, source: str, feishu_path: str) -> str:
    """在回答末尾统一拼接规则来源与办事入口路径"""
    suffix_parts: List[str] = []
    
    # 拼接来源信息
    if source:
        suffix_parts.append(f"\n\n【规则来源：{source}】")
    
    # 拼接办事路径
    if feishu_path:
        suffix_parts.append(f"【办事入口：{feishu_path}】")
    
    if suffix_parts:
        return answer_text + "".join(suffix_parts)
    return answer_text


def normal_answer_node(
    state: NormalAnswerInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> NormalAnswerOutput:
    """
    title: 正常回答
    desc: 基于知识库检索结果生成正式回答，支持标准问答直答；前置校验确保有制度内容时禁止输出兜底话术；末尾统一拼接规则来源与办事入口
    integrations: 大语言模型
    """
    ctx = runtime.context

    # 获取来源和路径信息
    doc_source: str = state.doc_source if state.doc_source else ""
    feishu_path: str = state.feishu_path if state.feishu_path else ""

    # 标准问答命中时，直接返回预制答案（不调用LLM）
    if state.standard_hit and state.standard_answer:
        logger.info("标准问答命中，直接返回预制答案")
        # 在标准答案末尾拼接来源和路径
        answer_text = state.standard_answer
        if doc_source or feishu_path:
            answer_text = _append_source_and_path(answer_text, doc_source, feishu_path)
        return NormalAnswerOutput(normal_answer={
            "answer_text": answer_text,
            "source": doc_source,
            "handoff_label": "",
            "handoff_url": ""
        })

    # 从config的metadata读取LLM配置文件路径
    cfg_file: str = os.path.join(
        os.getenv("COZE_WORKSPACE_PATH", ""),
        config["metadata"]["llm_cfg"]
    )
    with open(cfg_file, "r", encoding="utf-8") as f:
        _cfg: Dict[str, Any] = json.load(f)

    llm_config: Dict[str, Any] = _cfg.get("config", {})
    sp: str = _cfg.get("sp", "")
    up: str = _cfg.get("up", "")

    # 前置校验：检查检索结果是否包含业务制度正文
    has_business_content = _check_retrieval_contains_business_content(
        state.knowledge_retrieval, 
        state.biz_type
    )
    
    # 如果检索结果包含业务内容，在UP后追加强制规则
    force_rule = ""
    if has_business_content:
        force_rule = """

【强制规则 - 前置校验触发】
检测到检索结果中包含业务制度正文内容，你必须：
1. 强制遍历全部检索片段提取规则，禁止忽略任何片段
2. 禁止输出"未明确规定"、"建议联系HR"等兜底话术
3. 即使部分子问题无对应内容，也必须从其他片段中提取相关信息
4. 必须携带source来源字段，从检索结果中提取文件名
"""
        logger.info(f"前置校验触发：检索结果包含{state.biz_type}业务内容，强制提取规则")

    # 使用jinja2渲染用户提示词模板
    up_tpl = Template(up)
    rendered_up: str = up_tpl.render(
        user_input=state.user_input,
        knowledge_retrieval=state.knowledge_retrieval,
        biz_type=state.biz_type
    )
    
    # 追加强制规则
    if force_rule:
        rendered_up += force_rule

    # 初始化LLM客户端
    llm_client = LLMClient(ctx=ctx)

    # 构建消息
    messages = [
        SystemMessage(content=sp),
        HumanMessage(content=rendered_up)
    ]

    # 调用大模型
    response = llm_client.invoke(
        messages=messages,
        model=llm_config.get("model", "doubao-seed-2-0-pro-260215"),
        temperature=llm_config.get("temperature", 0.0),
        top_p=llm_config.get("top_p", 0.7),
        max_completion_tokens=llm_config.get("max_completion_tokens", 1500),
        thinking=llm_config.get("thinking", "disabled")
    )

    # 安全提取响应内容
    content_text: str = _extract_text_content(response.content)

    # 解析JSON响应
    result: Dict[str, str] = {}
    try:
        json_match = re.search(r'\{[\s\S]*\}', content_text)
        if json_match:
            parsed = json.loads(json_match.group())
            if isinstance(parsed, dict):
                result = {
                    "answer_text": str(parsed.get("answer_text", content_text)),
                    "source": str(parsed.get("source", "")),
                    "handoff_label": str(parsed.get("handoff_label", "")),
                    "handoff_url": str(parsed.get("handoff_url", ""))
                }
            else:
                raise ValueError("Parsed result is not a dict")
    except (json.JSONDecodeError, ValueError) as e:
        logger.warning(f"LLM响应JSON解析失败: {e}, 使用原始内容")
        result = {
            "answer_text": content_text,
            "source": "",
            "handoff_label": "",
            "handoff_url": ""
        }

    # 硬性约束：如果有知识库内容但source为空，尝试从检索结果中提取来源
    answer_text = result.get("answer_text", "")
    extracted_source = result.get("source", "")
    
    if state.knowledge_retrieval and not extracted_source:
        extracted_source = _extract_source_from_retrieval(state.knowledge_retrieval)
        if extracted_source:
            logger.info(f"从检索结果中提取来源: {extracted_source}")

    # 优先使用上游传入的doc_source，其次使用从回答中提取的source
    final_source = doc_source or extracted_source
    
    # 优先使用上游传入的feishu_path，其次根据biz_type推断
    final_path = feishu_path
    if not final_path:
        final_path = FEISHU_PATH_MAP.get(state.biz_type, "")

    # 在回答末尾统一拼接规则来源与办事入口路径
    if final_source or final_path:
        answer_text = _append_source_and_path(answer_text, final_source, final_path)

    # 前置校验二次检查：如果有业务内容但回答包含兜底话术，记录警告
    if has_business_content:
        fallback_phrases = ["未明确规定", "建议联系HR", "联系人事", "暂无相关规定"]
        for phrase in fallback_phrases:
            if phrase in answer_text:
                logger.warning(f"前置校验警告：回答包含兜底话术'{phrase}'，但检索结果包含业务内容")
                break

    return NormalAnswerOutput(normal_answer={
        "answer_text": answer_text,
        "source": final_source,
        "handoff_label": "",
        "handoff_url": ""
    })
