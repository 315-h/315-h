"""
结果合并节点：合并向量检索 + 关键词检索结果
权重融合逻辑：向量检索内容权重0.65作为回答主体，关键词检索仅提取金额、审批层级、时间、天数等实体信息做补充
若两类检索内容出现规则冲突，统一以向量检索文本为准
"""
import logging
import re
from typing import List, Dict, Any, Set, Optional
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from graphs.state import MergeRetrievalInput, MergeRetrievalOutput

logger = logging.getLogger(__name__)

# 最小有效内容长度（低于此长度视为纯标题/无效片段）
MIN_VALID_LENGTH = 50
# 向量检索权重
VECTOR_WEIGHT = 0.65
# 关键词检索权重
KEYWORD_WEIGHT = 0.35

# 禁止纯标题模式
TITLE_PATTERNS = [
    r'^[一二三四五六七八九十]+[、.．]\s*\S+$',
    r'^第[一二三四五六七八九十]+[章节篇条]\s*\S+$',
    r'^\d+[.．]\s*\S+$',
    r'^[（(][一二三四五六七八九十\d]+[)）]\s*\S+$',
]

# 实体提取关键词
ENTITY_KEYWORDS = {
    'amount': ['元', '万元', '额度', '上限', '下限', '金额', '费用', '报销'],
    'approval': ['审批', '审核', '批准', '报批', '总经理', '部门经理', '总监', '主管'],
    'time': ['天', '日', '月', '年', '小时', '工作日', '期限', '时效'],
    'quantity': ['次', '份', '件', '个', '套', '数量', '次数']
}


def _is_title_only(content: str) -> bool:
    """判断是否仅为标题（无有效正文）"""
    if not content:
        return True
    content = content.strip()
    # 含业务关键词的短片段也视为有效正文（如"病假超6个月按60%发放"）
    has_biz_kw = any(kw in content for kw in [
        '审批', '申请', '提交', '元', '天', '年', '月', '流程', '步骤', '规定', '制度',
        '报销', '假', '薪资', '工资', '申领', '领', '标准', '额度', '上限', '下限', '比例'
    ])
    if len(content) < MIN_VALID_LENGTH and not has_biz_kw:
        return True
    for pattern in TITLE_PATTERNS:
        if re.match(pattern, content):
            return True
    has_content = bool(re.search(r'\d+', content)) or has_biz_kw
    return not has_content



def _extract_entities(content: str) -> Dict[str, List[str]]:
    """从内容中提取实体信息（金额、审批层级、时间、数量等）"""
    entities: Dict[str, List[str]] = {
        'amount': [],
        'approval': [],
        'time': [],
        'quantity': []
    }
    if not content:
        return entities
    
    # 提取金额实体
    amount_patterns = [
        r'(\d+(?:\.\d+)?)\s*(?:元|万元)',
        r'(?:上限|下限|额度)\s*(?:为|是)?\s*(\d+(?:\.\d+)?)\s*(?:元|万元)?',
        r'(\d+(?:\.\d+)?)\s*(?:元|万元)?\s*/\s*(?:人|次|天|月|年)'
    ]
    for pattern in amount_patterns:
        matches = re.findall(pattern, content)
        entities['amount'].extend(matches)
    
    # 提取审批层级
    approval_keywords = ['总经理', '部门经理', '总监', '主管', '财务', '人力', '行政审批']
    for kw in approval_keywords:
        if kw in content:
            entities['approval'].append(kw)
    
    # 提取时间实体
    time_patterns = [
        r'(\d+)\s*(?:天|日|月|年|小时|工作日)',
        r'(?:每|每年|每月)\s*(\d+)\s*(?:日|号|次)',
        r'(\d+)\s*(?:月|年)\s*(?:\d+)\s*(?:日|号)'
    ]
    for pattern in time_patterns:
        matches = re.findall(pattern, content)
        entities['time'].extend(matches)
    
    # 去重
    for key in entities:
        entities[key] = list(dict.fromkeys(entities[key]))
    
    return entities


def _check_rule_conflict(vector_content: str, keyword_content: str) -> bool:
    """检查向量检索和关键词检索内容是否存在规则冲突"""
    if not vector_content or not keyword_content:
        return False
    
    # 提取两边的数值规则
    vector_numbers = set(re.findall(r'\d+(?:\.\d+)?', vector_content))
    keyword_numbers = set(re.findall(r'\d+(?:\.\d+)?', keyword_content))
    
    # 如果两边都包含数值，检查是否有明显冲突
    # 这里简化处理：如果关键词检索的数值与向量检索的数值差异过大，视为潜在冲突
    if vector_numbers and keyword_numbers:
        # 检查是否有相同的上下文但不同的数值
        vector_context = re.findall(r'(\w{2,10}\d+\w{0,10})', vector_content)
        keyword_context = re.findall(r'(\w{2,10}\d+\w{0,10})', keyword_content)
        
        # 如果上下文相似但数值不同，可能存在冲突
        for vc in vector_context:
            for kc in keyword_context:
                # 提取上下文中的文字部分
                vc_text = re.sub(r'\d+', '', vc)
                kc_text = re.sub(r'\d+', '', kc)
                if vc_text == kc_text and len(vc_text) > 2:
                    # 上下文相同但数值可能不同
                    vc_nums = set(re.findall(r'\d+', vc))
                    kc_nums = set(re.findall(r'\d+', kc))
                    if vc_nums != kc_nums:
                        return True
    
    return False


def _sort_priority(chunk: Dict[str, Any]) -> tuple:
    """排序优先级：含数值规则 > 含审批流程 > 内容长度 > 来源"""
    has_numeric = 1 if chunk.get("has_numeric_rule", False) else 0
    has_approval = 1 if chunk.get("has_approval_flow", False) else 0
    content_len = len(chunk.get("content", ""))
    score = chunk.get("score", 0.0)
    kw_score = chunk.get("kw_score", 0.0)
    # 向量来源优先
    source_priority = 1 if chunk.get("source") == "vector" else 0
    return (has_numeric, has_approval, source_priority, content_len, score + kw_score)


def merge_retrieval_node(
    state: MergeRetrievalInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> MergeRetrievalOutput:
    """
    title: 结果合并
    desc: 合并向量检索+关键词检索结果，权重融合（向量0.65+关键词实体补充），去重排序
    """
    # 获取两路检索结果
    vector_chunks_input = state.vector_chunks if state.vector_chunks else []
    keyword_chunks_input = state.keyword_chunks if state.keyword_chunks else []
    vector_result: str = state.vector_result if state.vector_result else ""
    keyword_result: str = state.keyword_result if state.keyword_result else ""
    vector_sources: List[str] = state.vector_sources if state.vector_sources else []
    vector_paths: List[str] = state.vector_paths if state.vector_paths else []
    keyword_sources: List[str] = state.keyword_sources if state.keyword_sources else []
    keyword_paths: List[str] = state.keyword_paths if state.keyword_paths else []

    has_any_input = bool(vector_chunks_input or keyword_chunks_input or vector_result or keyword_result)
    if not has_any_input:
        logger.warning("合并检索：两路均无结果")
        return MergeRetrievalOutput(
            knowledge_retrieval="",
            has_valid_content=False,
            top_score=0.0,
            retrieval_sources=[],
            retrieval_paths=[],
            fused_content=""
        )

    # 解析两路结果为结构化片段列表
    vector_chunks: List[Dict[str, Any]] = []
    keyword_chunks: List[Dict[str, Any]] = []
    seen_contents: Set[str] = set()
    top_score: float = 0.0

    # 解析向量检索结果 - 支持列表格式和字符串格式
    if vector_chunks_input and isinstance(vector_chunks_input, list):
        for chunk in vector_chunks_input:
            if isinstance(chunk, dict):
                content = chunk.get("content", "")
                score = float(chunk.get("score", 0.0))
                source = chunk.get("source", "")
                if content and content not in seen_contents:
                    seen_contents.add(content)
                    has_numeric = bool(re.search(r'\d+', content))
                    has_approval = any(kw in content for kw in ['审批', '审核', '批准', '报批', '申请', '提交'])
                    vector_chunks.append({
                        "content": content,
                        "score": score,
                        "source": source,
                        "has_numeric_rule": has_numeric,
                        "has_approval_flow": has_approval
                    })
                    if score > top_score:
                        top_score = score
    elif vector_result:
        # 兼容旧的字符串格式
        vector_parts = vector_result.split("\n\n")
        for part in vector_parts:
            content = part.strip()
            if not content:
                continue
            score_match = re.search(r'score=([\d.]+)', content)
            score = float(score_match.group(1)) if score_match else 0.0
            clean_content = re.sub(r'^\[.*?\]\n', '', content).strip()
            content_key = clean_content[:100] if clean_content else ""
            if content_key and content_key not in seen_contents:
                seen_contents.add(content_key)
                has_numeric = bool(re.search(r'\d+', clean_content)) if clean_content else False
                has_approval = any(kw in clean_content for kw in ['审批', '审核', '批准', '报批', '申请', '提交']) if clean_content else False
                vector_chunks.append({
                    "content": clean_content,
                    "score": score,
                    "source": "vector",
                    "has_numeric_rule": has_numeric,
                    "has_approval_flow": has_approval
                })
                if score > top_score:
                    top_score = score

    # 解析关键词检索结果 - 支持列表格式和字符串格式
    if keyword_chunks_input and isinstance(keyword_chunks_input, list):
        for chunk in keyword_chunks_input:
            if isinstance(chunk, dict):
                content = chunk.get("content", "")
                score = float(chunk.get("score", 0.0))
                source = chunk.get("source", "")
                if content and content not in seen_contents:
                    seen_contents.add(content)
                    has_numeric = bool(re.search(r'\d+', content))
                    has_approval = any(kw in content for kw in ['审批', '审核', '批准', '报批', '申请', '提交'])
                    keyword_chunks.append({
                        "content": content,
                        "score": score,
                        "source": source,
                        "has_numeric_rule": has_numeric,
                        "has_approval_flow": has_approval
                    })
                    if score > top_score:
                        top_score = score
    elif keyword_result:
        # 兼容旧的字符串格式
        keyword_parts = keyword_result.split("\n\n")
        for part in keyword_parts:
            content = part.strip()
            if not content:
                continue
            kw_score_match = re.search(r'kw_score=([\d.]+)', content)
            kw_score = float(kw_score_match.group(1)) if kw_score_match else 0.0
            clean_content = re.sub(r'^\[.*?\]\n', '', content).strip()
            content_key = clean_content[:100] if clean_content else ""
            if content_key and content_key not in seen_contents:
                seen_contents.add(content_key)
                has_numeric = bool(re.search(r'\d+', clean_content)) if clean_content else False
                has_approval = any(kw in clean_content for kw in ['审批', '审核', '批准', '报批', '申请', '提交']) if clean_content else False
                keyword_chunks.append({
                    "content": clean_content,
                    "score": kw_score,
                    "source": "keyword",
                    "has_numeric_rule": has_numeric,
                    "has_approval_flow": has_approval
                })
                if kw_score > top_score:
                    top_score = kw_score

    # 权重融合逻辑
    # 1. 向量检索内容作为主体（权重0.65）
    # 2. 关键词检索仅提取实体信息做补充（权重0.35）
    # 3. 若存在规则冲突，以向量检索为准
    
    fused_parts: List[str] = []
    fused_entities: Dict[str, Set[str]] = {'amount': set(), 'approval': set(), 'time': set(), 'quantity': set()}
    
    # 添加向量检索内容（主体）
    for chunk in vector_chunks:
        fused_parts.append(f"[向量检索·主体] {chunk['content']}")
    
    # 从关键词检索中提取实体信息（补充）
    keyword_entity_supplements: List[str] = []
    for chunk in keyword_chunks:
        entities = _extract_entities(chunk['content'])
        for entity_type, values in entities.items():
            for v in values:
                fused_entities[entity_type].add(v)
        
        # 检查是否与向量检索内容冲突
        has_conflict = False
        for vc in vector_chunks:
            if _check_rule_conflict(vc['content'], chunk['content']):
                has_conflict = True
                logger.warning(f"检测到规则冲突，以向量检索为准: {chunk['content'][:50]}...")
                break
        
        # 如果不冲突，添加关键词检索的实体补充
        if not has_conflict and chunk['content']:
            keyword_entity_supplements.append(f"[关键词检索·实体补充] {chunk['content']}")
    
    # 添加关键词检索的实体补充
    fused_parts.extend(keyword_entity_supplements)
    
    # 合并所有片段用于排序
    all_chunks = vector_chunks + keyword_chunks
    all_chunks.sort(key=_sort_priority, reverse=True)

    # 检测是否有有效正文内容
    has_valid: bool = False
    for chunk in all_chunks:
        content = chunk.get("content", "")
        if not _is_title_only(content):
            has_valid = True
            break

    # 格式化为文本
    lines: List[str] = []
    for i, chunk in enumerate(all_chunks):
        flags = []
        if chunk.get("has_numeric_rule"):
            flags.append("含数值规则")
        if chunk.get("has_approval_flow"):
            flags.append("含审批流程")
        flag_str = f" [{', '.join(flags)}]" if flags else ""
        source_tag = "向量" if chunk.get("source") == "vector" else "关键词"
        lines.append(f"【片段{i+1}·{source_tag}】(score={chunk.get('score', 0):.2f}){flag_str}\n{chunk['content']}")

    # 合并来源和路径（去重）
    all_sources: List[str] = []
    all_paths: List[str] = []
    seen_sources: Set[str] = set()
    seen_paths: Set[str] = set()
    
    for s in vector_sources + keyword_sources:
        if s and s not in seen_sources:
            seen_sources.add(s)
            all_sources.append(s)
    
    for p in vector_paths + keyword_paths:
        if p and p not in seen_paths:
            seen_paths.add(p)
            all_paths.append(p)

    fused_content = "\n\n".join(fused_parts) if fused_parts else ""

    return MergeRetrievalOutput(
        knowledge_retrieval="\n\n".join(lines),
        has_valid_content=has_valid,
        top_score=top_score,
        retrieval_sources=all_sources,
        retrieval_paths=all_paths,
        fused_content=fused_content
    )
