"""
兜底回答节点：当知识库未找到相关内容时，使用大模型返回固定兜底话术
"""
import os
import json
import logging
from typing import Any, Dict
from jinja2 import Template
from langchain_core.runnables import RunnableConfig
from langchain_core.messages import SystemMessage, HumanMessage
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context, new_context
from coze_coding_dev_sdk import LLMClient
from graphs.state import FallbackAnswerInput, FallbackAnswerOutput

logger = logging.getLogger(__name__)


def _extract_text_content(content: Any) -> str:
    """安全提取LLM响应中的文本内容"""
    if isinstance(content, str):
        return content
    elif isinstance(content, list):
        if content and isinstance(content[0], str):
            return " ".join(content)
        else:
            text_parts = [
                item.get("text", "")
                for item in content
                if isinstance(item, dict) and item.get("type") == "text"
            ]
            return " ".join(text_parts)
    return str(content)


def fallback_answer_node(
    state: FallbackAnswerInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> FallbackAnswerOutput:
    """
    title: 兜底回答
    desc: 当知识库检索未找到相关内容时，使用DeepSeek-V3大模型返回固定的兜底引导话术
    integrations: 大语言模型
    """
    ctx = runtime.context

    # 从config的metadata读取LLM配置文件路径
    cfg_file: str = os.path.join(
        os.getenv("COZE_WORKSPACE_PATH", ""),
        config["metadata"]["llm_cfg"]
    )
    with open(cfg_file, "r", encoding="utf-8") as f:
        _cfg: Dict[str, Any] = json.load(f)

    llm_config: Dict[str, Any] = _cfg.get("config", {})
    sp: str = _cfg.get("sp", "")
    up: str = _cfg.get("up", "")

    # 使用jinja2渲染用户提示词模板
    up_tpl = Template(up)
    rendered_up: str = up_tpl.render(user_input=state.user_input)

    # 初始化LLM客户端
    llm_client = LLMClient(ctx=ctx)

    # 构建消息
    messages = [
        SystemMessage(content=sp),
        HumanMessage(content=rendered_up)
    ]

    # 调用大模型
    response = llm_client.invoke(
        messages=messages,
        model=llm_config.get("model", "deepseek-v3-2-251201"),
        temperature=llm_config.get("temperature", 0.1),
        top_p=llm_config.get("top_p", 0.7),
        max_completion_tokens=llm_config.get("max_completion_tokens", 500),
        thinking=llm_config.get("thinking", "disabled")
    )

    # 安全提取响应内容
    content_text: str = _extract_text_content(response.content)

    return FallbackAnswerOutput(fallback_answer=content_text)
