"""
知识库向量检索节点（分支A）：从企业制度知识库中向量检索相关内容，Top 5
输出：vector_chunks（合并文本）、vector_top_score、doc_source、feishu_path
"""
import logging
import json
import re
from typing import List, Any, Dict, Set
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from coze_coding_dev_sdk import KnowledgeClient, Config
from graphs.state import VectorRetrievalInput, VectorRetrievalOutput

logger = logging.getLogger(__name__)

KNOWLEDGE_BASE_NAME = "coze_doc_knowledge"
MIN_SCORE = 0.6
TOP_K = 5

# 业务类型到飞书办理路径的映射
FEISHU_PATH_MAP = {
    "假期": "飞书-请假管理-对应假期申请单",
    "报销": "飞书首页 > 费用报销 > 新建报销",
    "办公用品": "飞书首页 > 办公用品 > 新建申领",
    "其他": ""
}


def _extract_source_from_content(content: str) -> str:
    """从内容中提取来源文档名"""
    if not content:
        return ""
    # 尝试从内容中提取来源标记
    patterns = [
        r'【来源[：:]\s*([^\]】]+)[\]】]',
        r'\[来源[：:]\s*([^\]]+)\]',
        r'来源[：:]\s*([^\n,，]+)',
    ]
    for pattern in patterns:
        match = re.search(pattern, content)
        if match:
            return match.group(1).strip()
    # 根据内容关键词推断来源
    if any(kw in content for kw in ['假期', '年假', '病假', '事假', '婚假', '产假', '丧假']):
        return "公司假期制度"
    elif any(kw in content for kw in ['报销', '发票', '补贴', '宴请', '出差']):
        return "企业报销制度"
    elif any(kw in content for kw in ['办公用品', '鼠标', '键盘', '显示器', '申领', '设备']):
        return "办公用品申领制度"
    return ""


def vector_retrieval_node(
    state: VectorRetrievalInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> VectorRetrievalOutput:
    """
    title: 向量检索（分支A）
    desc: 按子问题分类独立向量检索知识库，Top 5召回，阈值0.6，+全库补搜
    integrations: 知识库
    """
    ctx = runtime.context

    split_questions: List[str] = state.split_questions if state.split_questions else []
    biz_types: List[str] = state.biz_types if state.biz_types else []
    query_rewrite: str = state.query_rewrite if state.query_rewrite else ""

    if len(biz_types) < len(split_questions):
        biz_types.extend(["其他"] * (len(split_questions) - len(biz_types)))

    if not split_questions and query_rewrite:
        split_questions = [query_rewrite]
        biz_types = ["其他"]

    if not split_questions:
        logger.warning("向量检索：无有效查询输入")
        return VectorRetrievalOutput(vector_result="", vector_score=0.0, vector_chunks=[], retrieval_sources=[], retrieval_paths=[])

    sdk_config = Config()
    client = KnowledgeClient(config=sdk_config, ctx=ctx)

    all_chunks: List[Dict[str, Any]] = []
    top_score: float = 0.0
    seen_contents: Set[str] = set()
    sources: Set[str] = set()

    # 按子问题独立检索
    for idx, (question, biz_type) in enumerate(zip(split_questions, biz_types)):
        if not isinstance(question, str) or not question.strip():
            continue
        search_query = question.strip()
        logger.info(f"向量检索-子问题{idx+1}({biz_type}): {search_query[:50]}...")
        try:
            response = client.search(
                query=search_query,
                table_names=[KNOWLEDGE_BASE_NAME],
                top_k=TOP_K,
                min_score=MIN_SCORE
            )
            if response.code == 0 and response.chunks:
                for chunk in response.chunks:
                    score = float(chunk.score) if chunk.score else 0.0
                    content = str(chunk.content) if chunk.content else ""
                    content_key = content[:100] if content else ""
                    if content_key and content_key not in seen_contents:
                        seen_contents.add(content_key)
                        # 检测是否包含数值规则、审批流程等
                        has_numeric = bool(re.search(r'\d+', content)) if content else False
                        has_approval = any(kw in content for kw in ['审批', '审核', '批准', '报批']) if content else False
                        source = _extract_source_from_content(content)
                        if source:
                            sources.add(source)
                        all_chunks.append({
                            "content": content,
                            "score": score,
                            "source": "vector",
                            "doc_source": source,
                            "biz_type": biz_type,
                            "sub_question": search_query,
                            "has_numeric_rule": has_numeric,
                            "has_approval_flow": has_approval
                        })
                        if score > top_score:
                            top_score = score
                        logger.info(f"  向量召回(score={score:.2f}): {content[:80]}...")
        except Exception as e:
            logger.error(f"向量检索-子问题{idx+1}失败: {e}")

    # 全知识库补搜
    if query_rewrite:
        logger.info(f"向量检索-全库补搜: {query_rewrite[:50]}...")
        try:
            response = client.search(
                query=query_rewrite,
                table_names=[KNOWLEDGE_BASE_NAME],
                top_k=TOP_K,
                min_score=MIN_SCORE
            )
            if response.code == 0 and response.chunks:
                for chunk in response.chunks:
                    score = float(chunk.score) if chunk.score else 0.0
                    content = str(chunk.content) if chunk.content else ""
                    content_key = content[:100] if content else ""
                    if content_key and content_key not in seen_contents:
                        seen_contents.add(content_key)
                        has_numeric = bool(re.search(r'\d+', content)) if content else False
                        has_approval = any(kw in content for kw in ['审批', '审核', '批准', '报批']) if content else False
                        source = _extract_source_from_content(content)
                        if source:
                            sources.add(source)
                        all_chunks.append({
                            "content": content,
                            "score": score,
                            "source": "vector",
                            "doc_source": source,
                            "biz_type": "全库",
                            "sub_question": query_rewrite,
                            "has_numeric_rule": has_numeric,
                            "has_approval_flow": has_approval
                        })
        except Exception as e:
            logger.error(f"向量检索-全库补搜失败: {e}")

    if not all_chunks:
        logger.warning("向量检索：无有效召回")
        return VectorRetrievalOutput(vector_result="", vector_score=0.0, vector_chunks=[], retrieval_sources=[], retrieval_paths=[])

    # 按得分排序
    all_chunks.sort(key=lambda x: x["score"], reverse=True)

    lines: List[str] = []
    for i, chunk in enumerate(all_chunks):
        prefix = f"[向量检索-片段{i+1}](score={chunk['score']:.2f})"
        lines.append(f"{prefix}\n{chunk['content']}")
    result_text = "\n\n".join(lines)

    # 确定主要来源和飞书路径
    doc_source = "、".join(sorted(sources)) if sources else ""
    # 根据主要业务类型确定飞书路径
    primary_biz = biz_types[0] if biz_types else "其他"
    feishu_path = FEISHU_PATH_MAP.get(primary_biz, "")

    logger.info(f"向量检索完成：{len(all_chunks)}个片段，top_score={top_score:.2f}，source={doc_source}")
    return VectorRetrievalOutput(
        vector_result=result_text,
        vector_score=top_score,
        vector_chunks=all_chunks,
        retrieval_sources=list(sources),
        retrieval_paths=[feishu_path] if feishu_path else []
    )
