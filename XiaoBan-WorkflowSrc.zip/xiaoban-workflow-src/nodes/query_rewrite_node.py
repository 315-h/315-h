"""
问题改写节点：将员工口语化提问规范化，提升后续匹配准确率
"""
import os
import json
import logging
from typing import Any
from jinja2 import Template
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from coze_coding_dev_sdk import LLMClient
from graphs.state import QueryRewriteInput, QueryRewriteOutput

logger = logging.getLogger(__name__)


def _extract_text_content(content: Any) -> str:
    """安全提取LLM响应中的文本内容"""
    if isinstance(content, str):
        return content
    elif isinstance(content, list):
        if content and isinstance(content[0], str):
            return " ".join(content)
        else:
            text_parts = [
                item.get("text", "")
                for item in content
                if isinstance(item, dict) and item.get("type") == "text"
            ]
            return " ".join(text_parts)
    return str(content)


def query_rewrite_node(
    state: QueryRewriteInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> QueryRewriteOutput:
    """
    title: 问题改写
    desc: 将员工口语化提问规范化为标准问句，修正错别字、补齐主体、转换简称，提升后续问题拆分和知识库检索的匹配准确率
    integrations: 大语言模型
    """
    ctx = runtime.context

    # 获取用户原始提问
    query_raw: str = state.user_input
    if not query_raw or not isinstance(query_raw, str):
        return QueryRewriteOutput(query_rewrite="")

    # 读取LLM配置
    cfg_file: str = os.path.join(
        os.getenv("COZE_WORKSPACE_PATH", ""),
        config["metadata"]["llm_cfg"]
    )
    with open(cfg_file, "r", encoding="utf-8") as f:
        _cfg: dict = json.load(f)

    llm_config: dict = _cfg.get("config", {})
    sp: str = _cfg.get("sp", "")
    up_tpl: str = _cfg.get("up", "")

    # 渲染用户提示词
    up_rendered: str = Template(up_tpl).render(query_raw=query_raw)

    # 初始化LLM客户端
    client = LLMClient(ctx=ctx)

    # 构建消息
    messages = [
        SystemMessage(content=sp),
        HumanMessage(content=up_rendered)
    ]

    # 调用LLM
    response = client.invoke(
        messages=messages,
        model=llm_config.get("model", "deepseek-v3-2-251201"),
        temperature=llm_config.get("temperature", 0.1),
        top_p=llm_config.get("top_p", 0.7),
        max_completion_tokens=llm_config.get("max_completion_tokens", 500),
        thinking=llm_config.get("thinking", "disabled")
    )

    # 提取改写结果
    query_rewrite: str = _extract_text_content(response.content).strip()

    # 如果改写结果为空，使用原始输入作为兜底
    if not query_rewrite:
        query_rewrite = query_raw

    logger.info(f"问题改写: raw='{query_raw}' -> rewrite='{query_rewrite}'")

    return QueryRewriteOutput(query_rewrite=query_rewrite)
