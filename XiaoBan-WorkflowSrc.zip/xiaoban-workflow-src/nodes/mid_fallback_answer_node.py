"""
过渡兜底回答节点：检索得分0.2-0.6时，输出「检索到条目但无细则」过渡兜底
无有效path时仅展示来源信息
"""
import logging
import re
from typing import List
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from graphs.state import MidFallbackAnswerInput, MidFallbackAnswerOutput

logger = logging.getLogger(__name__)

# 业务类型到飞书办理路径的映射
FEISHU_PATH_MAP = {
    "假期": "飞书-请假管理-对应假期申请单",
    "报销": "飞书首页 > 费用报销 > 新建报销",
    "办公用品": "飞书首页 > 办公用品 > 新建申领",
    "其他": ""
}


def _extract_source_from_retrieval(retrieval_text: str) -> str:
    """从检索结果中提取来源信息"""
    if not retrieval_text:
        return ""
    
    # 尝试提取文件名
    source_match = re.search(r'[\u4e00-\u9fa5\w\-]+\.txt', retrieval_text)
    if source_match:
        return source_match.group(0)
    
    # 尝试提取"来源："后的内容
    source_match = re.search(r'来源[：:]\s*([^\n]+)', retrieval_text)
    if source_match:
        return source_match.group(1).strip()
    
    return ""


def mid_fallback_answer_node(
    state: MidFallbackAnswerInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> MidFallbackAnswerOutput:
    """
    title: 过渡兜底回答
    desc: 当知识库检索得分在0.2-0.6之间时，输出「检索到条目但无细则」的过渡兜底文本；无有效path时仅展示来源信息
    """
    ctx = runtime.context

    # 提取匹配到的章节标题（从检索结果中）
    matched_topics: List[str] = []
    retrieval_text: str = state.knowledge_retrieval if state.knowledge_retrieval else ""

    # 尝试从检索结果中提取关键信息
    if retrieval_text:
        lines = retrieval_text.split("\n")
        for line in lines[:5]:  # 只看前几行
            line = line.strip()
            if line and len(line) < 50 and not line.startswith("【"):
                matched_topics.append(line)

    # 构造过渡兜底文本
    user_question: str = state.user_input if state.user_input else "您的问题"
    score_info: str = f"（匹配度: {state.top_score:.0%}）" if state.top_score > 0 else ""

    if matched_topics:
        topic_hint: str = f"，可能涉及「{matched_topics[0]}」相关内容"
    else:
        topic_hint = ""

    fallback_text: str = (
        f"关于「{user_question}」{topic_hint}{score_info}，"
        f"我们在公司制度中检索到了相关条目，但暂未找到对应的详细实施细则。\n\n"
        f"建议您：\n"
        f"1. 联系 HR 部门获取最新政策说明（邮箱：hr@company.com）\n"
        f"2. 或咨询您的直属上级了解具体操作流程\n\n"
        f"我们会持续完善制度文档，感谢您的理解！"
    )

    # 获取来源信息（从检索结果中提取）
    doc_source: str = state.doc_source if state.doc_source else ""
    if not doc_source and retrieval_text:
        doc_source = _extract_source_from_retrieval(retrieval_text)

    # 获取飞书路径
    feishu_path: str = state.feishu_path if state.feishu_path else ""
    if not feishu_path:
        feishu_path = FEISHU_PATH_MAP.get(state.biz_type, "")

    # 拼接来源和路径信息
    # 兜底回答无有效path时仅展示来源信息
    suffix_parts: List[str] = []
    if doc_source:
        suffix_parts.append(f"\n\n【规则来源：{doc_source}】")
    if feishu_path:
        suffix_parts.append(f"【办事入口：{feishu_path}】")

    if suffix_parts:
        fallback_text += "".join(suffix_parts)

    return MidFallbackAnswerOutput(mid_fallback_answer=fallback_text)
