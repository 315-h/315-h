"""
关键词检索节点（分支B）：使用关键词词典匹配金额、审批、场景词，Top 5召回
输出：keyword_chunks（合并文本）、doc_source、feishu_path
"""
import logging
import re
import json
from typing import List, Dict, Any, Set
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from coze_coding_dev_sdk import KnowledgeClient, Config
from graphs.state import KeywordRetrievalInput, KeywordRetrievalOutput

logger = logging.getLogger(__name__)

KNOWLEDGE_BASE_NAME = "coze_doc_knowledge"
MIN_SCORE = 0.0  # 关键词检索不设阈值，靠关键词匹配
TOP_K = 10  # 拉大召回量，再通过关键词过滤

# 业务类型到飞书办理路径的映射
FEISHU_PATH_MAP = {
    "假期": "飞书-请假管理-对应假期申请单",
    "报销": "飞书首页 > 费用报销 > 新建报销",
    "办公用品": "飞书首页 > 办公用品 > 新建申领",
    "其他": ""
}

# 关键词词典：按业务分类
KEYWORD_DICT = {
    "假期": {
        "场景词": ["年假", "病假", "事假", "婚假", "产假", "陪产假", "丧假", "调休", "休假", "请假"],
        "金额词": [],
        "审批词": ["审批", "申请", "提交", "人力", "主管"],
        "时效词": ["天", "年", "月", "周", "小时", "日", "内", "前", "后"]
    },
    "报销": {
        "场景词": ["报销", "发票", "补贴", "出差", "宴请", "接待", "培训", "加班", "报账", "费用"],
        "金额词": [r"\d+元", r"\d+块", r"\d+钱", r"上限", r"标准", r"限额", r"额度"],
        "审批词": ["审批", "审核", "批准", "财务", "主管", "经理", "总经理", "总监"],
        "时效词": ["月", "天", "周", "年", "内", "前", "逾期", "超过"]
    },
    "办公用品": {
        "场景词": ["鼠标", "键盘", "显示器", "纸张", "文具", "申领", "设备", "耗材", "采购", "维修", "换新", "U盘", "座椅", "椅子", "办公桌"],
        "金额词": [r"\d+元", r"上限", r"标准", r"限额", r"单价"],
        "审批词": ["审批", "申请", "提交", "主管", "行政", "部门", "经理"],
        "时效词": ["月", "年", "天", "周", "内", "前", "周期"]
    },
    "通用": {
        "场景词": ["公司", "制度", "规定", "政策", "规则", "流程", "申请", "材料", "条件", "要求", "怎么办", "如何", "怎么", "需要"],
        "金额词": [r"\d+元", r"\d+块", r"多少钱", r"标准", r"上限"],
        "审批词": ["审批", "审核", "批准", "层级", "流程", "签批"],
        "时效词": ["多久", "什么时候", "时间", "期限", "天", "年", "月"]
    }
}


def _get_keywords_for_query(query: str, biz_types: List[str]) -> set:
    """根据问题内容和业务分类组合关键词集合"""
    keywords: set = set()
    # 添加业务分类对应的关键词
    for biz in biz_types:
        if biz in KEYWORD_DICT:
            for cat in ["场景词", "金额词", "审批词", "时效词"]:
                for kw in KEYWORD_DICT[biz][cat]:
                    if isinstance(kw, str):
                        keywords.add(kw.lower())
                    else:
                        # 正则表达式关键词（如金额模式）
                        pass
    # 添加通用关键词
    for cat in ["场景词", "金额词", "审批词", "时效词"]:
        for kw in KEYWORD_DICT["通用"][cat]:
            if isinstance(kw, str):
                keywords.add(kw.lower())

    # 从问题本身提取关键词（分词：按字词简单拆分）
    if query:
        # 提取数字相关的模式
        nums = re.findall(r'\d+', query)
        for n in nums:
            keywords.add(f"{n}元")
            keywords.add(f"{n}天")
        # 提取关键短语
        for term in ["多少", "怎么", "如何", "需要", "什么", "哪些", "是否", "能", "可以", "不能"]:
            if term in query:
                keywords.add(term)
    return keywords


def _score_chunk_by_keywords(content: str, keywords: set) -> float:
    """根据关键词匹配度评分"""
    if not content or not keywords:
        return 0.0
    content_lower = content.lower()
    matched = 0
    for kw in keywords:
        if kw in content_lower:
            matched += 1
    if len(keywords) > 0:
        return matched / len(keywords)
    return 0.0


def _extract_source_from_content(content: str) -> str:
    """从内容中提取来源文档名"""
    if not content:
        return ""
    # 尝试从内容中提取来源标记
    patterns = [
        r'【来源[：:]\s*([^\]】]+)[\]】]',
        r'\[来源[：:]\s*([^\]]+)\]',
        r'来源[：:]\s*([^\n,，]+)',
    ]
    for pattern in patterns:
        match = re.search(pattern, content)
        if match:
            return match.group(1).strip()
    # 根据内容关键词推断来源
    if any(kw in content for kw in ['假期', '年假', '病假', '事假', '婚假', '产假', '丧假']):
        return "公司假期制度"
    elif any(kw in content for kw in ['报销', '发票', '补贴', '宴请', '出差']):
        return "企业报销制度"
    elif any(kw in content for kw in ['办公用品', '鼠标', '键盘', '显示器', '申领', '设备']):
        return "办公用品申领制度"
    return ""


def keyword_retrieval_node(
    state: KeywordRetrievalInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> KeywordRetrievalOutput:
    """
    title: 关键词检索（分支B）
    desc: 使用关键词词典匹配金额、审批、场景词，Top 5召回，弥补向量检索不足
    integrations: 知识库
    """
    ctx = runtime.context

    split_questions: List[str] = state.split_questions if state.split_questions else []
    biz_types: List[str] = state.biz_types if state.biz_types else []
    query_rewrite: str = state.query_rewrite if state.query_rewrite else ""

    if len(biz_types) < len(split_questions):
        biz_types.extend(["其他"] * (len(split_questions) - len(biz_types)))

    searched_queries: List[str] = []
    if split_questions:
        searched_queries.extend(split_questions)
    if query_rewrite:
        searched_queries.append(query_rewrite)

    if not searched_queries:
        logger.warning("关键词检索：无有效查询输入")
        return KeywordRetrievalOutput(keyword_chunks="", doc_source="", feishu_path="")

    sdk_config = Config()
    client = KnowledgeClient(config=sdk_config, ctx=ctx)

    all_chunks: List[Dict[str, Any]] = []
    seen_contents: Set[str] = set()
    sources: Set[str] = set()

    # 获取关键词集合
    keywords = _get_keywords_for_query(query_rewrite or " ".join(split_questions), biz_types)
    logger.info(f"关键词检索-关键词集合: {keywords}")

    # 先执行向量检索获取候选池，再用关键词过滤排序
    for search_query in searched_queries:
        if not isinstance(search_query, str) or not search_query.strip():
            continue
        try:
            response = client.search(
                query=search_query.strip(),
                table_names=[KNOWLEDGE_BASE_NAME],
                top_k=TOP_K,
                min_score=MIN_SCORE
            )
            if response.code == 0 and response.chunks:
                for chunk in response.chunks:
                    content = str(chunk.content) if chunk.content else ""
                    score = float(chunk.score) if chunk.score else 0.0
                    content_key = content[:100] if content else ""
                    if content_key and content_key not in seen_contents:
                        seen_contents.add(content_key)
                        # 计算关键词匹配得分
                        kw_score = _score_chunk_by_keywords(content, keywords)
                        # 关键词匹配得分 > 0 才保留
                        if kw_score > 0.0:
                            has_numeric = bool(re.search(r'\d+', content)) if content else False
                            has_approval = any(kw in content for kw in ['审批', '审核', '批准', '报批', '申请', '提交']) if content else False
                            source = _extract_source_from_content(content)
                            if source:
                                sources.add(source)
                            all_chunks.append({
                                "content": content,
                                "score": score,
                                "kw_score": kw_score,
                                "source": "keyword",
                                "doc_source": source,
                                "has_numeric_rule": has_numeric,
                                "has_approval_flow": has_approval,
                                "sub_question": search_query
                            })
                            logger.info(f"  关键词匹配(kw_score={kw_score:.2f}): {content[:80]}...")
        except Exception as e:
            logger.error(f"关键词检索-查询失败({search_query[:30]}): {e}")

    # 按关键词得分排序，取Top 5
    all_chunks.sort(key=lambda x: (x["kw_score"], x["score"]), reverse=True)
    top_chunks = all_chunks[:5]

    if not top_chunks:
        logger.warning("关键词检索：无匹配结果")
        return KeywordRetrievalOutput(
            keyword_result="",
            keyword_chunks=[],
            retrieval_sources=[],
            retrieval_paths=[]
        )

    lines: List[str] = []
    for i, chunk in enumerate(top_chunks):
        prefix = f"[关键词检索-片段{i+1}](kw_score={chunk['kw_score']:.2f})"
        lines.append(f"{prefix}\n{chunk['content']}")
    result_text = "\n\n".join(lines)

    # 确定主要来源和飞书路径
    doc_source_list = sorted(sources) if sources else []
    primary_biz = biz_types[0] if biz_types else "其他"
    feishu_path = FEISHU_PATH_MAP.get(primary_biz, "")

    return KeywordRetrievalOutput(
        keyword_result=result_text,
        keyword_chunks=top_chunks,
        retrieval_sources=doc_source_list,
        retrieval_paths=[feishu_path] if feishu_path else []
    )
