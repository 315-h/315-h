"""
二次检索节点（循环重试）：当首次检索无有效内容时，扩大检索范围重试
最大重试次数2次，每次检索间隔1秒
两次检索均无有效内容才进入兜底分支
"""
import logging
import re
import time
from typing import List, Dict, Any, Set
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from coze_coding_dev_sdk import KnowledgeClient, Config
from graphs.state import SecondaryRetrievalInput, SecondaryRetrievalOutput

logger = logging.getLogger(__name__)

# 数据集名称
DATASET_NAME = "coze_doc_knowledge"
# 二次检索 Top K（扩大范围）
SECONDARY_TOP_K = 10
# 最小有效内容长度
MIN_VALID_LENGTH = 50
# 最大重试次数
MAX_RETRY = 2
# 重试间隔（秒）
RETRY_INTERVAL = 1

# 禁止纯标题模式
TITLE_PATTERNS = [
    r'^[一二三四五六七八九十]+[、.．]\s*\S+$',
    r'^第[一二三四五六七八九十]+[章节篇条]\s*\S+$',
    r'^\d+[.．]\s*\S+$',
    r'^[（(][一二三四五六七八九十\d]+[)）]\s*\S+$',
]


def _is_title_only(content: str) -> bool:
    """判断是否仅为标题（无有效正文）"""
    if not content:
        return True
    content = content.strip()
    if len(content) < MIN_VALID_LENGTH:
        return True
    for pattern in TITLE_PATTERNS:
        if re.match(pattern, content):
            return True
    has_content = bool(re.search(r'\d+', content)) or \
                  any(kw in content for kw in ['审批', '申请', '提交', '元', '天', '年', '月', '流程', '步骤', '规定', '制度'])
    return not has_content


def _has_valid_content(chunks: List[Any]) -> bool:
    """检查检索结果中是否包含有效正文内容"""
    for chunk in chunks:
        content = getattr(chunk, 'content', '')
        if not _is_title_only(content):
            return True
    return False


def _format_chunks(chunks: List[Any]) -> str:
    """将检索结果格式化为文本"""
    lines: List[str] = []
    for i, chunk in enumerate(chunks):
        content = getattr(chunk, 'content', '')
        score = getattr(chunk, 'score', 0.0)
        if content:
            lines.append(f"【片段{i+1}】(score={score:.2f})\n{content}")
    return "\n\n".join(lines)


def secondary_retrieval_node(
    state: SecondaryRetrievalInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> SecondaryRetrievalOutput:
    """
    title: 二次检索（循环重试）
    desc: 当首次检索无有效内容时，扩大检索范围重试，最大重试2次，间隔1秒
    """
    ctx = runtime.context
    query_rewrite: str = state.query_rewrite if state.query_rewrite else ""
    split_questions: List[str] = state.split_questions if state.split_questions else []
    biz_types: List[str] = state.biz_types if state.biz_types else []

    # 构建检索查询列表
    queries: List[str] = []
    if split_questions:
        queries.extend(split_questions)
    if query_rewrite and query_rewrite not in queries:
        queries.append(query_rewrite)
    if not queries:
        logger.warning("二次检索：无可用查询")
        return SecondaryRetrievalOutput(
            secondary_retrieval="",
            has_valid_content=False,
            secondary_sources=[],
            secondary_paths=[]
        )

    # 初始化知识库客户端
    sdk_config = Config()
    client = KnowledgeClient(config=sdk_config, ctx=ctx)
    
    all_chunks: List[Any] = []
    seen_contents: Set[str] = set()
    all_sources: Set[str] = set()
    all_paths: Set[str] = set()
    
    # 循环重试逻辑
    for retry in range(MAX_RETRY):
        logger.info(f"二次检索：第{retry + 1}次尝试")
        
        retry_chunks: List[Any] = []
        
        # 对每个查询执行检索
        for query in queries:
            try:
                results = client.search(query=query, top_k=SECONDARY_TOP_K)
                if results:
                    for chunk in results:
                        content = getattr(chunk, 'content', '')
                        content_key = content[:100] if content else ""
                        if content_key and content_key not in seen_contents:
                            seen_contents.add(content_key)
                            retry_chunks.append(chunk)
                            # 提取来源信息
                            metadata = getattr(chunk, 'metadata', {}) or {}
                            source = metadata.get('source', '')
                            path = metadata.get('path', '')
                            if source:
                                all_sources.add(source)
                            if path:
                                all_paths.add(path)
            except Exception as e:
                logger.error(f"二次检索异常: {e}")
        
        all_chunks.extend(retry_chunks)
        
        # 检查是否有有效内容
        if _has_valid_content(retry_chunks):
            logger.info(f"二次检索：第{retry + 1}次找到有效内容")
            break
        
        # 如果还有重试机会，等待间隔
        if retry < MAX_RETRY - 1:
            logger.info(f"二次检索：未找到有效内容，{RETRY_INTERVAL}秒后重试")
            time.sleep(RETRY_INTERVAL)
    
    # 格式化结果
    formatted = _format_chunks(all_chunks)
    has_valid = _has_valid_content(all_chunks)
    
    logger.info(f"二次检索完成：共{len(all_chunks)}个片段，has_valid={has_valid}")
    
    return SecondaryRetrievalOutput(
        secondary_retrieval=formatted,
        has_valid_content=has_valid,
        secondary_sources=list(all_sources),
        secondary_paths=list(all_paths)
    )
