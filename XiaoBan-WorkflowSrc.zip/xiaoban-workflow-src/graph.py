"""
小办-企业办事问答流：主图编排（混合检索架构 + 制度冲突校验）
流程：__start__ → query_rewrite → split_and_classify → standard_qa_match
  ├── 所有子问题都命中标准问答 → normal_answer → __end__
  └── 部分或全部未命中 → vector_retrieval → keyword_retrieval → merge_retrieval
                → rule_conflict_check → condition_conflict
                      ├── 真实冲突 → conflict_fallback_answer → __end__
                      └── 阶梯合规/无冲突 → condition_check → 三级路由 → normal/mid_fallback/fallback
                → condition_valid
                      ├── 无效内容 → secondary_retrieval → condition_secondary
                            ├── 有效 → normal_answer → __end__
                            └── 无效 → fallback_answer → __end__
"""
from langgraph.graph import StateGraph, END
from graphs.state import (
    GlobalState,
    GraphInput,
    GraphOutput,
    StandardQaMatchOutput,
    MergeRetrievalOutput,
    RuleConflictCheckOutput,
    SecondaryRetrievalOutput,
    ConditionCheckOutput
)

# 导入节点函数
from graphs.nodes.query_rewrite_node import query_rewrite_node
from graphs.nodes.split_and_classify_node import split_and_classify_node
from graphs.nodes.standard_qa_match_node import standard_qa_match_node
from graphs.nodes.vector_retrieval_node import vector_retrieval_node
from graphs.nodes.keyword_retrieval_node import keyword_retrieval_node
from graphs.nodes.merge_retrieval_node import merge_retrieval_node
from graphs.nodes.rule_conflict_check_node import rule_conflict_check_node
from graphs.nodes.secondary_retrieval_node import secondary_retrieval_node
from graphs.nodes.condition_check_node import condition_check_node
from graphs.nodes.normal_answer_node import normal_answer_node
from graphs.nodes.mid_fallback_answer_node import mid_fallback_answer_node
from graphs.nodes.fallback_answer_node import fallback_answer_node
from graphs.nodes.conflict_fallback_answer_node import conflict_fallback_answer_node


# ============ 条件判断函数 ============

def check_standard_qa(state: StandardQaMatchOutput) -> str:
    """
    title: 是否所有子问题都命中标准问答
    desc: 只有所有子问题都命中才直接返回，否则进入混合检索
    """
    if state.all_sub_questions_hit:
        return "全部命中"
    else:
        return "部分或全部未命中"


def check_conflict(state: RuleConflictCheckOutput) -> str:
    """
    title: 检查制度冲突类型
    desc: 区分真实冲突和阶梯合规规则
    - 真实冲突：rule_conflict_detected=true 且 is_real_conflict=true → 走冲突专属兜底
    - 虚假冲突：rule_conflict_detected=true 但 is_real_conflict=false → 正常流转（跨子问题带来的虚假冲突）
    - 阶梯合规：工龄分段、金额分档等 → 正常流转
    - 无冲突：正常流转
    """
    # 仅真实冲突才走冲突兜底分支
    if state.rule_conflict_detected and state.is_real_conflict:
        return "真实冲突"
    # 虚假冲突或无冲突继续正常流程
    return "无冲突"


def check_valid_content(state: MergeRetrievalOutput) -> str:
    """
    title: 检查是否包含有效内容
    desc: 判断合并检索结果中是否包含有效正文内容，有则进入冲突校验，无则触发二次检索
    """
    if state.has_valid_content:
        return "有效内容"
    else:
        return "无效内容"


def check_secondary_valid(state: SecondaryRetrievalOutput) -> str:
    """
    title: 二次检索结果检查
    desc: 判断二次检索是否找到有效内容，有则送入正常回答，无则全局兜底
    """
    if state.has_valid_content:
        return "有效"
    else:
        return "无效"


def route_retrieval(state: ConditionCheckOutput) -> str:
    """
    title: 检索得分路由
    desc: 根据三级路由判断结果选择对应分支
    """
    branch: str = state.route_branch if state.route_branch else "fallback"
    if branch == "normal":
        return "正常回答"
    elif branch == "mid_fallback":
        return "过渡兜底"
    else:
        return "全局兜底"


# ============ 构建主图 ============

builder = StateGraph(GlobalState, input_schema=GraphInput, output_schema=GraphOutput)

# 添加节点
builder.add_node("query_rewrite", query_rewrite_node, metadata={"type": "agent", "llm_cfg": "config/query_rewrite_llm_cfg.json"})
builder.add_node("split_and_classify", split_and_classify_node, metadata={"type": "agent", "llm_cfg": "config/split_and_classify_llm_cfg.json"})
builder.add_node("standard_qa_match", standard_qa_match_node)
builder.add_node("vector_retrieval", vector_retrieval_node, metadata={"type": "task"})
builder.add_node("keyword_retrieval", keyword_retrieval_node, metadata={"type": "task"})
builder.add_node("merge_retrieval", merge_retrieval_node, metadata={"type": "task"})
builder.add_node("rule_conflict_check", rule_conflict_check_node, metadata={"type": "task"})
builder.add_node("secondary_retrieval", secondary_retrieval_node, metadata={"type": "task"})
builder.add_node("condition_check", condition_check_node)
builder.add_node("normal_answer", normal_answer_node, metadata={"type": "agent", "llm_cfg": "config/normal_answer_llm_cfg.json"})
builder.add_node("mid_fallback_answer", mid_fallback_answer_node)
builder.add_node("fallback_answer", fallback_answer_node, metadata={"type": "agent", "llm_cfg": "config/fallback_answer_llm_cfg.json"})
builder.add_node("conflict_fallback_answer", conflict_fallback_answer_node)

# 设置入口点
builder.set_entry_point("query_rewrite")

# 添加边：query_rewrite → split_and_classify → standard_qa_match
builder.add_edge("query_rewrite", "split_and_classify")
builder.add_edge("split_and_classify", "standard_qa_match")

# 条件分支：standard_qa_match → 全部命中/部分或全部未命中
# 全部命中 → 直接走正常回答；否则 → 进入混合检索
builder.add_conditional_edges(
    source="standard_qa_match",
    path=check_standard_qa,
    path_map={
        "全部命中": "normal_answer",
        "部分或全部未命中": "vector_retrieval"
    }
)

# 混合检索链路：向量检索 → 关键词检索 → 合并
builder.add_edge("vector_retrieval", "keyword_retrieval")
builder.add_edge("keyword_retrieval", "merge_retrieval")

# 合并结果 → 条件判断：有效内容/无效内容
builder.add_conditional_edges(
    source="merge_retrieval",
    path=check_valid_content,
    path_map={
        "有效内容": "rule_conflict_check",
        "无效内容": "secondary_retrieval"
    }
)

# 冲突校验 → 真实冲突/无冲突（阶梯合规规则视为无冲突）
builder.add_conditional_edges(
    source="rule_conflict_check",
    path=check_conflict,
    path_map={
        "真实冲突": "conflict_fallback_answer",
        "无冲突": "condition_check"
    }
)

# 无冲突 → 三级路由
builder.add_conditional_edges(
    source="condition_check",
    path=route_retrieval,
    path_map={
        "正常回答": "normal_answer",
        "过渡兜底": "mid_fallback_answer",
        "全局兜底": "fallback_answer"
    }
)

# 无效内容 → 二次检索 → 判断是否有效
builder.add_conditional_edges(
    source="secondary_retrieval",
    path=check_secondary_valid,
    path_map={
        "有效": "normal_answer",
        "无效": "fallback_answer"
    }
)

# 终止节点
builder.add_edge("normal_answer", END)
builder.add_edge("mid_fallback_answer", END)
builder.add_edge("fallback_answer", END)
builder.add_edge("conflict_fallback_answer", END)

# 编译图
main_graph = builder.compile()
