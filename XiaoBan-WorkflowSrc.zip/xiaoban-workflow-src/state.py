"""
小办-企业办事问答流：状态定义
定义全局状态、图输入输出、各节点独立输入输出
"""
from typing import List, Optional, Any, Dict
from pydantic import BaseModel, Field


class SubQuestionStandardHit(BaseModel):
    """单条子问题的标准QA命中结果"""
    sub_question: str = Field(default="", description="子问题原文")
    hit: bool = Field(default=False, description="是否命中标准QA")
    answer_text: str = Field(default="", description="命中时的预制答案")
    source: str = Field(default="", description="来源文档")
    path: str = Field(default="", description="办事路径")
    steps: str = Field(default="", description="填写步骤")


class GlobalState(BaseModel):
    """全局状态定义"""
    user_input: str = Field(default="", description="用户输入的问题")
    query_rewrite: str = Field(default="", description="标准化改写后的问句")
    split_questions: List[str] = Field(default=[], description="拆分后的子问题列表")
    biz_type: str = Field(default="其他", description="主业务分类标签：假期/报销/办公用品/其他")
    biz_types: List[str] = Field(default=[], description="每条子问题对应的业务分类标签列表")
    # 标准QA匹配 - 子问题级别
    standard_hit: bool = Field(default=False, description="是否有任何子问题命中高频标准问答")
    standard_match_type: str = Field(default="", description="标准问答匹配类型：whole_sentence_match/sub_question_match/knowledge_match/none")
    standard_answer: dict = Field(default={}, description="标准问答命中时直接返回的预制回答（仅用于全命中场景）")
    sub_question_standard_hits: List[SubQuestionStandardHit] = Field(default=[], description="每条子问题的标准QA命中结果")
    # 检索相关
    knowledge_retrieval: str = Field(default="", description="知识库检索结果的格式化文本（向量检索+关键词检索合并）")
    top_score: float = Field(default=0.0, description="检索结果中最高得分")
    route_branch: str = Field(default="fallback", description="路由分支：normal/mid_fallback/fallback")
    has_valid_content: bool = Field(default=False, description="合并检索结果中是否包含有效正文内容")
    merged_chunks: List[Dict[str, Any]] = Field(default=[], description="合并后的检索结果片段列表，含排序优先级")
    secondary_retrieval: str = Field(default="", description="二次检索结果文本（循环重试）")
    secondary_has_valid: bool = Field(default=False, description="二次检索是否有有效内容")
    # 冲突校验
    rule_conflict_detected: bool = Field(default=False, description="是否检测到真实量化规则冲突")
    is_real_conflict: bool = Field(default=False, description="是否为真实制度冲突（非阶梯规则）")
    is_tiered_rule: bool = Field(default=False, description="是否为阶梯分段合规规则")
    rule_conflict_sources: List[str] = Field(default=[], description="冲突规则的知识库文档来源列表")
    rule_conflict_details: str = Field(default="", description="冲突详情描述")
    retrieval_sources: List[str] = Field(default=[], description="检索命中的文档来源列表")
    retrieval_paths: List[str] = Field(default=[], description="检索命中的办事路径列表")
    # 回答
    normal_answer: dict = Field(default={}, description="正常回答结果JSON")
    mid_fallback_answer: str = Field(default="", description="过渡兜底回答文本（0.2-0.6分）")
    fallback_answer: str = Field(default="", description="全局兜底回答文本")
    conflict_fallback_answer: str = Field(default="", description="制度冲突专属兜底回答文本")


class GraphInput(BaseModel):
    """工作流的输入"""
    user_input: str = Field(..., description="用户输入的问题")


class GraphOutput(BaseModel):
    """工作流的输出"""
    standard_hit: bool = Field(default=False, description="是否命中高频标准问答")
    standard_match_type: str = Field(default="", description="标准问答匹配类型")
    has_valid_content: bool = Field(default=False, description="是否包含有效正文内容")
    rule_conflict_detected: bool = Field(default=False, description="是否检测到规则冲突")
    is_real_conflict: bool = Field(default=False, description="是否为真实制度冲突")
    normal_answer: dict = Field(default={}, description="正常回答结果，包含answer_text/source/handoff_label/handoff_url")
    mid_fallback_answer: str = Field(default="", description="过渡兜底回答（检索到条目但无细则）")
    fallback_answer: str = Field(default="", description="全局兜底回答文本")
    conflict_fallback_answer: str = Field(default="", description="制度冲突专属兜底回答")


# ============ 问题改写节点 ============

class QueryRewriteInput(BaseModel):
    """问题改写节点的输入"""
    user_input: str = Field(..., description="用户原始提问文本")


class QueryRewriteOutput(BaseModel):
    """问题改写节点的输出"""
    query_rewrite: str = Field(..., description="标准化改写后的问句")


# ============ 问题拆分 & 业务分类节点（合并） ============

class SplitAndClassifyInput(BaseModel):
    """问题拆分&业务分类节点的输入"""
    query_rewrite: str = Field(..., description="标准化改写后的问句")


class SplitAndClassifyOutput(BaseModel):
    """问题拆分&业务分类节点的输出"""
    split_questions: List[str] = Field(..., description="拆分后的独立子问题列表")
    biz_type: str = Field(..., description="主业务分类标签：假期/报销/办公用品/其他（取出现频率最高的）")
    biz_types: List[str] = Field(..., description="每条子问题对应的业务分类标签列表，与split_questions一一对应")


# ============ 高频标准问答匹配节点 ============

class StandardQaMatchInput(BaseModel):
    """高频标准问答匹配节点的输入"""
    query_rewrite: str = Field(..., description="标准化改写后的问句")
    split_questions: List[str] = Field(default=[], description="拆分后的子问题列表")


class StandardQaMatchOutput(BaseModel):
    """高频标准问答匹配节点的输出"""
    standard_hit: bool = Field(..., description="是否有任何子问题命中高频标准问答")
    standard_match_type: str = Field(default="none", description="匹配类型")
    standard_answer: dict = Field(default={}, description="全部子问题都命中时的预制回答JSON")
    sub_question_standard_hits: List[SubQuestionStandardHit] = Field(default=[], description="每条子问题的标准QA命中结果")
    all_sub_questions_hit: bool = Field(default=False, description="是否所有子问题都命中了标准QA")


# ============ 知识库向量检索节点（分支A - Top 5） ============

class VectorRetrievalInput(BaseModel):
    """知识库向量检索节点的输入"""
    split_questions: List[str] = Field(default=[], description="拆分后的子问题列表")
    biz_types: List[str] = Field(default=[], description="每条子问题对应的业务分类标签")
    query_rewrite: str = Field(default="", description="改写后的问句（备用）")


class VectorRetrievalOutput(BaseModel):
    """知识库向量检索节点的输出"""
    vector_result: str = Field(..., description="向量检索结果文本")
    vector_score: float = Field(default=0.0, description="向量检索最高得分")
    vector_chunks: List[Dict[str, Any]] = Field(default=[], description="向量检索结果片段列表")
    retrieval_sources: List[str] = Field(default=[], description="命中的文档来源列表")
    retrieval_paths: List[str] = Field(default=[], description="命中的办事路径列表")


# ============ 关键词检索节点（分支B - Top 5） ============

class KeywordRetrievalInput(BaseModel):
    """关键词检索节点的输入"""
    split_questions: List[str] = Field(default=[], description="拆分后的子问题列表")
    biz_types: List[str] = Field(default=[], description="每条子问题对应的业务分类标签")
    query_rewrite: str = Field(default="", description="改写后的问句（备用）")


class KeywordRetrievalOutput(BaseModel):
    """关键词检索节点的输出"""
    keyword_result: str = Field(..., description="关键词检索结果文本")
    keyword_chunks: List[Dict[str, Any]] = Field(default=[], description="关键词检索结果片段列表")
    retrieval_sources: List[str] = Field(default=[], description="命中的文档来源列表")
    retrieval_paths: List[str] = Field(default=[], description="命中的办事路径列表")


# ============ 结果合并节点 ============

class MergeRetrievalInput(BaseModel):
    """结果合并节点的输入"""
    vector_result: str = Field(default="", description="向量检索结果文本")
    vector_score: float = Field(default=0.0, description="向量检索最高得分")
    vector_chunks: List[Dict[str, Any]] = Field(default=[], description="向量检索结果片段列表")
    keyword_result: str = Field(default="", description="关键词检索结果文本")
    keyword_chunks: List[Dict[str, Any]] = Field(default=[], description="关键词检索结果片段列表")
    retrieval_sources: List[str] = Field(default=[], description="向量检索命中的文档来源")
    retrieval_paths: List[str] = Field(default=[], description="向量检索命中的办事路径")
    vector_sources: List[str] = Field(default=[], description="向量检索命中的文档来源")
    vector_paths: List[str] = Field(default=[], description="向量检索命中的办事路径")
    keyword_sources: List[str] = Field(default=[], description="关键词检索命中的文档来源")
    keyword_paths: List[str] = Field(default=[], description="关键词检索命中的办事路径")


class MergeRetrievalOutput(BaseModel):
    """结果合并节点的输出"""
    knowledge_retrieval: str = Field(..., description="合并后的检索结果文本")
    top_score: float = Field(default=0.0, description="合并后最高得分")
    has_valid_content: bool = Field(default=False, description="是否包含有效正文内容")
    merged_chunks: List[Dict[str, Any]] = Field(default=[], description="合并后的检索结果片段列表")
    retrieval_sources: List[str] = Field(default=[], description="合并后的文档来源列表")
    retrieval_paths: List[str] = Field(default=[], description="合并后的办事路径列表")


# ============ 制度冲突校验节点 ============

class RuleConflictCheckInput(BaseModel):
    """制度冲突校验节点的输入"""
    knowledge_retrieval: str = Field(..., description="合并后的检索结果文本")
    merged_chunks: List[Dict[str, Any]] = Field(default=[], description="合并后的检索结果片段列表")
    biz_type: str = Field(default="其他", description="业务分类标签")
    has_valid_content: bool = Field(default=False, description="是否包含有效正文内容")
    standard_hit: bool = Field(default=False, description="是否命中标准QA（命中时跳过冲突校验）")


class RuleConflictCheckOutput(BaseModel):
    """制度冲突校验节点的输出"""
    rule_conflict_detected: bool = Field(default=False, description="是否检测到真实量化规则冲突")
    is_real_conflict: bool = Field(default=False, description="是否为真实制度冲突（非阶梯规则）")
    is_tiered_rule: bool = Field(default=False, description="是否为阶梯分段合规规则")
    rule_conflict_sources: List[str] = Field(default=[], description="冲突规则的知识库文档来源列表")
    rule_conflict_details: str = Field(default="", description="冲突详情描述")


# ============ 二次检索节点 ============

class SecondaryRetrievalInput(BaseModel):
    """二次检索节点的输入"""
    split_questions: List[str] = Field(default=[], description="拆分后的子问题列表")
    biz_types: List[str] = Field(default=[], description="每条子问题对应的业务分类标签")
    query_rewrite: str = Field(default="", description="改写后的问句")


class SecondaryRetrievalOutput(BaseModel):
    """二次检索节点的输出"""
    secondary_retrieval: str = Field(..., description="二次检索结果文本")
    has_valid_content: bool = Field(default=False, description="二次检索是否有有效内容")
    retrieval_sources: List[str] = Field(default=[], description="命中的文档来源列表")
    retrieval_paths: List[str] = Field(default=[], description="命中的办事路径列表")


# ============ 条件判断节点 ============

class ConditionCheckInput(BaseModel):
    """条件判断节点的输入"""
    top_score: float = Field(..., description="检索结果最高得分")
    biz_type: str = Field(default="其他", description="业务分类标签")
    has_valid_content: bool = Field(default=False, description="是否有有效内容")
    knowledge_retrieval: str = Field(default="", description="检索结果文本")


class ConditionCheckOutput(BaseModel):
    """条件判断节点的输出"""
    route_branch: str = Field(..., description="路由分支：normal/mid_fallback/fallback")


# ============ 正常回答节点 ============

class NormalAnswerInput(BaseModel):
    """正常回答节点的输入"""
    user_input: str = Field(default="", description="用户原始问题")
    query_rewrite: str = Field(default="", description="改写后的问句")
    split_questions: List[str] = Field(default=[], description="拆分后的子问题列表")
    knowledge_retrieval: str = Field(default="", description="检索结果文本")
    top_score: float = Field(default=0.0, description="最高得分")
    biz_type: str = Field(default="其他", description="业务分类标签")
    retrieval_sources: List[str] = Field(default=[], description="命中的文档来源列表")
    retrieval_paths: List[str] = Field(default=[], description="命中的办事路径列表")
    doc_source: str = Field(default="", description="命中的文档来源")
    feishu_path: str = Field(default="", description="飞书办理路径")
    # 标准QA相关
    sub_question_standard_hits: List[SubQuestionStandardHit] = Field(default=[], description="每条子问题的标准QA命中结果")
    standard_hit: bool = Field(default=False, description="是否有子问题命中标准QA")
    standard_answer: Dict[str, Any] = Field(default={}, description="命中的标准QA预制答案")


class NormalAnswerOutput(BaseModel):
    """正常回答节点的输出"""
    normal_answer: dict = Field(..., description="正常回答结果JSON")


# ============ 过渡兜底回答节点 ============

class MidFallbackAnswerInput(BaseModel):
    """过渡兜底回答节点的输入"""
    user_input: str = Field(default="", description="用户原始问题")
    knowledge_retrieval: str = Field(default="", description="检索结果文本")
    top_score: float = Field(default=0.0, description="最高得分")
    biz_type: str = Field(default="其他", description="业务分类标签")
    doc_source: str = Field(default="", description="命中的文档来源")
    feishu_path: str = Field(default="", description="飞书办理路径")
    retrieval_sources: List[str] = Field(default=[], description="命中的文档来源列表")
    retrieval_paths: List[str] = Field(default=[], description="命中的办事路径列表")


class MidFallbackAnswerOutput(BaseModel):
    """过渡兜底回答节点的输出"""
    mid_fallback_answer: str = Field(..., description="过渡兜底回答文本")


# ============ 制度冲突专属兜底回答节点 ============

class ConflictFallbackAnswerInput(BaseModel):
    """制度冲突专属兜底回答节点的输入"""
    user_input: str = Field(default="", description="用户原始问题")
    rule_conflict_sources: List[str] = Field(default=[], description="冲突规则的知识库文档来源列表")
    rule_conflict_details: str = Field(default="", description="冲突详情描述")


class ConflictFallbackAnswerOutput(BaseModel):
    """制度冲突专属兜底回答节点的输出"""
    conflict_fallback_answer: str = Field(..., description="制度冲突专属兜底回答文本")


# ============ 全局兜底回答节点 ============

class FallbackAnswerInput(BaseModel):
    """全局兜底回答节点的输入"""
    user_input: str = Field(default="", description="用户原始问题")


class FallbackAnswerOutput(BaseModel):
    """全局兜底回答节点的输出"""
    fallback_answer: str = Field(..., description="全局兜底回答文本")
