# 小办（企业智能办事助手）· 工作流源码

> 面向企业员工行政制度自助问答的 Agent 工作流源码（由 Coze 导出）。覆盖**假期、报销、办公用品**三大高频场景，用 RAG 混合检索 + 分层 Agent 工作流替代 HR 重复性答疑。

---

## 一、产品简介

企业内部行政制度自助问答 Agent，面向员工侧的高频行政咨询（年假/事假/病假/婚假/产假、报销额度与流程、办公用品申领与维修等）。核心设计：

- **标准 QA 直答优先**：63 条人工梳理的标准问答作为最高优先级，命中即跳过检索、直接输出，保障高频问题稳定准确。
- **混合检索兜底**：未命中标准 QA 时走「向量检索 + 关键词检索 + 合并 + 二次检索」的 RAG 链路。
- **分层 Agent 工作流**：问句改写 → 拆分分类 → 标准 QA 匹配 → 冲突校验 → 三级路由（正常 / 过渡兜底 / 全局兜底）。

---

## 二、技术架构

| 维度 | 方案 |
|------|------|
| 编排 | LangGraph 状态图（`StateGraph`），由 Coze 平台导出 |
| 服务 | FastAPI（HTTP 同步 / 流式 SSE / OpenAI 兼容接口） |
| 检索 | 标准 QA 库向量命中（直答）+ 制度文档向量/关键词混合检索 + 二次检索兜底 |
| 校验 | 阶梯规则冲突识别、混合问句拆分与分类、三级路由 |
| 知识底座 | 63 条标准 QA（`standard_qa_kb/`）+ 结构化 `standard_qa_pool.json` |
| 运行环境 | Coze 开发者运行时（`coze_coding_utils` / `cozeloop` / `uv` 依赖） |

---

## 三、工作流主图（`graph.py`）

```
__start__
   │
   ▼
query_rewrite ──► split_and_classify ──► standard_qa_match
                                               │
                          ┌────────────────────┴─────────────────────┐
                    全部命中(库内高频)                          部分/全部未命中
                          │                                            │
                          ▼                                            ▼
                  normal_answer ──► __end__              vector_retrieval ──► keyword_retrieval
                                                                              │
                                                                              ▼
                                                                      merge_retrieval
                                                                              │
                                                                    ┌─────────┴─────────┐
                                                              有效内容              无效内容
                                                                  │                    │
                                                                  ▼                    ▼
                                                          rule_conflict_check    secondary_retrieval
                                                                  │                    │
                                                    ┌─────────────┴─────────────┐     ┌──────┴──────┐
                                                真实冲突                    无冲突   有效          无效
                                                  │                          │      │            │
                                                  ▼                          ▼      ▼            ▼
                                        conflict_fallback_answer    condition_check  normal_answer  fallback_answer
                                                                          │
                                                            ┌─────────┴─────────┐
                                                        正常回答   过渡兜底   全局兜底
                                                          │         │         │
                                                          ▼         ▼         ▼
                                                  normal_answer  mid_fallback  fallback_answer
```

- **13 个业务节点**：`query_rewrite` / `split_and_classify` / `standard_qa_match` / `vector_retrieval` / `keyword_retrieval` / `merge_retrieval` / `rule_conflict_check` / `secondary_retrieval` / `condition_check` / `normal_answer` / `mid_fallback_answer` / `fallback_answer` / `conflict_fallback_answer`
- **5 个条件路由**：标准 QA 是否全命中、制度是否真实冲突、合并检索是否有效、二次检索是否有效、检索得分三级路由

---

## 四、目录结构

```
xiaoban-workflow-src/
├── graph.py                      # 工作流主图编排（节点 + 边 + 条件路由）
├── main.py                       # 入口：FastAPI 服务 + 命令行运行（http / flow / node）
├── state.py                      # 全局状态与各节点输入/输出 Schema
├── config/                       # 节点 LLM 配置（6 个）
│   ├── query_rewrite_llm_cfg.json
│   ├── split_and_classify_llm_cfg.json
│   ├── normal_answer_llm_cfg.json
│   ├── fallback_answer_llm_cfg.json
│   ├── question_split_llm_cfg.json
│   └── biz_classify_llm_cfg.json
├── nodes/                        # 13 个节点实现
│   ├── query_rewrite_node.py
│   ├── split_and_classify_node.py
│   ├── standard_qa_match_node.py
│   ├── vector_retrieval_node.py
│   ├── keyword_retrieval_node.py
│   ├── merge_retrieval_node.py
│   ├── rule_conflict_check_node.py
│   ├── secondary_retrieval_node.py
│   ├── condition_check_node.py
│   ├── normal_answer_node.py
│   ├── mid_fallback_answer_node.py
│   ├── fallback_answer_node.py
│   ├── conflict_fallback_answer_node.py
│   └── __init__.py
├── standard_qa_kb/              # 63 条标准 QA 文本（假期 / 报销 / 办公用品）
├── standard_qa_pool.json        # 63 条标准 QA 结构化版本
└── 测试与实测/
    ├── auto_test_118.py                    # 118 条分层回归测试脚本
    └── 小办_扣子实测结果_20260823.json     # 人工实测结果（分层统计 + 逐例明细）
```

---

## 五、运行说明

本目录为 Coze 导出的工作流**源码快照**。完整可运行环境依赖 Coze 开发者运行时（`uv` + `coze_coding_utils` 等）。在 Coze 导出工程内，入口为 `main.py`：

```bash
# 1. 启动 HTTP 服务（默认 5000 端口）
python main.py -m http -p 5000

# 2. 直接跑完整工作流
python main.py -m flow -i '{"text":"工作满3年每年有几天年假？"}'

# 3. 单节点调试
python main.py -m node -n query_rewrite -i '{"text":"工作满3年每年有几天年假？"}'
```

提供的 HTTP 接口：`POST /run`、`/stream_run`、`/async_run`、`/node_run/{node_id}`、`/v1/chat/completions`（OpenAI 兼容）、`/health`、`/graph_parameter`、`/cancel/{run_id}`。

> ⚠️ **运行前提**：`graph.py` 使用 `from graphs.state / graphs.nodes` 的包内导入，本快照为扁平结构（根目录直接是 `graph.py` / `state.py` / `nodes/`）。若需脱离 Coze 工程单独运行，请将其还原为 `graphs/` 包布局（`graphs/graph.py`、`graphs/state.py`、`graphs/nodes/`），或在 Coze 导出工程内引用本目录源码。

---

## 六、知识库

- **`standard_qa_kb/`**：63 条人工梳理的标准问答（覆盖年假 / 事假 / 病假 / 婚假 / 产假 / 报销 / 办公用品申领维修等），作为最高优先级直答来源，命中即跳过检索分支。
- **`standard_qa_pool.json`**：同上内容的结构化版本，便于程序加载与回归测试。

---

## 七、评测与实测结果

- **测试集**：118 条分层用例（`L0 极端边界` / `L1 库内高频` / `L2 全量正常`），回归脚本见 `测试与实测/auto_test_118.py`。
- **人工实测**（Coze 工作流，2026-08-23，118 例全量）：

| 分层 | 用例数 | 通过 | 半通过 | 未通过 | 准确率 |
|------|-------:|-----:|-------:|-------:|-------:|
| L1 库内高频 | 24 | 24 | 0 | 0 | **100%** |
| L2 合并（L1+其余） | 102 | 95 | 0 | 7 | **93.1%** |
| └ 其余正常（非 L1） | 78 | 71 | 0 | 7 | 91.0% |
| L0 极端边界 | 16 | 12 | 1 | 3 | 75% – 81% |
| **整体** | **118** | **107** | **1** | **10** | **91.5%** |

> 说明：未通过项均为「兜底话术 / 改写覆盖」类，核心业务命中零误答；「半通过」计为部分符合（按 0 / 0.5 折算）。逐例明细见 `测试与实测/小办_扣子实测结果_20260823.json`。

---

## 八、技术栈

`Python` · `LangGraph` · `FastAPI` · `Coze 工作流运行时` · `向量检索（RAG）` · `OpenAI 兼容接口`
